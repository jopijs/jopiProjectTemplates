import { jopiApp } from "jopijs";

jopiApp.startApp(import.meta);