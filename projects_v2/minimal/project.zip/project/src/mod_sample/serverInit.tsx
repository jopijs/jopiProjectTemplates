import {JopiEasyWebSite} from "jopijs";

export default async function(webSite: JopiEasyWebSite) {
}