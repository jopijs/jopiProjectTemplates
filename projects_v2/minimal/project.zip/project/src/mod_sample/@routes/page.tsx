export default function Page() {
    return <div className="text-blue-400">Hello from Tailwind CSS!</div>
}