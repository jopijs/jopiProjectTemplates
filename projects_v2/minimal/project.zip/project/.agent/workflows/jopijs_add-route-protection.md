---
description: Protect a JopiJS route with Role-Based Access Control (RBAC)
---

// turbo-all
1. Identify the route folder you want to protect (e.g., `src/mod_admin/@routes/dashboard`).
2. Determine the required role (e.g., `admin`, `writer`).
3. Choose the scope of protection:
   - **Entire Folder (Recursive)**: Create a file named `needRole_<role>.cond`.
     - Example: `needRole_admin.cond` protects the folder and all subfolders.
   - **Specific Method**:
     - `postNeedRole_<role>.cond` (only for POST requests)
     - `pageNeedRole_<role>.cond` (only for Page GET requests)
4. **Multiple Roles (OR logic)**:
   - You can create multiple files.
   - Example behavior: If `needRole_admin.cond` AND `needRole_writer.cond` exist, the user needs EITHER `admin` OR `writer`.
5. **No Content**: These are marker files. They should be empty. Create them using `touch` or write an empty string.
