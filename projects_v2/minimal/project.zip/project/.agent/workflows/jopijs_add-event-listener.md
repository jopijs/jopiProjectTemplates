---
description: Create a new static event listener to react to system events
---

1. Identify the event:
    Find the event name you want to listen to (e.g., `user.login`, `cart.product_added`).
    This corresponds to a folder in `@alias/events/[event_name]`.

2. Create the listener directory:
    In your module, create a folder path following this structure:
    `src/my_module/@alias/events/[event_name]/[priority]_[action_name]/`

    - `[priority]`: A number (e.g., `100`, `200`) to determine execution order.
    - `[action_name]`: A descriptive name for what your listener does (e.g., `log_analytics`, `show_toast`).

3. Implement the listener logic:
    Create an `index.ts` (or `.tsx`) file in your new folder.
    Export a default function that receives the event data.

    ```typescript
    export default function(data: any) {
        console.log("Event received with data:", data);
        // Add your logic here (e.g., analytics, API calls, side effects)
    }
    ```

4. (Optional) Testing:
    To verify, trigger the event in your app and check if your listener executes.
