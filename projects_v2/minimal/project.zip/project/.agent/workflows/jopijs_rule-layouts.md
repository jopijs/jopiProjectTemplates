---
description: Rule and guide for creating and using layout components
---

# Rule: Layout Components

**Rule**: Layouts (common UI structures) MUST be implemented as Shared UI Components with a specific naming convention.

## Naming Convention
The component MUST be named using the pattern `layout.[context]`.
- Example: `layout.admin`
- Example: `layout.dashboard`
- Path: `src/mod_your_module/@alias/ui/layout.admin/index.tsx`

## Usage
Import the layout component and wrap your page content.

```tsx
import AdminLayout from "@/ui/layout.admin";

export default function MyPage() {
    return (
        <AdminLayout>
            <h1>My Page Content</h1>
            <p>Page logic goes here...</p>
        </AdminLayout>
    );
}
```

## Why?
- **Overridability**: By using a shared UI component, the layout can be easily overridden by another module (using `high.priority`), allowing for theme replacements.
- **Flexibility**: Multiple pages can explicitly opt-in to different layouts.
