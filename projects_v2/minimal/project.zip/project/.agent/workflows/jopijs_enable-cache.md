---
description: Enable automatic caching for a JopiJS route
---

// turbo-all
1. Identify the route directory in `@routes` where you want to enable caching.
2. Create an empty file named `autoCache.enable` in that directory.
   - For example: `src/mod_main/@routes/products/autoCache.enable`.
3. JopiJS will now automatically cache the rendered output of this route to improve performance.
4. To disable caching, simply delete the `autoCache.enable` file.
