---
description: Start the JopiJS development server
---

// turbo-all
1. Navigate to the project root directory.
2. Launch the development server using **Bun**:
   - `bun run start`: Standard development server.
   - `bun run start:ui-dev`: Development mode with Hot Module Replacement (HMR) enabled for the UI.
3. Access the application:
   - The default URL is usually `http://localhost:3000`.
   - You can customize it via the `JOPI_WEBSITE_URL` environment variable.
   - *Note: Avoid `npm run` as JopiJS is optimized for `bun`.*