---
description: Replace an existing resource (image, json, etc) from another module using the JopiJS override system
---

1. Identify the resource you want to override:
    Find the name of the resource folder in `@alias/res/` (e.g., `main.logo`).

2. Create the override structure in your module:
    If you don't have a module, create one first. Then, replicate the path:
    `src/my_module/@alias/res/[resource_name]/`

3. Add your new asset:
    Place your new file (image, json, etc.) inside this folder.

4. Create the `index.ts` bridge:
    Create a file `src/my_module/@alias/res/[resource_name]/index.ts` that exports your new asset as default.
    Example:
    ```typescript
    import myNewImage from "./my_new_image.png";
    export default myNewImage;
    ```

5. Apply the override:
    Create an empty file named `high.priority` in the same folder (`src/my_module/@alias/res/[resource_name]/`).
    This tells JopiJS to use your version instead of the original one.

6. Verify:
    Restart the server or check the browser to ensure the new resource is being used.