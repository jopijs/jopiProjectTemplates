---
description: Register a page to a navigation menu (Sidebar, Header, etc.)
---

1. Locate the route:
    Navigate to the route folder containing the `page.tsx` you want to register (e.g., `src/mod_app/@routes/admin/users/`).

2. Create or Edit `config.ts`:
    In the route folder, create a file named `config.ts` if it doesn't exist.

3. Add the registration logic:
    Export a default function receiving `JopiRouteConfig`. Call the appropriate method (`menu_addToLeftMenu`, `menu_addToTopMenu`, etc.).

    ```typescript
    import { JopiRouteConfig } from "jopijs";
    import trProvider, { supportedLangs } from "@/translations/website.layout";

    export default function (config: JopiRouteConfig) {
        // Prepare translations dynamically
        const translations: Record<string, string> = {};
        for (const lang of supportedLangs) {
             translations[lang] = trProvider(lang).menu_users();
        }

        // Syntax: .menu_addTo[MenuName](["Parent Label", "Child Label"], options)
        config.menu_addToLeftMenu(["Admin", "Users Management"], {
            translations,
        });
    }
    ```

4. Verify:
    - Check the menu in the browser.
    - **Note**: If the route is protected by a role (e.g., `needRole_admin.cond`), the menu item will *only* appear for authorized users.

---
**See also**: [Rule and guide for route configuration](jopijs_rule-route-config.md) for detailed syntax and constraints.
