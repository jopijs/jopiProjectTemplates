---
description: Add a new page to a JopiJS module
---

// turbo-all
1. Identify the target module (e.g., `src/mod_main`).
2. Create a file at `src/mod_<module_name>/@routes/<path>/page.tsx`.
   - The `<path>` corresponds to the URL. For example, `@routes/products/page.tsx` will be accessible at `/products`.
   - The homepage is `@routes/page.tsx`.
3. Use the following template for a standard page:
   ```tsx
   import React from 'react';
   import { JopiPageProps, usePageTitle } from "jopijs/ui";

   export default function Page({ params, searchParams }: JopiPageProps) {
       usePageTitle("New Page");
       return (
           <main className="container mx-auto p-8">
               <h1 className="text-4xl font-bold mb-4 text-slate-900 dark:text-white">
                   New Page
               </h1>
               <p className="text-lg text-slate-600 dark:text-slate-400">
                   Welcome to your new JopiJS page!
               </p>
           </main>
       );
   }
   ```
4. **Shared Components**: If a component is used across pages, place it in `@alias/ui` for easy importing via `@/ui`.
5. Use Shared Components for menus.