---
description: Rule and guide for creating and using route config.ts
---

# Route Configuration Rule

Every route in JopiJS can have an optional `config.ts` file in its directory to define metadata like menu registration, transition effects, or SEO.

## The Rule
- The `config.ts` file **MUST** export a default function.
- This function receives a `config` object of type `JopiRouteConfig`.
- It **MUST NOT** export a static object or use `defineRouteConfig` (which is for other frameworks).

## Correct Syntax
```typescript
import { JopiRouteConfig } from "jopijs";

export default function (config: JopiRouteConfig) {
    // To add to the main sidebar/navigation
    config.menu_addToLeftMenu(["My Section", "My Page"]);
    
    // To add to the top header
    config.menu_addToTopMenu(["My Page"]);
}
```

## When to use
1. To register a page in the automatic navigation system.
2. To define the display order (not shown in simple menu calls but available in metadata).
3. To group pages under common parents in menus.
