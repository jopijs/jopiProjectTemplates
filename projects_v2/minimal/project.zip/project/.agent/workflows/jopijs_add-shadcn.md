---
description: Add a ShadCN component or block to a specific JopiJS module
---

1. Choose the component/block:
    Identify the name of the ShadCN component (e.g., `button`, `input`) or block (e.g., `dashboard-01`).

2. Run the JopiJS utility:
    Use the `npx jopi shadcn-add` command with the `--mod` flag to specify the target module.

    ```bash
    npx jopi shadcn-add [component_name] --mod [module_name] --yes
    ```

    *Example:*
    ```bash
    npx jopi shadcn-add button --mod mod_ui_kit --yes
    ```

3. Verify installation:
    The files will be installed in `src/[module_name]/shadCN/`.
    If you installed a block (like a dashboard), a demo page will often be created in `@routes/shadPages/`.
