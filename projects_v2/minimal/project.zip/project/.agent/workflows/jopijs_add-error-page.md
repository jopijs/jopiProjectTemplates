---
description: how to add a custom error page (404, 500, 401)
---

To add a custom error page for specific HTTP status codes (like 404, 500, or 401), you simply need to create a standard page route named after the error status with an `error` prefix.

### Naming Convention
- **404 Not Found**: Create a route at `/error404`
- **500 Internal Server Error**: Create a route at `/error500`
- **401 Unauthorized**: Create a route at `/error401`

### Implementation Steps

1.  Identify the module where you want the error page to live (e.g., `src/mod_jopi`).
2.  Create the directory structure for the specific error code in `@routes`.
    - For 404: `src/[module_name]/@routes/error404/`
    - For 500: `src/[module_name]/@routes/error500/`
    - For 401: `src/[module_name]/@routes/error401/`
3.  Create a `page.tsx` file inside that directory.

### Example for 404 Page

Create `src/mod_jopi/@routes/error404/page.tsx`:

```tsx
import { definePage } from "@alias/lib/page.utils";

export default definePage({
  render() {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
        <h1 className="text-4xl font-bold text-gray-800">404</h1>
        <p className="text-xl text-gray-600">Page not found</p>
        <a href="/" className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
          Go back home
        </a>
      </div>
    );
  }
});
```

JopiJS will automatically use these routes when the corresponding error occurs.
