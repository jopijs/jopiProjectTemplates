---
description: Create a new API endpoint in JopiJS
---

// turbo-all
1. Identify the target module (e.g., `src/mod_main`).
2. Decide on the HTTP method and path:
   - `GET` -> `onGET.ts`
   - `POST` -> `onPOST.ts`
   - `PUT` -> `onPUT.ts`
   - `DELETE` -> `onDELETE.ts`
3. Create the file at `src/mod_<module_name>/@routes/<path>/<filename>.ts`.
   - Example: `src/mod_api/@routes/users/onGET.ts` for `GET /users`.
4. Use the following template:
   ```typescript
   import { JopiRequest } from "jopijs";

   export default async function handler(req: JopiRequest): Promise<Response> {
       // logic here
       const data = { message: "Hello API" };
       
       return req.res_jsonResponse(data);
   }
   ```
5. **Helpers**:
   - Parse body: `const body = await req.req_getBodyData();`
   - Query params: `req.url.searchParams.get('key')`