---
description: Listen to JopiJS events directly within a React component
---

1. Import the event:
    Import the event object from the virtual path `@/events/[event_name]`.
    ```typescript
    import eventMyAction from "@/events/my.action";
    ```

2. Use the `reactListener` method:
    Inside your React component function (before the return statement), call `.reactListener()`.
    Pass the callback function that should run when the event is emitted.

    ```tsx
    export default function MyComponent() {
        
        // This listener is automatically managed (mounted/unmounted)
        eventMyAction.reactListener((data) => {
            console.log("Event received:", data);
            // You can update state here
        });

        return <div>...</div>;
    }
    ```

3. (Optional) Benefits:
    - **Automatic Cleanup**: JopiJS handles adding and removing the listener when the component mounts/unmounts.
    - **No `useEffect` needed**: You don't need to manually wrap this in `useEffect`.
