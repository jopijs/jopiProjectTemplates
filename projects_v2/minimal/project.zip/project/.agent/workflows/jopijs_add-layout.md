---
description: Add a layout to a JopiJS route
---

// turbo-all
1. Identify the route directory in `@routes`.
2. Create a `layout.tsx` file in that directory.
3. Use the following template for the layout:
   ```tsx
   import React from 'react';
   import { JopiLayoutProps } from "jopijs/ui";

   export default function Layout({ children }: JopiLayoutProps) {
       return (
           <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
               {/* Add your shared layout elements here (e.g., Navbar, Sidebar) */}
               <main>{children}</main>
               {/* Add Footer here */}
           </div>
       );
   }
   ```
4. The layout will wrap all pages and nested routes within that directory.
