---
description: Use a shared UI component in JopiJS
---

// turbo-all
1. Identify the component name (e.g., `Button`, `Hero`).
2. Import it using the prefix `@/ui/`:
   ```tsx
   import Button from "@/ui/Button";
   ```
3. JopiJS will find the component in any of your modules' `@alias/ui` folders.
4. Pass props as defined in the component's `index.tsx`:
   ```tsx
   <Button className="mt-4">Click Me</Button>
   ```