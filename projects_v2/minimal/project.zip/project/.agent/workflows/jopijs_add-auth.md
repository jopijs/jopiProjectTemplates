---
description: Set up user authentication in JopiJS using the official module.
---

1. Install the `@jopijs/jopimod_user_auth` module:
    ```bash
    npm install @jopijs/jopimod_user_auth
    ```

2. Run `jopi mod-check` to extract the authentication module:
   // turbo
   ```bash
   npx jopi mod-check
   ```

3. Verify the installation:
    The module should be extracted to `src/mod_jopijs@user_auth/`.
    - It provides a default `/login` route.
    - It includes a default user: `admin` / `admin`.

4. (Optional) customize the authentication logic or UI:
    JopiJS allows customization via the priority system. To customize, create a new module (e.g., `src/mod_auth_custom`) and override shared items.

    Common overrides:
    - **Login Form**: `@alias/ui/jopijs.auth.loginForm` - Create a component to replace the default form.
    - **Login Image**: `@alias/res/jopijs.auth.image` - Export a default image URL/path to replace the side image.
    - **User Finder**: `@alias/lib/jopijs.auth.findUser` - A function `(loginInfo: IAuthData) => Promise<UserEntry | undefined>` to fetch users from a DB.
    - **Password Checker**: `@alias/lib/jopijs.auth.checkAuthData` - A function `(fromDB: IAuthData, fromBrowser: IAuthData) => Promise<boolean>` to validate credentials.

    **Important**: Remember to add a `high.priority` file in the directory of the overridden item to ensure your custom logic takes precedence.

5. (Optional) Extend User Data:
    To add custom fields to the user object (e.g., `phoneNumber`), use TypeScript interface merging on `IUserInfos` in a definition file (e.g., `src/mod_app/index.d.ts`).