---
description: Create a new UI Composite area where other modules can inject components
---

1. Choose a name:
    Decide on a unique name for your composite area (e.g., `mainToolbar`, `adminSidebar`, `userMenu`).

2. Create the directory:
    Inside your module, create a folder in the `@alias/uiComposites/` path:
    `src/my_module/@alias/uiComposites/[composite_name]/`

3. (Optional) Add initial content:
    You can add initial items here using numeric prefixes (e.g., `100_start/`).
    *Note: Even without content, just creating the folder reserves the namespace.*

4. Use the composite in React:
    Import the composite via the virtual path and use it like a component.
    
    ```tsx
    import MyComposite from "@/uiComposites/[composite_name]";

    export default function Page() {
        return (
            <div className="layout">
                <MyComposite /> 
            </div>
        );
    }
    ```
