---
description: Replace an existing component or style from another module using the JopiJS override system
---

// turbo-all
1. Identify the target component you want to override (e.g., `src/mod_core/@alias/ui/Button`).
2. Identify or create the module where you will place the override (e.g., `src/mod_myTheme`).
3. Replicate the directory structure in your module:
   - Target: `src/mod_myTheme/@alias/ui/Button`
4. **Important**: Add a marker file named `high.priority` in this new folder.
   - This tells JopiJS to prefer this component over the original one.
5. Create your new `index.tsx` (and `style.module.css` if needed) in this folder.
   - Any import of `@/ui/Button` across the application will now resolve to your new component.

**Alternative: Override Style Only**
If you only want to change the CSS but keep the logic:
1. Create the path: `src/mod_myTheme/@alias/styles/ui/Button`.
2. Create your `style.module.css`.
3. JopiJS will inject your styles into the original component automatically.
