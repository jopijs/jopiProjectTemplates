---
description: Share an image, text, or JSON file across modules using JopiJS resource system
---

1. Choose a meaningful name:
    Decide on a unique name for your resource (e.g., `main.logo`, `app.config`, `default.avatar`).

2. Create the resource directory:
    Inside your module, create a folder in the `@alias/res/` path:
    `src/my_module/@alias/res/[resource_name]/`

3. Add your asset:
    Place your file (image, json, txt, etc.) inside this new folder.

4. Create the export bridge:
    Create an `index.ts` file in the folder (`src/my_module/@alias/res/[resource_name]/index.ts`) to make it accessible to the rest of the app.

    **For Images:**
    ```typescript
    import img from "./image.png";
    export default img;
    ```

    **For JSON:**
    ```typescript
    import data from "./data.json";
    export default data;
    ```

5. Usage:
    You can now import this resource from anywhere in your application using the virtual path:
    ```typescript
    import myResource from "@/res/[resource_name]";
    ```