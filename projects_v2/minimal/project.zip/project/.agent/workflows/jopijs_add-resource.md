---
description: Share an image, text, or JSON file across modules using JopiJS resource system
---

To share a static asset (like an image, font, or JSON file) so it can be used by other modules or overridden later, you must place it in `@alias/res`.

### 1. Create the Resource

1.  Choose a unique name for your resource (e.g., `brand_logo`).
2.  Create a folder with this name inside `src/[your_module]/@alias/res/`.
3.  Place your file (e.g., `logo.png`) inside this new folder.
4.  Create an `index.ts` file in the same folder to export the asset.

**Structure:**
```text
src/mod_jopi/@alias/res/brand_logo/
├── logo.png
└── index.ts
```

**Content of `index.ts`:**
```typescript
import logo from "./logo.png";
export default logo;
```

### 2. Use the Resource

In any component or page in your project, import the resource using the `@/res/` alias.

```tsx
import logo from "@/res/brand_logo";

export default function Header() {
    return <img src={logo} alt="Brand Logo" />;
}
```

JopiJS handles the path resolution, ensuring that if another module overrides `brand_logo`, the correct file is served automatically.