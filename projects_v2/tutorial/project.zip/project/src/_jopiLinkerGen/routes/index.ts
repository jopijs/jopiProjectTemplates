import { jsx as _jsx } from "react/jsx-runtime";
import routes from "./jBundler_ifServer.ts";
export * as routes from "./jBundler_ifServer.ts";


function renderRoute(name: string) {
    let F = (routes as any)[name];
    if (!F) F = () => _jsx("div", { children: `Error 404: put a @routes${name}/page.tsx file for personalizing it` });
    return _jsx(F, {});
}

export function error404() {
    return renderRoute("/error404");
}

export function error500() {
   return renderRoute("/error500");
}

export function error401() {
    return renderRoute("/error401");
}