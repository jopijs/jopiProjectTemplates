import {CheckRoles} from "jopijs/uikit";
import AdminPageLayout from "@/uiComponents/page.layout.admin";

export default function() {
    return <AdminPageLayout>
        <CheckRoles roles={["writer"]}>
            <div>Writer Role Only</div>
        </CheckRoles>
    </AdminPageLayout>
}