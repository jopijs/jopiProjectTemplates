import {RouteConfig} from "jopijs";

export default function (config: RouteConfig) {
    config.menu_addToLeftMenu(["Roles demo",  "Hide test"]);
}