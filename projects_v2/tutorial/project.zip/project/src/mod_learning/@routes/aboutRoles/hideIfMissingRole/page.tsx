import {CheckRoles} from "jopijs/uikit";
import AdminPageLayout from "@/uiComponents/page.layout.admin";

export default function () {
    // CheckRoles allows protection a UI content and displays
    // this content only if the user has the required roles.
    return <AdminPageLayout>
        <div>This part is visible for everyone</div>
        <CheckRoles roles={["writer"]}>
            <div>This part is only visible for users with "writer" role</div>
        </CheckRoles>
        <CheckRoles roles={["admin", "writer"]}>
            <div>This part is only visible for users with "admin" or "writer" roles</div>
        </CheckRoles>
    </AdminPageLayout>
}