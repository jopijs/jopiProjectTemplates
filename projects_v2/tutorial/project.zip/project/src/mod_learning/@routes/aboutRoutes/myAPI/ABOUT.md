# About

What is here allows listing the url:http://localhost:3000/aboutRoutes/myAPI

Here we will declare listeners for the GET and POST http methods.

You can also do it for others methods:
- onGET.ts for GET calls
- onPOST.ts for POST calls
- onPUT.ts for PUT calls
- onDELETE.ts for DELETE calls
- onHEAD.ts for HEAD calls
- onOPTIONS.ts for OPTIONS calls

> You can't have both 'onGET.ts' and 'page.tsx' because the two one respond to GET calls. 