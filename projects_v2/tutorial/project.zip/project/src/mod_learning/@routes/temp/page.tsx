import {usePageTitle} from "jopijs/ui";
import {PageProps} from "jopijs/ui";

// For loading a style sheet.
// import "./my-style.css";

// You can also use SCSS.
// import "./my-style.scss";

// For using CSS modules.
// import myCssMod from "./style.module.css";

// For using an image.
// Will returns his URL (and automatically make it public).
// import myImg from "./image.png";

export default function(props: PageProps) {
    // If you use CSS modules, you need to call this function.
    //useCssModule(myCssMod);

    usePageTitle("My page title");

    return <div onClick={()=>alert('click')} className="text-red-500">
        Click me!
    </div>
}