export default function(data: any) {
    console.log("card.product.added - refreshPrice", data);
}