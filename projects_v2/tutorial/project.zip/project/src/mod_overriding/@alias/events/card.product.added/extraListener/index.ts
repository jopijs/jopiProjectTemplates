export default function(data: any) {
    console.log("card.product.added - mod_overriding/extraListener", data);
}