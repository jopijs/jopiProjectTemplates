import C from "../../../../shadCN/variants/jTable/default";
export default C;