import C from "../../../../shadCN/variants/jForm/default";
export default C;