import {UiKitModule} from "jopijs/uikit";

import {Frame, GalleryVerticalEnd, SquareTerminal} from "lucide-react";

export default function(myModule: UiKitModule) {
    const menuManager = myModule.getMenuManager();

    myModule.resolveIcon("square", SquareTerminal);

    menuManager.addMenuBuilder("favorites", (projectsMenu) => {
        projectsMenu.set(["Home"], {url: "/", icon: Frame});
    });

    menuManager.addMenuBuilder("teams", (teamsMenu) => {
        teamsMenu.set(["Acme 1"], {url: "#", icon: GalleryVerticalEnd, plan: "Plan 1"});
        teamsMenu.set(["Acme 2"], {url: "#", icon: GalleryVerticalEnd, plan: "Plan 2"});
        teamsMenu.set(["Acme 3"], {url: "#", icon: GalleryVerticalEnd, plan: "Plan 3"});
    });
}