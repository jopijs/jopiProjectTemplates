# About

This module allows:
- Enabling user authentification with JWT (Json Web Token).
- Exposing a route for user login: http://localhost:3000/login
- Declaring some sample users (see file `myUsers.json`)


Interesting parts:
```
|- mod_userAuth/
    |- serverInit.ts        < Enable user authentification and init the user store.
    |- myUsers.json         < Sample users.
    |- @routes/
        |- login/
            |- page.tsx     < The visual of the login page.
            |- onPOST.ts    < Handle the POST request receiving the login/password.
                               It's where this login/password are checked.                                
```