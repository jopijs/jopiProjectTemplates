import React from "react";

export default function() {
    return <div>
        My error 401 page
    </div>
}