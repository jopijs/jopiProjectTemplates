import React from "react";

export default function() {
    return <div>
        My error 404 page
    </div>
}