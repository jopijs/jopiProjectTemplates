# README

Welcome to this tutorial project!

## Run the app

To start the app, run: `bun run start` or `npm run start` or `yarn start` from the root of the project.

`package.json` contains the scripts to run the app. This scripts are:

* `start`: run the app in default mode (no dev server, no hot reload).
* `start:nodejs`: the same for node.js
* `start:sever-dev`: execute server dev-mode.
  * It watches all file changes (including resources like images, css, etc.) and restarts the server.
  * Once fully restarted, the browser reloads automatically. 
* `start:ui-dev`: execute UI dev-mode.
  * With Bun.js it rebuilds the UI (+ Tailwind) and refreshs the Browser.
  * The whole in less than 0,5 seconds, even with 1000+ pages. 

In addition, you have the script `jopiBuild_node` which is executed when you run `npm run start:nodejs`.
It allows converting the TypeScript to JavaScript (into the `dist` folder).

## What's inside?

This project is composed into modules: Jopi projects are always organized into modules.

Here is the list of modules and what they did:
```
|- src/
    |- mod_learning/        < Contains 80% of the samples code.
    |- mod_userAuth/        < Show you how to implement user authentication.
    |- mod_errorPages/      < Show you how to define error pages templates.
    |- mod_adminLayout/     < Implements a layout for admin pages.
    |- mod_shadcn/          < Where ShadCN components are stored.
    |- mod_overriding/      < Use to demonstrate overriding of items form another module.
```


### mod_userAuth

The module **mod_userAuth** can be copy-paste as-is into your project, to:
- Add user authentication to your project.
- Manage a simple user store.
- Add a login page screen with his API.

> You will find a file ABOUT.md at the root of this module, explaining what it does.

### mod_adminLayout

The module **mod_adminLayout** implements a layout for admin pages.

All the UI structure his implemented here (it's the only goal of this module).
Other modules only add pages, while the main UI logic is in this module.

### mod_shadcn

This module contains ShadCN components. It's not mandatory to use ShadCN, but here we did this choice for the demo.

### mod_learning

It's where you will find the main code sample of this tutorial.  

```
|- mod_learning/
    |- @routes/
        |- aboutEvents/             < Explains how to works with events.
        |- aboutReact/              < Most of the samples about React are here.
            |        
            |- aboutCSS/            < Explains how to use CSS with Jopi.
            |- aboutImages/         < Explains how to import / embed images.
            |
            |- aboutReactHMR/       < Explains what is React HMR with a demo.
            |
            |- aboutUiComposites/   < Explains what are composites and how to use them.                     
            |- aboutUiComponents/   < Explains how to use share React components.
                                        between the modules and how a module can override
                                        a component from another module.      
```