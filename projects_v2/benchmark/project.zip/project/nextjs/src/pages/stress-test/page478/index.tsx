export default function() {
    return <div>Page 478/1000</div>
};