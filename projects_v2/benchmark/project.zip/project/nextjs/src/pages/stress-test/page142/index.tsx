export default function() {
    return <div>Page 142/1000</div>
};