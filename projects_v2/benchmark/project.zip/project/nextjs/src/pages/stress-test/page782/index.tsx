export default function() {
    return <div>Page 782/1000</div>
};