export default function() {
    return <div>Page 32/1000</div>
};