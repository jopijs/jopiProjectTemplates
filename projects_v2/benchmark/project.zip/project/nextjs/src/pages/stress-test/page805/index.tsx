export default function() {
    return <div>Page 805/1000</div>
};