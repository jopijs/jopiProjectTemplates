export default function() {
    return <div>Page 56/1000</div>
};