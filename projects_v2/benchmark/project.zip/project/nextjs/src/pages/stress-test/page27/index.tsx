export default function() {
    return <div>Page 27/1000</div>
};