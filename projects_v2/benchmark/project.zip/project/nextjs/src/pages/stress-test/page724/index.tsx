export default function() {
    return <div>Page 724/1000</div>
};