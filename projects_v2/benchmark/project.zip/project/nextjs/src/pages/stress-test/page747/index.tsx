export default function() {
    return <div>Page 747/1000</div>
};