export default function() {
    return <div>Page 572/1000</div>
};