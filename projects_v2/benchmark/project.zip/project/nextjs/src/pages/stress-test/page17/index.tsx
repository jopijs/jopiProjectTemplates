export default function() {
    return <div>Page 17/1000</div>
};