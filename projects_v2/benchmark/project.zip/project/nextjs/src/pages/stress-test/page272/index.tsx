export default function() {
    return <div>Page 272/1000</div>
};