export default function() {
    return <div>Page 753/1000</div>
};