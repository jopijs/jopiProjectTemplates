export default function() {
    return <div>Page 120/1000</div>
};