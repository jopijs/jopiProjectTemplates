export default function() {
    return <div>Page 365/1000</div>
};