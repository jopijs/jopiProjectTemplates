export default function() {
    return <div>Page 673/1000</div>
};