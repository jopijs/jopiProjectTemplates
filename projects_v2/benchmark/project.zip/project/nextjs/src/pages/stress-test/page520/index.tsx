export default function() {
    return <div>Page 520/1000</div>
};