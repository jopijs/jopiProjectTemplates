export default function() {
    return <div>Page 714/1000</div>
};