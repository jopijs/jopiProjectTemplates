export default function() {
    return <div>Page 60/1000</div>
};