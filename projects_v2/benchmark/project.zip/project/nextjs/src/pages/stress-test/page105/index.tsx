export default function() {
    return <div>Page 105/1000</div>
};