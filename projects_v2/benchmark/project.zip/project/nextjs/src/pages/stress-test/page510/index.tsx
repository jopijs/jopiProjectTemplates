export default function() {
    return <div>Page 510/1000</div>
};