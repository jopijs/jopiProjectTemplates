export default function() {
    return <div>Page 707/1000</div>
};