export default function() {
    return <div>Page 244/1000</div>
};