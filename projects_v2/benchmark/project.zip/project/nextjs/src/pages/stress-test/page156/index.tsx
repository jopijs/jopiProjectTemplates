export default function() {
    return <div>Page 156/1000</div>
};