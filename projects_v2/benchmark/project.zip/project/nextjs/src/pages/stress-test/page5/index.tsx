export default function() {
    return <div>Page 5/1000</div>
};