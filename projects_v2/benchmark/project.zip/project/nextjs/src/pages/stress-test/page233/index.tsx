export default function() {
    return <div>Page 233/1000</div>
};