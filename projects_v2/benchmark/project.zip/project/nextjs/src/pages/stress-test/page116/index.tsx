export default function() {
    return <div>Page 116/1000</div>
};