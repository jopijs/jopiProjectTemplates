export default function() {
    return <div>Page 666/1000</div>
};