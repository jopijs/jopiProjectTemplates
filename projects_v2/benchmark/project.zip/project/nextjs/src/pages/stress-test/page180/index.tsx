export default function() {
    return <div>Page 180/1000</div>
};