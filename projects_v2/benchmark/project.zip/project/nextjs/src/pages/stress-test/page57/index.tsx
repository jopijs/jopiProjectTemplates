export default function() {
    return <div>Page 57/1000</div>
};