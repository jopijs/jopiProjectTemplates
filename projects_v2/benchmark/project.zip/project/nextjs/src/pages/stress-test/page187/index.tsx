export default function() {
    return <div>Page 187/1000</div>
};