export default function() {
    return <div>Page 672/1000</div>
};