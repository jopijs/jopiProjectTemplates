export default function() {
    return <div>Page 627/1000</div>
};