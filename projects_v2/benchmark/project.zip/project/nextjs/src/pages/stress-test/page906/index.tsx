export default function() {
    return <div>Page 906/1000</div>
};