export default function() {
    return <div>Page 667/1000</div>
};