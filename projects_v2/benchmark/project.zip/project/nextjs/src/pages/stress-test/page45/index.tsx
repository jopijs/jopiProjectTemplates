export default function() {
    return <div>Page 45/1000</div>
};