export default function() {
    return <div>Page 256/1000</div>
};