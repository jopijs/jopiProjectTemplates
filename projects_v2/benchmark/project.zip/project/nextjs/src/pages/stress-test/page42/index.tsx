export default function() {
    return <div>Page 42/1000</div>
};