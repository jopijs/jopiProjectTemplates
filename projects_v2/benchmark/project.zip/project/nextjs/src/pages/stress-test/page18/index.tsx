export default function() {
    return <div>Page 18/1000</div>
};