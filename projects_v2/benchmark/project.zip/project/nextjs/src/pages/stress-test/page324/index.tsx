export default function() {
    return <div>Page 324/1000</div>
};