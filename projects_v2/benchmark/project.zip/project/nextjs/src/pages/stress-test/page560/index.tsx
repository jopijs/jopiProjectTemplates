export default function() {
    return <div>Page 560/1000</div>
};