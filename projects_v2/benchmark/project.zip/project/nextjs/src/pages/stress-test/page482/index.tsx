export default function() {
    return <div>Page 482/1000</div>
};