export default function() {
    return <div>Page 708/1000</div>
};