export default function() {
    return <div>Page 226/1000</div>
};