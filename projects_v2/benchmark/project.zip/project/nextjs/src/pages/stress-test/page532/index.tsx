export default function() {
    return <div>Page 532/1000</div>
};