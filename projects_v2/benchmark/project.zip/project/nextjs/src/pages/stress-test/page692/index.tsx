export default function() {
    return <div>Page 692/1000</div>
};