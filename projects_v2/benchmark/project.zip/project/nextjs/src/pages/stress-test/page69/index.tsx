export default function() {
    return <div>Page 69/1000</div>
};