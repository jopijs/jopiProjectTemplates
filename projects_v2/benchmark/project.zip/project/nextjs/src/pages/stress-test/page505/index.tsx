export default function() {
    return <div>Page 505/1000</div>
};