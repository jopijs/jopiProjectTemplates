export default function() {
    return <div>Page 567/1000</div>
};