export default function() {
    return <div>Page 736/1000</div>
};