export default function() {
    return <div>Page 900/1000</div>
};