export default function() {
    return <div>Page 260/1000</div>
};