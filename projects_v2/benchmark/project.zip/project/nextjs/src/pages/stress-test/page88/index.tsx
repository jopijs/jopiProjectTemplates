export default function() {
    return <div>Page 88/1000</div>
};