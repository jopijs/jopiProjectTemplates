export default function() {
    return <div>Page 867/1000</div>
};