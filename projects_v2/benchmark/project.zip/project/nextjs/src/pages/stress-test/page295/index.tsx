export default function() {
    return <div>Page 295/1000</div>
};