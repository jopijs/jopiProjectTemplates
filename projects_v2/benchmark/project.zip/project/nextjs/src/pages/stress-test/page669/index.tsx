export default function() {
    return <div>Page 669/1000</div>
};