export default function() {
    return <div>Page 738/1000</div>
};