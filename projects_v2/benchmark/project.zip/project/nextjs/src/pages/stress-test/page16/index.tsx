export default function() {
    return <div>Page 16/1000</div>
};