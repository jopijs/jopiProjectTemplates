export default function() {
    return <div>Page 118/1000</div>
};