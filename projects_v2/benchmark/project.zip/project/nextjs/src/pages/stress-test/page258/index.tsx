export default function() {
    return <div>Page 258/1000</div>
};