export default function() {
    return <div>Page 74/1000</div>
};