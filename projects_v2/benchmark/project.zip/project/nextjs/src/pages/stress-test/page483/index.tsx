export default function() {
    return <div>Page 483/1000</div>
};