export default function() {
    return <div>Page 765/1000</div>
};