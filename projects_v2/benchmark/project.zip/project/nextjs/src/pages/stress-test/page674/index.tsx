export default function() {
    return <div>Page 674/1000</div>
};