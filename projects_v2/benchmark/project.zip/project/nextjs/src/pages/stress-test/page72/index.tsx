export default function() {
    return <div>Page 72/1000</div>
};