export default function() {
    return <div>Page 188/1000</div>
};