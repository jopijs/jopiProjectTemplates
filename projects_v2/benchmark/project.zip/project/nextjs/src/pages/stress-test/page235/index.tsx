export default function() {
    return <div>Page 235/1000</div>
};