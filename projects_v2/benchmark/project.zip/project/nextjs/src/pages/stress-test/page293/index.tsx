export default function() {
    return <div>Page 293/1000</div>
};