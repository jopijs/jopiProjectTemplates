export default function() {
    return <div>Page 210/1000</div>
};