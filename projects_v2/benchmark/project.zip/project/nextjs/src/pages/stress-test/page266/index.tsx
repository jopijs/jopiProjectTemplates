export default function() {
    return <div>Page 266/1000</div>
};