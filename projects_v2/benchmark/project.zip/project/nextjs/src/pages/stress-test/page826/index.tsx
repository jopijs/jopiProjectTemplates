export default function() {
    return <div>Page 826/1000</div>
};