export default function() {
    return <div>Page 20/1000</div>
};