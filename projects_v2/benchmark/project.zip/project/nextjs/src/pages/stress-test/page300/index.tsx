export default function() {
    return <div>Page 300/1000</div>
};