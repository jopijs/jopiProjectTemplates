export default function() {
    return <div>Page 588/1000</div>
};