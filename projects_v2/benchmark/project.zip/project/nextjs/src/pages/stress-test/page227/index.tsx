export default function() {
    return <div>Page 227/1000</div>
};