export default function() {
    return <div>Page 762/1000</div>
};