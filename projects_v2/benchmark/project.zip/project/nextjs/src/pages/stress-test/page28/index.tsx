export default function() {
    return <div>Page 28/1000</div>
};