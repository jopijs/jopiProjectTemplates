export default function() {
    return <div>Page 730/1000</div>
};