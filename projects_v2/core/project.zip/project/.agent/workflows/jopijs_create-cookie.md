---
description: How to create/set a cookie in JopiJS (API & UI)
---

This workflow explains how to set cookies in JopiJS. There are two contexts: **API Routes** (Server) and **React Components** (UI).

### 1. In API Routes (Server-Side)

When working in an API route (e.g., `onGET.ts`, `onPOST.ts`), use the `JopiRequest` object methods.

**File:** `src/[module]/@routes/[path]/onGET.ts`

```typescript
import { JopiRequest } from "jopijs";

export default async function(req: JopiRequest) {
    // Set a cookie named "my_cookie" with value "123"
    // The third argument is optional options (maxAge, path, etc.)
    req.cookie_addCookieToRes("my_cookie", "123", { 
        maxAge: 60 * 60 * 24 * 7 // 7 days in seconds
    });

    return req.res_jsonResponse({ success: true });
}
```

### 2. In React Components (UI / Isomorphic)

When working in a Page or Component, use the `setCookie` utility from `jopijs/ui`. This works both on the server (during SSR) and in the browser.

**File:** `src/[module]/@routes/[path]/page.tsx`

```tsx
import { setCookie } from "jopijs/ui";

export default function MyPage() {
    const handleSave = () => {
        // Set a cookie when a user interacts
        setCookie("user_pref", "dark_mode", { maxAge: 86400 });
    };

    return (
        <button onClick={handleSave}>Save Preference</button>
    );
}
```

**Note:** If you need to set a cookie immediately when the page loads (and have it available during SSR), you should use `useStaticEffect`:

```tsx
import { setCookie, useStaticEffect } from "jopijs/ui";

export default function MyPage() {
    useStaticEffect(() => {
        setCookie("initial_visit", "true");
    }, []);
    
    return <div>Welcome!</div>;
}
```
