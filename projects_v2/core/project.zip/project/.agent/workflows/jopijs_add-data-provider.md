---
description: Create a cached Data Provider (Entity Provider) for sharing data between modules
---

// turbo-all
1. **Identify the Data Entity**: (e.g., `shop.product`, `blog.post`).

2. **Create the Provider Folder**:
   - Path: `src/mod_<module>/@alias/dataProviders/<entity_name>/`
   - Example: `src/mod_shop/@alias/dataProviders/shop.product/`

3. **Implement the Logic**:
   - Create `index.ts` inside the folder.
   - Export an efficient async function that fetches the data.

   ```typescript
   import { db } from "@/lib/db";

   // Optional ID argument (string, number, or object)
   export default async function(id?: string) {
       if (!id) return undefined;

       // Fetch data (DB, API, etc.)
       const data = await db.query("SELECT * FROM products WHERE id = ?", [id]);

       // MUST return an object with a 'value' property
       return {
           value: data
       };
   }
   ```

4. **Consume the Provider**:
   - Import using the alias `@/dataProviders/name`.

   ```typescript
   import shopProduct from "@/dataProviders/shop.product";

   export async function someLogic() {
       // 1. Get value (Auto-cached)
       const product = await shopProduct.getValue("123");

       // 2. Refresh (Force fetch)
       await shopProduct.refresh("123");

       // 3. Delete from cache
       await shopProduct.delete("123");
   }
   ```
