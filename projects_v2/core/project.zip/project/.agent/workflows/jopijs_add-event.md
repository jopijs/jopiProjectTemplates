---
description: Create a new custom event definition for other modules to listen to
---

1. Choose a unique event name:
    Use a dot notation for clarity (e.g., `invoice.created`, `profile.updated`, `chat.message_received`).

2. Create the event directory:
    In your module, create a folder in the `@alias/events/` path:
    `src/my_module/@alias/events/[event_name]/`

    *Note: You don't need to put any files inside this folder. The existence of the folder defines the event. No listener registration is required for the event to be active.*

3. Emit the event:
    In your code (React component or logic file), import the event via the virtual path `@/events/[event_name]` and call `.send()`.
    
    *Important: The method to trigger the event is `.send()`, NOT `.emit()`.*

    ```typescript
    import eventMyAction from "@/events/[event_name]";

    // ... inside your function
    eventMyAction.send({ someKey: "someValue" });
    ```
