---
description: List all available shared UI components
---

// turbo-all
1. Shared components are located in the `@alias/ui` virtual directory.
2. To find them on disk, check `src/mod_*/@alias/ui/`.
3. Each sub-directory (e.g., `Card`, `Button`) is a component you can import.
4. **Auto-Discovery**: JopiJS automatically resolves the `@/ui` alias to find components in any module.
5. Example list check:
   ```bash
   ls -d src/mod_*/@alias/ui/*/
   ```