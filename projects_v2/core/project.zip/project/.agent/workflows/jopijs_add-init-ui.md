---
description: Add a UI initializer (Browser/SSR) to a JopiJS module
---

// turbo-all
1. Identify the target module (e.g., `src/mod_main`).
2. Create a file `src/mod_<module_name>/uiInit.tsx`.
3. Use this file to run code during the application initialization (both on Server for SSR and in the Browser).
4. **Requirement**: The file **MUST** export a default async function.
5. Template:
   ```typescript
   import { JopiUiApplication } from "jopijs/ui";
   import { EventPriority } from "jopi-toolkit/jk_events";

   export default function(uiApp: JopiUiApplication) {
       // Optional, for post-install execution.
       // Priority can also be: verylow (executed after), low, high, veryhigh (executed first).
       uiApp.addUiInitializer(EventPriority.default, () => {
           console.log("Module initialized in the browser!");
       });
   }
   ```