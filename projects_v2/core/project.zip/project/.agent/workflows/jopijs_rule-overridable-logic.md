---
description: Rule and guide for placing overridable logic in @alias/lib
---

# Rule: Logic & Overrides (@alias/lib)

**Rule**: Classes and interfaces that are at risk of being overloaded (replaced or extended) MUST be placed in `@alias/lib`.

## Why?
Placing them in `@alias/lib` enables the JopiJS Priority System to handle:
- **Replacements** (via `high.priority`)
- **Merging** (via `class.merge` or `interface.merge`)

## Usage Steps

1. **Identify Logic**: Determine if your class or interface is likely to be customized by other modules (e.g., `User`, `Product`, `Config`).
2. **Place in Lib**: Create your file in `src/mod_your_module/@alias/lib/YourItem/index.ts`.
3. **Import correctly**: Always import using the virtual path:
   ```typescript
   import YourItem from "@/lib/YourItem";
   ```

## Important Notes

- **One Item Per Folder**: Do not group multiple classes or interfaces in a single file (e.g., `types.ts`). Each shared item MUST have its own folder and `index.ts`.
  - ✅ `@alias/lib/shop.Product/index.ts`
  - ❌ `@alias/lib/types.ts`
- **Naming**: Use dot notation for related items if necessary (e.g., `shop.Product`, `user.Profile`).
- **Export Default**: You MUST use `export default` for the item in `index.ts`. Named exports are not supported for overridable items.