---
description: Override the styles of a shared component using CSS Modules
---

// turbo-all
1. Identify the component you want to style.
   - Example: `@alias/ui/Card` (located in `src/mod_ui/@alias/ui/Card`).

2. Create a new module (e.g., `mod_theme`) if you don't have one.

3. Create the style override file matching the component's path under `@alias/styles`.
   - Target Path: `src/mod_theme/@alias/styles/ui/Card/style.module.css`

4. Write your new CSS.
   - You can use standard CSS or Tailwind `@apply`.

   ```css
   /* src/mod_theme/@alias/styles/ui/Card/style.module.css */
   
   /* These class names must match the ones used in the original component */
   .container {
       @apply bg-slate-900 border-slate-700;
   }

   .title {
       @apply text-blue-400 font-bold;
   }
   ```

5. **Done!** JopiJS automatically detects the new file and updates the `style.gen.ts` used by the component. 
   - Note: The original component must be using `useCssModule(styles)` and `import styles from "./style.gen.ts"` for this to work.
