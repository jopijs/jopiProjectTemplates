---
description: Inject a component into an existing UI Composite (Toolbar, Sidebar, etc.)
---

1. Identify the composite:
    Find the name of the composite you want to extend (e.g., `mainToolbar`).

2. Create the injection directory:
    In your module, follow this path structure:
    `src/my_module/@alias/uiComposites/[composite_name]/[priority]_[item_name]/`

    - `[priority]`: A number (e.g., `100`, `500`) to control order. Lower numbers appear first.
    - `[item_name]`: A descriptive name (e.g., `save_button`).

3. Add your component:
    Create an `index.tsx` file inside this folder.
    Export your React component as **default**.

    ```tsx
    export default function SaveButton() {
        return <button>Save</button>;
    }
    ```

4. Verify:
    The component should now appear automatically in the target composite area, respecting the numeric order.
