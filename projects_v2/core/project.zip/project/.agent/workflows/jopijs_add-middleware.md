---
description: Add global or route-specific middlewares to JopiJS
---

// turbo-all
1. **Determine the Scope**:
   - **Global**: Applies to the whole app or a pattern of routes. Use `serverInit.ts`.
   - **Route-Specific**: Applies to a single page/route folder. Use `config.ts`.

### Option A: Global Middleware
2. Locate or create `src/mod_<your_module>/serverInit.ts`.
3. Export a default function receiving `JopiWebSiteBuilder`.
4. Use `configure_middlewares()` to add your logic.

   ```typescript
   import { JopiWebSiteBuilder } from "jopijs";

   export default async function(app: JopiWebSiteBuilder) {
       app.configure_middlewares()
           .add_middleware(
               undefined, // Apply to ALL HTTP methods (or "GET", "POST", etc.)
               async (req) => {
                   console.log(`Intercepted: ${req.url}`);
                   // Return a Response to stop execution, or null to continue
                   return null; 
               },
               {
                   // Optional: Restrict to specific paths
                   routeSelector: {
                       fromPath: "/api",
                       exclude: ["/api/public"]
                   }
               }
           );
   }
   ```

### Option B: Route-Specific Middleware
2. Open the `config.ts` file in your route folder (e.g., `src/mod_main/@routes/dashboard/config.ts`).
3. Add middleware to specific method hooks.

   ```typescript
   import { JopiRouteConfig } from "jopijs";

   export default function(config: JopiRouteConfig) {
       // Runs for ALL methods on this route
       config.onALL.add_middleware(async (req) => {
           if (!req.headers.get("X-Custom-Auth")) {
               return new Response("Unauthorized", { status: 401 });
           }
       });

       // Runs only for POST
       config.onPOST.add_middleware(async (req) => {
           // ... logic
       });
   }
   ```
