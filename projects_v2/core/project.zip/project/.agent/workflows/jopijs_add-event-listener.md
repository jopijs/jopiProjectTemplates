---
description: Create a new static event listener to react to system events
---

1. Identify the event:
    Find the event name you want to listen to (e.g., `user.login`, `cart.product_added`).
    This corresponds to a folder in `@alias/events/[event_name]`.

2. Create the listener directory:
    In your module, create a folder path following this structure:
    `src/my_module/@alias/events/[event_name]/[priority]_[action_name]/`

    - `[priority]`: A number (e.g., `100`, `200`) to determine execution order.
    - `[action_name]`: A descriptive name for what your listener does (e.g., `log_analytics`, `show_toast`).

3. Implement the listener logic:
    Create an `index.ts` (or `.tsx`) file in your new folder.
    Export a default function that receives the event data.
    
    **Accessing JopiUiApplication (`this` context):**
    The `this` context of the listener is bound to the `JopiUiApplication` instance.
    You can use TypeScript `this` typing or casting to access it.

    ```typescript
    import { JopiUiApplication } from "jopijs/ui";
    
    // Option 1: Function signature typing (Recommended)
    export default function(this: JopiUiApplication, data: any) {
        const app = this;
        console.log("App instance:", app);
    }

    // Option 2: Casting
    export default function(data: any) {
        const app = this as JopiUiApplication;
        // ...
    }
    ```
