---
description: How to read/get a cookie in JopiJS (API & UI)
---

This workflow explains how to read cookies in JopiJS. There are two contexts: **API Routes** (Server) and **React Components** (UI).

### 1. In API Routes (Server-Side)

When working in an API route (e.g., `onGET.ts`, `onPOST.ts`), use the `JopiRequest` object methods.

**File:** `src/[module]/@routes/[path]/onGET.ts`

```typescript
import { JopiRequest } from "jopijs";

export default async function(req: JopiRequest) {
    // Read a cookie named "auth_token"
    const token = req.cookie_getReqCookie("auth_token");

    if (!token) {
        // Handle missing cookie
    }

    return req.res_jsonResponse({ token });
}
```

### 2. In React Components (UI / Isomorphic)

When working in a Page or Component, use the `getCookieValue` utility from `jopijs/ui`. This works both on the server (during SSR) and in the browser.

**File:** `src/[module]/@routes/[path]/page.tsx`

```tsx
import { getCookieValue, useStaticEffect } from "jopijs/ui";
import { useState } from "react";

export default function MyPage() {
    const [theme, setTheme] = useState("light");

    // useStaticEffect runs on the server (SSR) AND the client
    useStaticEffect(() => {
        const savedTheme = getCookieValue("theme");
        if (savedTheme) {
            setTheme(savedTheme);
        }
    }, []);

    return (
        <div>Current Theme: {theme}</div>
    );
}
```

**Important:** Always use `useStaticEffect` (or `useEffect` if client-only) to read cookies that affect the initial render to ensure consistency between server and client states, or to handle hydration correctly.
