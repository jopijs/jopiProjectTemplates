---
description: Create a visual menu component (Sidebar, Header) that consumes the automatic menu data
---

1. Install the dependency (if needed):
    Ensure `@jopijs/jopimod_menu` is installed.

2. Create the component:
    Create a React component (e.g., `src/mod_layout/@alias/ui/Sidebar/index.tsx`).

3. Import the hooks:
    ```typescript
    import useMenu from "@hooks/jopijs.menu.useMenu";
    import MenuNames from "@/lib/jopijs.menu.MenuNames";
    ```

4. Fetch the data:
    Use the hook to get the hierarchical tree of items for the desired menu (Left or Top).
    ```typescript
    const menuItems = useMenu(MenuNames.LEFT_MENU); // or MenuNames.TOP_MENU
    ```

5. Render recursively:
    Iterate over `menuItems` to render links. Handle the `items` property for submenus.

    ```tsx
    import useLanguage from "@/hooks/jopijs.lang.useLanguage";

    // Inside component:
    const [lang] = useLanguage();

    <ul>
      {menuItems.map(item => {
         // Resolve translation if available
         const title = item.translations?.[lang] || item.title;

         return (
            <li key={item.key} className={item.isActive ? 'active' : ''}>
               <a href={item.url}>{title}</a>
               {/* Check item.items for submenus */}
            </li>
         )
      })}
    </ul>
    ```