---
description: How to get user informations in React and Server side
---

# How to get user informations

## In React (Client Side & SSR)

You can use the `useUserGetInfos` hook to retrieve current user information.
It returns `undefined` if the user is not logged in.

```typescript
import useUserGetInfos from "@/hooks/jopijs.user.useGetInfos";

export default function MyComponent() {
    const userInfos = useUserGetInfos();

    if (!userInfos) {
        return <div>Not logged in</div>;
    }

    return (
        <div>
            Hello {userInfos.name} ({userInfos.id})
        </div>
    );
}
```

## In Server (API Routes)

In your API routes (e.g. `onGET.ts`, `onPOST.ts`), you can use the `user_getInfos` method from the request object.

```typescript
import { JopiRequest } from "jopijs";
import IUserInfos from "@/lib/jopijs.auth.IUserInfos";

export default async function (req: JopiRequest) {
    // Retrieve user infos from the session/cookie
    const userInfos = await req.user_getInfos<IUserInfos>();

    if (!userInfos) {
        return req.res_jsonResponse({ error: "Unauthorized" }, 401);
    }

    return req.res_jsonResponse({
        message: `Hello ${userInfos.name}`,
        userId: userInfos.id
    });
}
```
