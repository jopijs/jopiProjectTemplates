---
description: Listen to JopiJS events (UI side) using the programmatic API
---

# listening to events in UI (React Component Context)

When importing an event in the UI side (e.g. `import eventSomething from "@/events/something"`), the object provides a `.reactListener()` method.

## Usage in React Components

Use `reactListener` to subscribe. It handles automatic cleanup when the component unmounts.

```tsx
import eventSomething from "@/events/something";

export default function MyComponent() {
    eventSomething.reactListener((data) => {
        console.log("data", data);
    });

    return <div>...</div>;
}
```

## Non-React Context (Global Listeners)

**CRITICAL RULE**: `.reactListener()` is designed primarily for React components. 

If you need a global listener (e.g. in `uiInit.tsx`), you **SHOULD PREFER** using the Static Listener system (creating a file in `@alias/events/...`).

**HOWEVER**, if you must use programmatic listening in global initialization:
1. You CAN use `.reactListener()` but be aware it never unmounts.
2. OR, if the API supports it, use `.listen()` (but double check availability).

**For strict JopiJS compliance**:
- **Inside React Components**: Use `.reactListener()`.
- **Outside Components (Global)**: Create a static listener via file system: `src/mod_name/@alias/events/event.name/100_listenerName/index.ts`.

DO NOT mix them up unless necessary.
