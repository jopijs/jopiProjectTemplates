---
description: Manage route metadata (Caching, Roles, Priority) using Marker Files
---

// turbo-all
1. Identify the folder you want to configure (Route, Component, or Module root).
2. Create an **empty file** with the specific name to apply the rule.

### Security / Roles (Routes)
- **`needRole_[roleName].cond`**: Global protection (Page + API).
  - Example: `needRole_admin.cond` -> Requires 'admin' role.
- **`getNeedRole_[roleName].cond`**: Only protects GET requests (Page).
- **`postNeedRole_[roleName].cond`**: Only protects POST requests (API).

### Caching (Routes)
- **`autoCache.disable`**: Completely disables HTML caching for this route.
- **`autoCache.enable`**: Forces caching implementation (default).

### Priority & Overrides
- **`high.priority`**: Use this version instead of the default one.
- **`veryHigh.priority`**: Use this version (Hotfix/Emergency).
- **`verylow.priority`**: Use this only if no other version exists (Fallback).

### Other API Markers
- **`cors.enable`**: Enables CORS for this API route.

### Example Structure
```text
src/mod_admin/@routes/dashboard/
├── page.tsx
├── needRole_admin.cond    # Protects this entire folder
└── autoCache.disable      # Real-time data, do not cache
```
