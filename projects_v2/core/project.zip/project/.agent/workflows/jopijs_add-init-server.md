---
description: Add a Server initializer to a JopiJS module
---

// turbo-all
1. Identify the target module (e.g., `src/mod_main`).
2. Create a file `src/mod_<module_name>/serverInit.ts`.
3. Use this file to run code **only** on the server startup (before the first request is served).
4. **Requirement**: The file **MUST** export a default async function.
5. Template:
   ```typescript
   import { JopiWebSiteBuilder } from "jopijs";

   export default async function(webSite: JopiWebSiteBuilder) {
       console.log("Module Server Initialized");
   }
   ```
