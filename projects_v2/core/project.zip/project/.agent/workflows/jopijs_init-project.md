---
description: Initialize a new JopiJS project
---

// turbo-all
1. Choose or create a directory for your project.
2. Run the initialization command:
   ```bash
   npx jopi init --template minimal --dir .
   ```
3. Install dependencies (recommended using `bun`):
   ```bash
   bun install
   ```
4. The project is now ready for development. Use `bun run start` to begin.