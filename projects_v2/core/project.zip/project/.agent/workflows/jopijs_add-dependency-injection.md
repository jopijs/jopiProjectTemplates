---
description: Share global services (classes, stores) across modules using Dependency Injection
---

// turbo-all
1. **Define the Service**: Create your class/service in `@alias/lib`.
   - Example: `src/mod_shop/@alias/lib/shop.cartService/index.ts`

2. **Register the Service**:
   - Create or open `src/mod_shop/uiInit.tsx`.
   - Use `uiApp.valueStore.addValueProvider` to register the factory.

   ```typescript
   import { JopiUiApplication } from "jopijs/ui";
   import CartService from "@/lib/shop.cartService";

   export default function(uiApp: JopiUiApplication) {
       // Register with a unique key.
       // The factory function is lazy-evaluated (called only when needed).
       uiApp.valueStore.addValueProvider("shop.cartService", () => {
           return new CartService();
       });
   }
   ```

3. **Consume the Service (React)**:
   - Use `useStoreValue` for reactive updates (re-renders on change).

   ```typescript
   // In a component
   import { useStoreValue } from "jopijs/ui";
   import type CartService from "@/lib/shop.cartService"; // Type-only import!

   export function CartWidget() {
       const [cartService] = useStoreValue<CartService>("shop.cartService");

       if (!cartService) return null;

       return <div>Items: {cartService.count}</div>;
   }
   ```

4. **Trigger Updates**:
   - Inside your service, when data changes, you might want to notify components.
   - If using `valueStore`, simply calling `setValue` on the store triggers React updates.
   - *Advanced*: Your service can hold its own state and methods.