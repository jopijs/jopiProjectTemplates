---
description: Rule and guide for overriding pages and API routes
---

# Rule: Route Overrides (Pages & APIs)

**Rule**: To replace a page (`page.tsx`) or API handler (`onGET.ts`, etc.) from another module, you MUST replicate its route structure and include a `high.priority` marker file.

## Why?
JopiJS merges routes from all modules. If two modules define the same handler (e.g., both have `page.tsx` for `/home`), conflicts are resolved using the Priority System. The module with specific priority markers wins.

## Implementation Steps

1. **Locate Target**: Find the route path in the original module (e.g., `src/mod_original/@routes/product/[id]`).
2. **Replicate Path**: Create the same structure in your module (e.g., `src/mod_yours/@routes/product/[id]`).
3. **Add Priority**: Create an empty file named `high.priority` in that folder.
   - `touch src/mod_yours/@routes/product/[id]/high.priority`
4. **Implement**: Create your `page.tsx`, `onGET.ts`, etc.
   - The new file will completely replace the original handler.

## Important Notes
- **Metadata Inheritance**: The "winning" route folder dictates the security and cache settings. If the original route had `needRole_admin.cond`, you likely want to copy that marker file to your override folder too, unless you intend to remove the protection.
- **Partial Overrides**: You can add `onPOST.ts` to a route that only had `page.tsx` without needing `high.priority`, because they don't conflict. Priority is only needed when replacing an *existing* handler.
