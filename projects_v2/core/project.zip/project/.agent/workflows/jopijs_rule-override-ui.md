---
description: Rule and guide for overriding UI components
---

# Rule: UI Component Overrides

**Rule**: To replace or customize a UI component from another module, you MUST replicate its path structure in your module and include a `high.priority` marker file.

## Why?
JopiJS resolves `@/ui/...` imports dynamically. If multiple modules provide the same component, the one with `high.priority` (or the alphabetically last module) applies. Using `high.priority` ensures your override is always selected.

## Implementation Steps

1. **Locate Target**: Find the path of the component to override (e.g., `src/mod_original/@alias/ui/Button`).
2. **Replicate Path**: Create the same structure in your module (e.g., `src/mod_yours/@alias/ui/Button`).
3. **Add Priority**: Create an empty file named `high.priority` in that folder.
   - `touch src/mod_yours/@alias/ui/Button/high.priority`
4. **Implement**: Create your `index.tsx` (and `style.module.css`).

## Style-Only Override
To change the look without changing logic:
1. Replicate path in `@alias/styles` instead of `@alias/ui`.
   - Ex: `src/mod_yours/@alias/styles/ui/Button/style.module.css`
2. No `high.priority` needed for styles (styles merge/override by CSS rules, but Jopi will inject the custom style file).
