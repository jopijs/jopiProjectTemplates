---
description: Create a cached Object Provider (Entity Provider) for sharing data between modules
---

// turbo-all
1. **Identify the Data Entity**: (e.g., `shop.product`, `blog.post`).

2. **Create the Provider Folder**:
   - Path: `src/mod_<module>/@alias/objectProviders/<entity_name>/`
   - Example: `src/mod_shop/@alias/objectProviders/shop.product/`

3. **Implement the Logic**:
   - Create `index.ts` inside the folder.
   - Export an object implementing `ObjectProvider`.

   ```typescript
   import { db } from "@/lib/db";
   import type { ObjectProvider } from "jopijs";

   // ID argument (string or number)
   export default <ObjectProvider>{
       async getValue(id?: string | number) {
           if (!id) return undefined;

           // Fetch data (DB, API, etc.)
           const data = await db.query("SELECT * FROM products WHERE id = ?", [id]);

           // MUST return an object with a 'value' property
           return {
               value: data
           };
       }
   };
   ```

4. **Consume the Provider**:
   - Import using the alias `@/objectProviders/name`.

   ```typescript
   import shopProduct from "@/objectProviders/shop.product";

   export async function someLogic() {
       // 1. Get value (Auto-cached)
       const product = await shopProduct.getValue("123");

       // 2. Refresh (Force fetch)
       await shopProduct.refreshValue("123");

       // 3. Delete from cache only
       await shopProduct.removeFromCache("123");

       // 4. Delete from both cache AND source (if implemented)
       await shopProduct.deleteValue("123");
   }
   ```
