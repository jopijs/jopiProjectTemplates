---
description: Create isomorphic functions with separate Server and Browser implementations
---

// turbo-all
1. **Identify the Logic**: You have a function (e.g., `getPlatformInfo`) that needs to behave differently on Server (Node/Bun) vs Browser.

2. **Create the Browser Version**:
   - Filename must end with `.jBundler_ifBrowser.ts`.
   - Example: `src/mod_utils/@alias/lib/platform/info.jBundler_ifBrowser.ts`

   ```typescript
   export function getPlatformInfo() {
       return `Browser: ${navigator.userAgent}`;
   }
   ```

3. **Create the Server Version**:
   - Filename must end with `.jBundler_ifServer.ts`.
   - Example: `src/mod_utils/@alias/lib/platform/info.jBundler_ifServer.ts`

   ```typescript
   import os from "os";

   export function getPlatformInfo() {
       return `Server: ${os.hostname()}`;
   }
   ```

4. **Create the Public Export**:
   - Create standard `index.ts` that exports one of them (usually the server one, as a reference).
   - *Note*: JopiJS bundler relies on the filenames to swap the implementation at build time.

   ```typescript
   // src/mod_utils/@alias/lib/platform/index.ts
   export * from "./info.jBundler_ifServer"; 
   ```

5. **Use Usage**:
   - `import { getPlatformInfo } from "@/lib/platform";`
   - It will automatically call the correct version depending on the environment.
