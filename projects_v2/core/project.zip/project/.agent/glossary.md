# JopiJS Glossary

## Key Concepts

### Module (`mod_*`)
A self-contained unit of functionality located in the `src/` directory. A module can contain pages, components, logic, and resources. By convention, module folders are prefixed with `mod_`.
*   **Example:** `src/mod_user_auth`

### Alias (`@alias`)
A special directory within a module that exposes its content to the rest of the application. Everything inside `@alias` is accessible via virtual paths (e.g., `@/ui`, `@/lib`, `@/res`).
- **Atomic Sharing**: JopiJS shares elements one by one.
- **Structure**: Each shared item must have its own folder with an `index.ts/tsx` and a `export default`.
- **Replacement**: This structure allows the priority system to replace or extend items at the folder level.

### Virtual Path (`@/...`)
An import path that doesn't point to a specific file on disk but to a "virtual" resource resolved by JopiJS based on priority.
*   **`@/ui/...`**: For React components.
*   **`@/lib/...`**: For business logic (functions, classes).
*   **`@/res/...`**: For static resources (images, JSON).
*   **`@/events/...`**: For event definitions.

### Priority System
The mechanism JopiJS uses to resolve conflicts when multiple modules provide the same item (same virtual path). The item with the highest priority "wins".
*   **Hierarchy:**
    1.  `veryHigh.priority` (Hotfixes)
    2.  `high.priority` (Overrides)
    3.  `default.priority` (Standard)
    4.  `low.priority` (Base features)
    5.  `verylow.priority` (Fallbacks)

### Override (Replacement)
The act of providing a version of a component or logic with a higher priority than the existing one, effectively replacing it across the entire application without changing the original code.

### Merge (`.merge`)
Instead of replacing, "Merge" combines multiple definitions.
*   **`class.merge`**: Creates an inheritance chain where the high-priority class extends the lower-priority one.
*   **`interface.merge`**: Combines TypeScript interface definitions.
*   **Events**: Listeners are always merged (executed in sequence).
*   **Translations**: Translation keys are merged.
*   **UI Composites**: Components from different modules are collected and rendered in order.

### UI Composite
An extensible global React component (e.g., `<MainToolbar />`) composed of smaller components contributed by multiple modules.

### Event System
A decoupled communication system where modules "emit" messages and others "listen".
*   **Static Listener**: A function in a numbered folder (e.g., `100_log`) that runs automatically when an event is emitted.
*   **React Listener**: A listener attached within a component lifecycle using `.reactListener()`.

## Directory Structure Terms

### `@routes`
Directory inside a module for defining pages (Next.js style file-system routing).

### `@alias/ui`
Directory for shared React components. Repleacable by default.

### `@alias/uiComposites`
Directory for extensible UI areas (Toolbars, Menus). Merged by default. Sub-folders use numeric prefixes for ordering.

### `@alias/lib`
Directory for shared business logic (functions, classes). Replaceable by default (unless marked with `.merge`).

### `@alias/res`
Directory for static assets. Replaceable by default.
