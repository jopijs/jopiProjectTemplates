# JopiJS Glossary

## Key Concepts

### Module (`mod_*`)
A self-contained unit of functionality located in the `src/` directory. A module can contain pages, components, logic, and resources. By convention, module folders are prefixed with `mod_`.
*   **Example:** `src/mod_user_auth`

### Alias (`@alias`)
A special directory within a module that exposes its content to the rest of the application. Everything inside `@alias` is accessible via virtual paths (e.g., `@/ui`, `@/lib`, `@/res`).
- **Atomic Sharing**: JopiJS shares elements one by one.
- **Structure**: Each shared item must have its own folder with an `index.ts/tsx` and a `export default`.
- **Replacement**: This structure allows the priority system to replace or extend items at the folder level.

### Virtual Path (`@/...`)
An import path that doesn't point to a specific file on disk but to a "virtual" resource resolved by JopiJS based on priority.
*   **`@/ui/...`**: For React components.
*   **`@/lib/...`**: For business logic (functions, classes).
*   **`@/res/...`**: For static resources (images, JSON).
*   **`@/events/...`**: For event definitions.
*   **`@/uiComposites/...`**: For extensible UI areas.

### Priority System
The mechanism JopiJS uses to resolve conflicts when multiple modules provide the same item (same virtual path). The item with the highest priority "wins".
*   **Hierarchy:**
    1.  `veryHigh.priority` (Hotfixes)
    2.  `high.priority` (Overrides)
    3.  `default.priority` (Standard)
    4.  `low.priority` (Base features)
    5.  `verylow.priority` (Fallbacks)

### Override (Replacement)
The act of providing a version of a component or logic with a higher priority than the existing one, effectively replacing it across the entire application without changing the original code.

### Merge (`.merge`)
Instead of replacing, "Merge" combines multiple definitions.
*   **Events**: Listeners are always merged (executed in sequence).
*   **Translations**: Translation keys are merged.
*   **UI Composites**: Components from different modules are collected and rendered in order.

### UI Composite
An extensible global React component (e.g., `<MainToolbar />`) composed of smaller components contributed by multiple modules.

### Event System
A decoupled communication system where modules "emit" messages and others "listen".
*   **Static Listener**: A function in a numbered folder (e.g., `100_log`) that runs automatically when an event is emitted.
*   **React Listener**: A listener attached within a component lifecycle using `.reactListener()`.

### Dependency Injection (ValueStore)
A system to share global singleton objects (services, controllers) across modules without hard dependencies.
*   **Register**: In `uiInit.tsx` using `uiApp.valueStore.addValueProvider`.
*   **Consume**: Using `uiApp.valueStore.getValue` or `useStoreValue` (reactive).

### Isomorphic Component
A React component capable of running both on the Server (SSR) and in the Browser. It must handle hydration and avoid accessing browser-specific APIs (like `window`) during the server render phase.

## Caching & Data

### HTML Cache
The static HTML output of a page. JopiJS serves this instantly. Can be bypassed using `autoCache.disable` or hooks like `htmlCache_beforeCheckingCache`.

### Page Data Cache (SWR)
A system where data is fetched on the server (`getDataForCache`), embedded in the HTML, and then "Refreshed" in the background by the browser (`getRefreshedData`).
*   **Benefit**: Allows showing stale data instantly while fetching only the "delta" (changes like price/stock) in the background.

### Seed
Data passed from the server to the browser to identify what content was rendered. Used by the browser to request updates for that specific content.

## Directory Structure Terms

### `@routes`
Directory inside a module for defining pages (file-system routing).
*   **`page.tsx`**: The UI (React component).
*   **`onGET.ts` / `onPOST.ts`**: API Handlers.
*   **`config.ts`**: Route configuration (menus, cache hooks, middleware).
*   **`pageData.ts`**: Data provider for the page.

### Marker Files
Empty files used to configure a route declaratively.
*   **`autoCache.enable / .disable`**: Control HTML caching.
*   **`needRole_[role].cond`**: Global route protection.
*   **`postNeedRole_[role].cond`**: Protects only the POST method.
*   **`high.priority`**: Sets the priority of the folder.

### `@alias/ui`
Directory for shared React components. Repleacable by default.

### `@alias/uiComposites`
Directory for extensible UI areas (Toolbars, Menus). Merged by default. Sub-folders use numeric prefixes for ordering.

### `@alias/lib`
Directory for shared business logic (functions, classes). Replaceable by default.

### `@alias/res`
Directory for static assets. Replaceable by default.
