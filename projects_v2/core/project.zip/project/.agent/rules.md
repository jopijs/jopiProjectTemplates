# General Rules

- Always use **English** for coding, comments, and documentation.
- Always prefix interface names with "**I**" (e.g., `interface IUserService {}`).
- Always use the suffix "**Props**" for interfaces defining React component properties (e.g., `interface IButtonProps {}`).
- Always use the suffix "**Params**" for interfaces defining function parameters (e.g., `interface ILoginParams {}`).
- Always use **`export default`** for elements shared via `@alias/` (`ui`, `lib`, `res`, etc.).
- Always share elements **one by one**: each shared item MUST have its own dedicated folder containing an `index.ts` (or `.tsx`) with a default export.
- Always use **numeric prefixes** (e.g., `100_itemName`) for sub-folders in `@alias/uiComposites/` and `@alias/events/` to control execution/display order.
- Always use **UI Composites** (`@alias/uiComposites/`) for container components like **Toolbars, Sidebars, Menus, or Dashboards** that might need to be extended by other modules. Do not build them as rigid static components.
- Always use **`config.ts`** inside the route folder when adding a page into a menu. It MUST export a **default function** receiving `config: JopiRouteConfig` (import from `jopijs`). Example: `export default function(config: JopiRouteConfig) { config.menu_addToLeftMenu(["Label"]); }`.
- Always use **`npx jopi shadcn-add [name] --mod [module]`** to install ShadCN components. NEVER use the default `shadcn` CLI or `v0` commands which are not compatible with JopiJS modular structure.
- Always identify **modules** by scanning the `/src` directory for folders starting with "**mod_**" if you need to list them manually.
- Always use **CSS Modules** with the generated wrapper: Import `styles` from `./style.gen.ts` and use the hook `useCssModule(styles)`. NEVER import `.css` files directly in components.
- Always use **Isomorphic Extensions** (`.jBundler_ifServer.ts` and `.jBundler_ifBrowser.ts`) to provide environment-specific implementations of a function or class.
- Always protect **SSR** by NEVER accessing `window` or `document` at the top level of a component. Use `useEffect` or check `if (typeof window !== "undefined")` inside functions.
- Always use **`autoCache.disable`** (empty marker file) in a route folder if you need to completely disable the automatic caching for that route.
- Always use **`useStaticEffect`** instead of `useEffect` when you need to read Cookies or Headers during the initial render. This hook runs on **both** Server (SSR) and Browser, ensuring the initial state is correct and preventing hydration mismatches.
- Always use **`import ... from '@/...'`** when importing shared elements. Never import directly from the `@alias/` folder using relative paths or direct `@alias` references. (Example: `import CategoryList from '../../@alias/ui/page.plants.CategoryList';` becomes `import CategoryList from '@/ui/page.plants.CategoryList';`).
- Always use **JopiJS Cookie System** (`req.cookie_*` in API, `jopijs/ui` utilities in Components) for handling cookies. **NEVER** use `document.cookie` directly, as it does not work on the server side (SSR) and breaks hydration.
- Always use **Image Imports**: Do not use direct URLs (string paths) in `img` src or `backgroundImage`. Instead, import the image file (`import myImg from "./myImg.png"`) and use the imported variable. This ensures assets are correctly bundled and hashed.
- Always share **ONLY important resources** (e.g., the logo) via `@alias/res`. For component-specific resources, use **local imports**.
- Always restrict folders in `@alias/` to the following allowed list: `ui`, `lib`, `res`, `translations`, `events`, `uiComposites`, `hooks`, `styles`. NO other folder types should be created in `@alias`.
- Always share components in `@alias/ui` **ONLY** if it is important to do so. In this case, use a **descriptive name** (e.g., `shop.product` instead of just `product`).

- Always remember that files containing **`jBundler_ifServer`** in their name are **automatically replaced** by their **`jBundler_ifBrowser`** counterpart (if it exists) when generating the browser bundle. This allows seamless environment-specific logic.
