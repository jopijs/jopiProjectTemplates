# General Rules

- Always use **English** for coding, comments, and documentation.
- Always prefix interface names with "**I**" (e.g., `interface IUserService {}`).
- Always use the suffix "**Props**" for interfaces defining React component properties (e.g., `interface IButtonProps {}`).
- Always use the suffix "**Params**" for interfaces defining function parameters (e.g., `interface ILoginParams {}`).
- Always use **`export default`** for elements shared via `@alias/` (`ui`, `lib`, `res`, etc.).
- Always share elements **one by one**: each shared item MUST have its own dedicated folder containing an `index.ts` (or `.tsx`) with a default export.
- Always use **numeric prefixes** (e.g., `100_itemName`) for sub-folders in `@alias/uiComposites/` and `@alias/events/` to control execution/display order.
- Always use **UI Composites** (`@alias/uiComposites/`) for container components like **Toolbars, Sidebars, Menus, or Dashboards** that might need to be extended by other modules. Do not build them as rigid static components.
- Always use **`config.ts`** inside the route folder when configuring a route (menus, cache, middleware). Use the default export function pattern: `export default function(config: JopiRouteConfig) { ... }`.
- Always use **`npx jopi shadcn-add [name] --mod [module]`** to install ShadCN components. NEVER use the default `shadcn` CLI.
- Always identify **modules** by scanning the `/src` directory for folders starting with "**mod_**".
- Always use **CSS Modules** with the generated wrapper: Import `styles` from `./style.gen.ts` and use the hook `useCssModule(styles)`. This enables the **theming system**. NEVER import `.css` files directly in components.
- Always use **Isomorphic Extensions** (`.jBundler_ifServer.ts` and `.jBundler_ifBrowser.ts`) to provide environment-specific implementations of a function or class.
- Always protect **SSR** by NEVER accessing `window` or `document` at the top level of a component. Use `useEffect`, `useStaticEffect`, or check `if (typeof window !== "undefined")`.
- Always use **`autoCache.disable`** (empty marker file) in a route folder if you need to completely disable the automatic caching for that route.
- Always use **`useStaticEffect`** instead of `useEffect` when you need to read Cookies or Headers during the initial render. This hook runs on **both** Server (SSR) and Browser.
- Always use **`import ... from '@/...'`** when importing shared elements. Never import directly from the `@alias/` folder using relative paths.
- Always use **JopiJS Cookie System** (`req.cookie_*` in API, `useStaticEffect` + `jopijs/ui` utilities in Components). **NEVER** use `document.cookie` directly.
- Always use **Image Imports**: Do not use direct URLs in `img` src. Import the image file (`import myImg from "./myImg.png"`) and use the variable.
- Always share **ONLY important resources** (e.g., the logo) via `@alias/res`. For component-specific resources, use **local imports**.
- Always restrict folders in `@alias/` to the following allowed list: `ui`, `lib`, `res`, `translations`, `events`, `uiComposites`, `hooks`, `styles`.
- Always share components in `@alias/ui` **ONLY** if it is important to do so. In this case, use a **descriptive name** (e.g., `shop.product` instead of just `product`).

## Strict Coding Rules

- **UI Data Access**: In UI components (`page.tsx`, etc.), **NEVER** import or use `dataProviders` directly. Data fetching logic must reside in a `server.ts` file, exposed via `pageData.ts` (using `getDataForCache`), and consumed in the UI using the `usePageData()` hook. This ensures proper separation of concerns and server-side optimization.

## Data & Logic Rules

- Always register **Global Services (ValueStore)** in a **`uiInit.tsx`** file within your module. Use `uiApp.valueStore.addValueProvider`.
- Always use **`pageData.ts`** located next to `page.tsx` for fetching page data. This enables the **Page Data Cache** (SWR) architecture.
- Always implement **`getDataForCache`** (Server) and **`getRefreshedData`** (Browser/Background) in `pageData.ts`.
- Always use **`itemKey`** in `getRefreshedData` return object to enable automatic **List Merging** in the UI.
- Always use **`onGET.ts`** or **`onPOST.ts`** to define API endpoints. Do not use Next.js style `route.ts`.
- Always use **Marker Files** (e.g., `needRole_admin.cond`) to protect routes. Do not rely solely on code checks.
- Always use **Type-Only Imports** (`import type ...`) when consuming objects from the ValueStore to avoid bundling unnecessary code.

## Cache Rules

- Always use **`req.htmlCache_removeFromCache()`** to invalidate cache when data changes.
- Always use **`htmlCache_beforeCheckingCache`** hook in `config.ts` if you need to bypass cache for specific users (e.g. admins).
