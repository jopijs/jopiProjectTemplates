import res from '../../../userList.json';
export default res;