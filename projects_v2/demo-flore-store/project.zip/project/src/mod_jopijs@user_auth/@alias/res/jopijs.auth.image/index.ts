import res from '../../../logo.png';
export default res;