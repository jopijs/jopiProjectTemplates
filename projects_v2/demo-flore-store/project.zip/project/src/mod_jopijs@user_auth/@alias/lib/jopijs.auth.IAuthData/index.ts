/**
 * The data needed to authenticate a user.
 * Is what the browser sends to the server.
 *
 * You can replace this interface with another one.
 * But if you do that, you must also change `jopijs.auth.checkAuthData`.
 */
interface IAuthData {
    login: string;
    password: string;
}

export default IAuthData;