import IAuthData from "@/lib/jopijs.auth.IAuthData";
import IUserInfos from "@/lib/jopijs.auth.IUserInfos";

interface UserEntry {
    authInfos: IAuthData;
    userInfos: IUserInfos;
}

export default UserEntry;