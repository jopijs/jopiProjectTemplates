import IUserInfos from "@/lib/jopijs.auth.IUserInfos";
import UserEntry from "@/lib/jopijs.auth.IUserEntry";
import IAuthData from "@/lib/jopijs.auth.IAuthData";
import CoreAuthController from "@/lib/jopijs.auth.CoreAuthController";
import userList from "@/res/jopijs.auth.userList";

export default class AuthController extends CoreAuthController {
    constructor() {
        super();
    }

    //@override    
    async addUser(newUserInfos: Omit<IUserInfos, "id">): Promise<UserEntry | undefined> {
        let newUser: UserEntry = {
            authInfos: {
                login: newUserInfos.login,
                password: newUserInfos.password,
            },
            userInfos: {
                // Here you should check and clean the data.
                ...newUserInfos,
                id: newUserInfos.login
            }
        };

        (userList as UserEntry[]).push(newUser);

        return newUser;
    }

    //@override    
    async checkAuthData(fromBDD: IAuthData, fromBrowser: IAuthData): Promise<boolean> {
        return fromBDD.password===fromBrowser.password;
    }

    //@override    
    async findUser(loginInfo: IAuthData): Promise<UserEntry | undefined> {
        return (userList as UserEntry[]).find(e => e.authInfos.login===loginInfo.login);
    }
}