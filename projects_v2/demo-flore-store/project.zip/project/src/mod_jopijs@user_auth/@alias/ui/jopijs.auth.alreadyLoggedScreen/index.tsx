import trProvider from "@/translations/page.login";
import IUserInfos from "@/lib/jopijs.auth.IUserInfos";

// Get the translation.
// Fallback to the default one if not found.
//
const tr = trProvider();

interface MyProps  {
    user: IUserInfos;
    doLogOutUser: () => void;
}

export default function({user, doLogOutUser}: MyProps) {
    return <div className="w-full flex flex-col items-center justify-center mt-20">
        <div>{tr.alreadyLoggedInAs({name: user.userFullName})}</div>
    <div onClick={doLogOutUser}
         className="mt-8 w-full h-11 rounded-full text-white bg-indigo-500 hover:opacity-90 transition-opacity
                flex items-center justify-center cursor-pointer">
        Logout
    </div>
</div>;
};