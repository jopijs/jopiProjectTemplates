import React from "react";
import trProvider from "@/translations/page.login";
import useLanguage from "@/hooks/jopijs.lang.useLanguage";

import defaultLoginPassword from "@/res/jopijs.auth.defaultLoginPassword";



interface MyProps {
    isAuhFailed?: boolean;
    errorCode?: string | null;
    isSuccess?: boolean;
    onSubmitForm: (e: React.FormEvent<HTMLFormElement>) => void;
}

export default function({isAuhFailed, errorCode, isSuccess, onSubmitForm}: MyProps) {
    const defaultLogin = (defaultLoginPassword as any).login;
    const defaultPassword = (defaultLoginPassword as any).password;
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    // Determine the error message
    let errorMessage = null;
    if (errorCode === "USER_ALREADY_EXISTS") {
        errorMessage = tr.userAlreadyExists();
    } else if (errorCode === "CANNOT_CREATE_USER") {
        errorMessage = tr.cannotCreateUser();
    } else if (isAuhFailed) {
        errorMessage = tr.registrationFailed();
    }

    if (isSuccess) {
         return (
            <div style={{padding: 20}}>
                <h2>{tr.accountCreated()}</h2>
                <a href="/login">{tr.logIn()}</a>
            </div>
        );
    }

    return (
        <div style={{padding: 20}}>
            <form onSubmit={(e) => onSubmitForm(e)}>
                <div style={{marginBottom: 10}}>
                    <input 
                        name="login" 
                        type="text" 
                        required 
                        defaultValue={defaultLogin} 
                        placeholder={tr.usernameOrEmailPlaceholder()}
                        style={{border: "1px solid black", padding: 5, display: "block", marginBottom: 5}}
                    />
                </div>

                <div style={{marginBottom: 10}}>
                    <input 
                        name="password" 
                        type="password" 
                        required 
                        defaultValue={defaultPassword} 
                        placeholder={tr.passwordPlaceholder()}
                        style={{border: "1px solid black", padding: 5, display: "block", marginBottom: 5}}
                    />
                </div>

                <button type="submit" style={{border: "1px solid black", padding: 5}}>
                    {tr.signUp()}
                </button>

                {errorMessage && (
                    <div style={{color: "red", marginTop: 10}}>
                        {errorMessage}
                    </div>
                )}
            </form>
        </div>
    );
};