import {type AuthResult, JopiWebSiteBuilder} from "jopijs";

import * as jk_term from "jopi-toolkit/jk_term";
import * as jk_tools from "jopi-toolkit/jk_tools";

import IAuthData from "@/lib/jopijs.auth.IAuthData";
import getAuthController from "@/lib/jopijs.auth.getAuthController";

// Here we will enable JWT and declare our users.
//
export default async function(webSite: JopiWebSiteBuilder) {
    let jwtSecretKey = process.env.JWT_SECRET_KEY;

    if (!jwtSecretKey) {
        jk_term.logBgRed(`JWT_SECRET_KEY environment variable is not set. ${jk_term.textBgBlue("Will use a random key instead")}.`);
        jwtSecretKey = jk_tools.generateUUIDv4();
    }

    // > Here we will configure 2 things:
    //
    // - An authentification mechanism allowing Jopi
    //      to identify users and know if they are logged-in.
    //
    // - A user store, in which we declare our user.
    //      Here it's a simple in-memory store, but it can
    //      easily be extended to a more complex one for your needs.
    //
    // To know: all this can be shortened with:
    //      fastConfigure_jwtTokenAuth("MY_SUPER_SECRET_KEY", users)
    //
    webSite.configure_jwtTokenAuth()
        .step_setPrivateKey(jwtSecretKey)

        // Second step: create the user store.
        .step_setUserStore()
            .use_customStore(userStore)

                .DONE_use_customStore()
            .DONE_setUserStore()
        .DONE_configure_jwtTokenAuth()
}

const gAuthController = getAuthController();

async function userStore(loginInfo: IAuthData): Promise<AuthResult> {
    let user = await gAuthController.findUser(loginInfo);
    if (!user) return {isOk: false, errorMessage: "Unknown user"};

    let isValid = await gAuthController.checkAuthData(user.authInfos, loginInfo);

    if (!isValid) {
        return {isOk: false, errorMessage: "Wrong password"};
    }

    return {isOk: true, userInfos: user.userInfos};
}