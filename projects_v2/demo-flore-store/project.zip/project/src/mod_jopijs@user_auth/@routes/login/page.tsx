import React from "react";

import useNavigate from "@/hooks/jopijs.page.useNavigate";
import useSearchParams from "@/hooks/jopijs.page.useSearchParams";
import useUserGetInfos from "@/hooks/jopijs.user.useGetInfos";
import useUserLogOut from "@/hooks/jopijs.user.useLogOut";
import useUserStateRefresh from "@/hooks/jopijs.user.useDeclareStateRefresh";
import useFormSubmit from "@/hooks/jopijs.form.useSubmit";

import LoginForm from "@/ui/jopijs.auth.loginForm";
import AlreadyLoggedScreen from "@/ui/jopijs.auth.alreadyLoggedScreen";

export default function() {
    const navigate = useNavigate();
    const searchParams = useSearchParams();
    
    // Handle returnUrl safely to avoid potential loops
    let returnUrl = searchParams.get('returnUrl') ? decodeURIComponent(searchParams.get('returnUrl')!) : '/';
    if (returnUrl === '' || returnUrl.includes('/login')) returnUrl = '/';

    const [isAuhFailed, setIsAuhFailed] = React.useState(false);

    const userInfos = useUserGetInfos();
    const logOutUser = useUserLogOut();
    const declareUserStateChange = useUserStateRefresh();

    const [submitForm, _] = useFormSubmit((res) => {
        if (res.isOk) {
            // We don't need to decode the result
            // since the only interesting thing here
            // is the cookie that is automatically set.
            //
            setIsAuhFailed(false);

            declareUserStateChange();
            navigate(returnUrl);
        } else {
            setIsAuhFailed(true);
        }
    });

    // Already connected when navigate to this page?
    // => Show the logout page.
    //
    if (userInfos) {
        return <AlreadyLoggedScreen user={userInfos} doLogOutUser={logOutUser} />
    }

    // Not connected?
    // => Show the login page.
    //
    return <LoginForm onSubmitForm={submitForm} isAuhFailed={isAuhFailed} />;
};