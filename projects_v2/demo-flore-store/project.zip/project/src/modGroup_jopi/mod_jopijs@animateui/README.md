# Animate UI Components

This module contains components from [Animate UI](https://animate-ui.com), ported to JopiJS.

## Components List

- [x] animateui.Accordion
- [x] animateui.AlertDialog
- [x] animateui.Button
- [x] animateui.Checkbox
- [x] animateui.Dialog
- [x] animateui.DropdownMenu
- [x] animateui.HoverCard
- [x] animateui.Popover
- [x] animateui.Progress
- [x] animateui.RadioGroup
- [x] animateui.Sheet
- [x] animateui.Sidebar
- [x] animateui.Switch
- [x] animateui.Tabs
- [x] animateui.Toggle
- [x] animateui.ToggleGroup
- [x] animateui.Tooltip

## Additional Primitives
- [x] animateui.AvatarGroup
- [x] animateui.CodeBlock
- [x] animateui.Cursor
- [x] animateui.GithubStars
- [x] animateui.MotionGrid
- [x] animateui.PinnedList
- [x] animateui.ScrollProgress
- [x] animateui.Spring
- [x] animateui.AnimatedTabs (Renamed from Tabs)
- [x] animateui.AnimatedTooltip (Renamed from Tooltip)

## Text Effects
- [x] animateui.CountingNumber
- [x] animateui.GradientText
- [x] animateui.HighlightText
- [x] animateui.MorphingText
- [x] animateui.RollingText
- [x] animateui.RotatingText
- [x] animateui.ScrollingNumber
- [x] animateui.ShimmeringText
- [x] animateui.SlidingNumber
- [x] animateui.SplittingText
- [x] animateui.TypingText

## Backgrounds
- [x] animateui.BubbleBg
- [x] animateui.FireworksBg
- [x] animateui.GradientBg
- [x] animateui.GravityStarsBg
- [x] animateui.HexagonBg
- [x] animateui.HoleBg
- [x] animateui.StarsBg

## Buttons
- [x] animateui.CopyButton
- [x] animateui.FlipButton
- [x] animateui.GithubStarsButton
- [x] animateui.IconButton
- [x] animateui.LiquidButton
- [x] animateui.RippleButton
- [x] animateui.ThemeToggler

## Community Components
- [x] animateui.FlipCard
- [x] animateui.ManagementBar
- [x] animateui.MotionCarousel
- [x] animateui.NotificationList
- [x] animateui.PinList
- [x] animateui.PlayfulTodolist
- [x] animateui.RadialIntro
- [x] animateui.RadialMenu
- [x] animateui.RadialNav
- [x] animateui.ShareButton
- [x] animateui.UserPresenceAvatar
