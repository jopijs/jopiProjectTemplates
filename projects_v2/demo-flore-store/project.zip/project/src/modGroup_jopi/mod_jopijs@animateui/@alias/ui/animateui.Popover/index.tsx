import { Popover } from "../../../shadCN/ui/popover";

export default Popover;
