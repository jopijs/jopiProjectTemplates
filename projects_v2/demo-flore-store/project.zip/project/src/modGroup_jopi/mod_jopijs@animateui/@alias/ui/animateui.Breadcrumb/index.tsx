import { Breadcrumb } from "../../../shadCN/ui/breadcrumb";
export default Breadcrumb;
