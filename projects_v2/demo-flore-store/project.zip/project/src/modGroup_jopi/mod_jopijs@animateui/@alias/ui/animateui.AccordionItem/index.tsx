import { AccordionItem } from "../../../shadCN/ui/accordion";

export default AccordionItem;
