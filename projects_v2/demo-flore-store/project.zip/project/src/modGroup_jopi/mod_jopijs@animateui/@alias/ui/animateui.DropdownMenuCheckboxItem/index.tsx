import { DropdownMenuCheckboxItem } from "../../../shadCN/ui/dropdown-menu";

export default DropdownMenuCheckboxItem;
