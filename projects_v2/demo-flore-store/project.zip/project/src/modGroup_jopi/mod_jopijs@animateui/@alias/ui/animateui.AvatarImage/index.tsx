import { AvatarImage } from "../../../shadCN/ui/avatar";
export default AvatarImage;
