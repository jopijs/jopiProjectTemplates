import { AlertDialogTrigger } from "../../../shadCN/ui/alert-dialog";

export default AlertDialogTrigger;
