import { CountingNumber } from "../../../shadCN/ui/counting-number/index";

export default CountingNumber;
