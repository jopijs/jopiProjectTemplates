import { Separator } from "../../../shadCN/ui/separator";
export default Separator;
