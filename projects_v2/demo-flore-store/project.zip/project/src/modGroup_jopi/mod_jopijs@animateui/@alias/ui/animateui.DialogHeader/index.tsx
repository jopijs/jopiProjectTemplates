import { DialogHeader } from "../../../shadCN/ui/dialog";

export default DialogHeader;
