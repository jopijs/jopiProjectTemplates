import { SidebarInset } from "../../../shadCN/ui/sidebar";
export default SidebarInset;
