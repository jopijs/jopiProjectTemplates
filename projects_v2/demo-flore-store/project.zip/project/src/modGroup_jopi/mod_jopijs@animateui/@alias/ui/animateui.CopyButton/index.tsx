import { CopyButton } from "../../../shadCN/ui/copy-button/index";

export default CopyButton;
