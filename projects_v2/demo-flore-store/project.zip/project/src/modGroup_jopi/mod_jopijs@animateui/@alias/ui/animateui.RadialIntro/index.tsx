import { RadialIntro } from "../../../shadCN/ui/radial-intro/index";

export default RadialIntro;
