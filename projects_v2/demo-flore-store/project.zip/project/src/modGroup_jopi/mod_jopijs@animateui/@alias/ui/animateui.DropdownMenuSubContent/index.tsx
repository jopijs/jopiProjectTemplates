import { DropdownMenuSubContent } from "../../../shadCN/ui/dropdown-menu";

export default DropdownMenuSubContent;
