import { GitHubStarsButton as GithubStarsButton } from "../../../shadCN/ui/github-stars-button/index";

export default GithubStarsButton;
