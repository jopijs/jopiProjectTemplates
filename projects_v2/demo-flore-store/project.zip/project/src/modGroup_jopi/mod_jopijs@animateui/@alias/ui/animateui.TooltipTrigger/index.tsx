import { TooltipTrigger } from "../../../shadCN/ui/tooltip";

export default TooltipTrigger;
