import { SplittingText } from "../../../shadCN/ui/splitting-text/index";

export default SplittingText;
