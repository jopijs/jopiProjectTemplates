import { AvatarFallback } from "../../../shadCN/ui/avatar";
export default AvatarFallback;
