import { TableRow } from "../../../shadCN/ui/table";
export default TableRow;
