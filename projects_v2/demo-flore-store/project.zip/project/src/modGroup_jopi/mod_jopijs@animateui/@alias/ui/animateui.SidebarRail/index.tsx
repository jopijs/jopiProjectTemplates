import { SidebarRail } from "../../../shadCN/ui/sidebar";
export default SidebarRail;
