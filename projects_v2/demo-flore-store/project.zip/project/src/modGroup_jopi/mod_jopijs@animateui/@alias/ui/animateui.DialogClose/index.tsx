import { DialogClose } from "../../../shadCN/ui/dialog";

export default DialogClose;
