import { AlertDialogHeader } from "../../../shadCN/ui/alert-dialog";

export default AlertDialogHeader;
