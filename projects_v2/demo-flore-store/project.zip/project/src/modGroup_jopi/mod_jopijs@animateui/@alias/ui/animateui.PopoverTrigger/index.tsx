import { PopoverTrigger } from "../../../shadCN/ui/popover";

export default PopoverTrigger;
