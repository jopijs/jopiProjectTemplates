import { GradientBackground as GradientBg } from "../../../shadCN/ui/gradient-bg/index";

export default GradientBg;
