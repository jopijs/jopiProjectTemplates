import { HighlightText } from "../../../shadCN/ui/highlight-text/index";

export default HighlightText;
