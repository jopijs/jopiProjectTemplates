import { AlertDialogFooter } from "../../../shadCN/ui/alert-dialog";

export default AlertDialogFooter;
