import { SheetDescription } from "../../../shadCN/ui/sheet";

export default SheetDescription;
