import { AccordionContent } from "../../../shadCN/ui/accordion";

export default AccordionContent;
