import { ToggleGroupItem } from "../../../shadCN/ui/toggle-group";

export default ToggleGroupItem;
