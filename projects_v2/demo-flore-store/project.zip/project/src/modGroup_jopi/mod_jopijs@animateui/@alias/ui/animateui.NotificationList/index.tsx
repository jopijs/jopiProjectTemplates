import { NotificationList } from "../../../shadCN/ui/notification-list/index";

export default NotificationList;
