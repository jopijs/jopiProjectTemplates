import { MorphingText } from "../../../shadCN/ui/morphing-text/index";

export default MorphingText;
