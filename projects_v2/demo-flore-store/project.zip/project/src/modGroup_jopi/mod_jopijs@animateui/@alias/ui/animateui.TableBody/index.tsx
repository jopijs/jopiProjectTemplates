import { TableBody } from "../../../shadCN/ui/table";
export default TableBody;
