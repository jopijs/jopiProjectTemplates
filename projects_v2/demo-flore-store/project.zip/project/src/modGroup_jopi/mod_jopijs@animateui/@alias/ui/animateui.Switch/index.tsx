import { Switch } from "../../../shadCN/ui/switch";

export default Switch;
