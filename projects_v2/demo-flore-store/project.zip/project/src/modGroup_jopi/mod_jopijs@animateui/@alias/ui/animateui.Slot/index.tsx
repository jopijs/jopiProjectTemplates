import { Slot } from "../../../shadCN/ui/slot";
export default Slot;
