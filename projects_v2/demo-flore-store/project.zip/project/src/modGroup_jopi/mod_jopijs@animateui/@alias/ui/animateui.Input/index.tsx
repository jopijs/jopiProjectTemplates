import { Input } from "../../../shadCN/ui/input";
export default Input;
