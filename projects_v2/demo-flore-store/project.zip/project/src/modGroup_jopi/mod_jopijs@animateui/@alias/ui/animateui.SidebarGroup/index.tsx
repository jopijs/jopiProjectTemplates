import { SidebarGroup } from "../../../shadCN/ui/sidebar";
export default SidebarGroup;
