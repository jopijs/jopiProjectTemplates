import { DialogDescription } from "../../../shadCN/ui/dialog";

export default DialogDescription;
