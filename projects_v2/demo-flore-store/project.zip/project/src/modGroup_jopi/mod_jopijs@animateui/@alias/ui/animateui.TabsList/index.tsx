import { TabsList } from "../../../shadCN/ui/tabs";

export default TabsList;
