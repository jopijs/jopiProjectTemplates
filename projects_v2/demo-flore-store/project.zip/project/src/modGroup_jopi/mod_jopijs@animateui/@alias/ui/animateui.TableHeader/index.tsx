import { TableHeader } from "../../../shadCN/ui/table";
export default TableHeader;
