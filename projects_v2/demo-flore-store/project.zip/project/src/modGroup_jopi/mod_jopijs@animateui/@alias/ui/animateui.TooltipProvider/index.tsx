import { TooltipProvider } from "../../../shadCN/ui/tooltip";

export default TooltipProvider;
