import { ManagementBar } from "../../../shadCN/ui/management-bar/index";

export default ManagementBar;
