import { HoleBackground as HoleBg } from "../../../shadCN/ui/hole-bg/index";

export default HoleBg;
