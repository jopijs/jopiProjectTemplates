import { DialogContent } from "../../../shadCN/ui/dialog";

export default DialogContent;
