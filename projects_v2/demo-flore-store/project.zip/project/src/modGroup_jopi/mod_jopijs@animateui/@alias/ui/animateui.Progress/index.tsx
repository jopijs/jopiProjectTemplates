import { Progress } from "../../../shadCN/ui/progress";

export default Progress;
