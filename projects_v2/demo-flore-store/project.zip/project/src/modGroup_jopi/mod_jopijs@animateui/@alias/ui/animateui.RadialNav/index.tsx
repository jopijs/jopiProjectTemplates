import { RadialNav } from "../../../shadCN/ui/radial-nav/index";

export default RadialNav;
