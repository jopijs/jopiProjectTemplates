import { GithubStars } from "../../../shadCN/ui/github-stars-primitive/index";

export default GithubStars;
