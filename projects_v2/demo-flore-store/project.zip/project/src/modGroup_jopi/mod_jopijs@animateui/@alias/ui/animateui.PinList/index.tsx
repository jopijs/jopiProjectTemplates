import { PinList } from "../../../shadCN/ui/pin-list/index";

export default PinList;
