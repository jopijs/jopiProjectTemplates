import { SheetTitle } from "../../../shadCN/ui/sheet";

export default SheetTitle;
