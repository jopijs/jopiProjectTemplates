import { PopoverContent } from "../../../shadCN/ui/popover";

export default PopoverContent;
