import { TooltipContent } from "../../../shadCN/ui/tooltip";

export default TooltipContent;
