import { DropdownMenu } from "../../../shadCN/ui/dropdown-menu";
export default DropdownMenu;
