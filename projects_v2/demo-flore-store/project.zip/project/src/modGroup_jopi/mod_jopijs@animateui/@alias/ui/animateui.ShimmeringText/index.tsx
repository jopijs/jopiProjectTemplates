import { ShimmeringText } from "../../../shadCN/ui/shimmering-text/index";

export default ShimmeringText;
