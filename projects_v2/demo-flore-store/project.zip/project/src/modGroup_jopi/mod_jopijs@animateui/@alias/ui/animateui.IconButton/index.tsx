import { IconButton } from "../../../shadCN/ui/icon-button/index";

export default IconButton;
