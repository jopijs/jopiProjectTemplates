import { DialogFooter } from "../../../shadCN/ui/dialog";

export default DialogFooter;
