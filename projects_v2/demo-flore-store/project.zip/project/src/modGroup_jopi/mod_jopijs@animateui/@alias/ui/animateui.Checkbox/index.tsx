import { Checkbox } from "../../../shadCN/ui/checkbox";
export default Checkbox;
