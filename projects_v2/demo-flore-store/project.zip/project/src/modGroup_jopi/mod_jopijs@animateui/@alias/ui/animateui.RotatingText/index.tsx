import { RotatingText } from "../../../shadCN/ui/rotating-text/index";

export default RotatingText;
