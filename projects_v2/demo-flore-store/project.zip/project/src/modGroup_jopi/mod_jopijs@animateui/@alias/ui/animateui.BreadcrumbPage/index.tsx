import { BreadcrumbPage } from "../../../shadCN/ui/breadcrumb";
export default BreadcrumbPage;
