import { DialogPortal } from "../../../shadCN/ui/dialog";

export default DialogPortal;
