import { RadialMenu } from "../../../shadCN/ui/radial-menu/index";

export default RadialMenu;
