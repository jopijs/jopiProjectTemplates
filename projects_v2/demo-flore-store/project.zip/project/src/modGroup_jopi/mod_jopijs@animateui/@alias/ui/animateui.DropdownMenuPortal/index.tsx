import { DropdownMenuPortal } from "../../../shadCN/ui/dropdown-menu";

export default DropdownMenuPortal;
