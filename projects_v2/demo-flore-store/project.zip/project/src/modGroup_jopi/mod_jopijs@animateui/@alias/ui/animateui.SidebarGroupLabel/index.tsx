import { SidebarGroupLabel } from "../../../shadCN/ui/sidebar";
export default SidebarGroupLabel;
