import { Cursor } from "../../../shadCN/ui/cursor/index";

export default Cursor;
