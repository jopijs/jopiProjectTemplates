import { Accordion } from "../../../shadCN/ui/accordion";

export default Accordion;
