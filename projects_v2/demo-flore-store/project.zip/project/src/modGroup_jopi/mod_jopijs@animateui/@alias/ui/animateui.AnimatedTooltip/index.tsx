import { Tooltip as AnimatedTooltip } from "../../../shadCN/ui/animated-tooltip/index";

export default AnimatedTooltip;
