import { HexagonBackground as HexagonBg } from "../../../shadCN/ui/hexagon-bg/index";

export default HexagonBg;
