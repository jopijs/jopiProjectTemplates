import { ShareButton } from "../../../shadCN/ui/share-button/index";

export default ShareButton;
