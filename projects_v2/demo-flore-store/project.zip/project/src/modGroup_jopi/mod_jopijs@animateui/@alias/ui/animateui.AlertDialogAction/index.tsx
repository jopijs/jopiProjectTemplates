import { AlertDialogAction } from "../../../shadCN/ui/alert-dialog";

export default AlertDialogAction;
