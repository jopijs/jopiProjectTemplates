import { Toggle, toggleVariants } from "../../../shadCN/ui/toggle";

export default Toggle;
