import { Spring } from "../../../shadCN/ui/spring/index";

export default Spring;
