import { SidebarContent } from "../../../shadCN/ui/sidebar";
export default SidebarContent;
