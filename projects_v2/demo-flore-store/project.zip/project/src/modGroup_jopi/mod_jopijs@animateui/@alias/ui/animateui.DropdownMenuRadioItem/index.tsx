import { DropdownMenuRadioItem } from "../../../shadCN/ui/dropdown-menu";

export default DropdownMenuRadioItem;
