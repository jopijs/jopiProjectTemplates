import { SidebarMenuAction } from "../../../shadCN/ui/sidebar";
export default SidebarMenuAction;
