import { RippleButton } from "../../../shadCN/ui/ripple-button/index";

export default RippleButton;
