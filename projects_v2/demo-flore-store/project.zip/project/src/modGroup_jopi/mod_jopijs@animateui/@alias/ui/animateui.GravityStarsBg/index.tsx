import { GravityStarsBackground as GravityStarsBg } from "../../../shadCN/ui/gravity-stars-bg/index";

export default GravityStarsBg;
