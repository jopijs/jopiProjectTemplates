import { HoverCard } from "../../../shadCN/ui/hover-card";

export default HoverCard;
