import { UserPresenceAvatar } from "../../../shadCN/ui/user-presence-avatar/index";

export default UserPresenceAvatar;
