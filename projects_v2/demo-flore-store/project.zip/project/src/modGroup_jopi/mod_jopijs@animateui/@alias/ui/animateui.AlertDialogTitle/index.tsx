import { AlertDialogTitle } from "../../../shadCN/ui/alert-dialog";

export default AlertDialogTitle;
