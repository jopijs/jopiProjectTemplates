import { Tooltip } from "../../../shadCN/ui/tooltip";

export default Tooltip;
