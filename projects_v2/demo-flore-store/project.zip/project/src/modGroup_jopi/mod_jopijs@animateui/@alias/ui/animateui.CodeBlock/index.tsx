import { CodeBlock } from "../../../shadCN/ui/code-block/index";

export default CodeBlock;
