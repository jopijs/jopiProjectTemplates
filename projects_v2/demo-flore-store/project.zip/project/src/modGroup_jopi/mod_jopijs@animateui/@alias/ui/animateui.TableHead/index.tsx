import { TableHead } from "../../../shadCN/ui/table";
export default TableHead;
