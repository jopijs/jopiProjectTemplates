import { SidebarMenuButton } from "../../../shadCN/ui/sidebar";
export default SidebarMenuButton;
