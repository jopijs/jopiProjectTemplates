import { BreadcrumbLink } from "../../../shadCN/ui/breadcrumb";
export default BreadcrumbLink;
