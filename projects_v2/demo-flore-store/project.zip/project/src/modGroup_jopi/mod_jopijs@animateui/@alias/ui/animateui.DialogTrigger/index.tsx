import { DialogTrigger } from "../../../shadCN/ui/dialog";

export default DialogTrigger;
