import { SheetTrigger } from "../../../shadCN/ui/sheet";

export default SheetTrigger;
