import { StarsBackground as StarsBg } from "../../../shadCN/ui/stars-bg/index";

export default StarsBg;
