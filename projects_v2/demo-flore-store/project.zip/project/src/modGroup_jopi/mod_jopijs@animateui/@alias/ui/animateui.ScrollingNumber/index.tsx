import { ScrollingNumber } from "../../../shadCN/ui/scrolling-number/index";

export default ScrollingNumber;
