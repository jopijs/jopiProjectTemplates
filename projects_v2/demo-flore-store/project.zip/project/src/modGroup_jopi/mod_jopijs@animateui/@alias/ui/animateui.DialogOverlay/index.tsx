import { DialogOverlay } from "../../../shadCN/ui/dialog";

export default DialogOverlay;
