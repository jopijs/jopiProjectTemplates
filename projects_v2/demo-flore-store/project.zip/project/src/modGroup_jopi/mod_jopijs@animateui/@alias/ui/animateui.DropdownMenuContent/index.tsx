import { DropdownMenuContent } from "../../../shadCN/ui/dropdown-menu";

export default DropdownMenuContent;
