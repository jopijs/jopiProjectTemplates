import { DropdownMenuLabel } from "../../../shadCN/ui/dropdown-menu";

export default DropdownMenuLabel;
