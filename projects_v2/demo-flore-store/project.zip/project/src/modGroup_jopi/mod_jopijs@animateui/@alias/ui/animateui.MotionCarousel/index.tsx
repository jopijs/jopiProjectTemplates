import { MotionCarousel } from "../../../shadCN/ui/motion-carousel/index";

export default MotionCarousel;
