import { DropdownMenuSeparator } from "../../../shadCN/ui/dropdown-menu";

export default DropdownMenuSeparator;
