import { Tabs } from "../../../shadCN/ui/tabs";

export default Tabs;
