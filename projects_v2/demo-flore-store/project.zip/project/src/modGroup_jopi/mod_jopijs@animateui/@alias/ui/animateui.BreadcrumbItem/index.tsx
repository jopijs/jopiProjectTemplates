import { BreadcrumbItem } from "../../../shadCN/ui/breadcrumb";
export default BreadcrumbItem;
