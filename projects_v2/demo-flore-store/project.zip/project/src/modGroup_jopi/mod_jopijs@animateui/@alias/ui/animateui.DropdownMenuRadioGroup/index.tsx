import { DropdownMenuRadioGroup } from "../../../shadCN/ui/dropdown-menu";

export default DropdownMenuRadioGroup;
