import * as T from "../../../shadCN/ui/table";
export default T.Table;
