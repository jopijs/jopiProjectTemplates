import { HoverCardTrigger } from "../../../shadCN/ui/hover-card";

export default HoverCardTrigger;
