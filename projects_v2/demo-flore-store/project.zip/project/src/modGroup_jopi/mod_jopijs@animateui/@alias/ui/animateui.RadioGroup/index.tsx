import { RadioGroup } from "../../../shadCN/ui/radio-group";

export default RadioGroup;
