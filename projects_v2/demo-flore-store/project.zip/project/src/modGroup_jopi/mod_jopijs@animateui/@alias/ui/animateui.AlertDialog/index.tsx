import { AlertDialog } from "../../../shadCN/ui/alert-dialog";

export default AlertDialog;
