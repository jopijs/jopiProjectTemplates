import { FlipButton } from "../../../shadCN/ui/flip-button/index";

export default FlipButton;
