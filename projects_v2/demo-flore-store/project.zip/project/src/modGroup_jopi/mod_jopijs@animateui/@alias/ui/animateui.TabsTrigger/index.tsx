import { TabsTrigger } from "../../../shadCN/ui/tabs";

export default TabsTrigger;
