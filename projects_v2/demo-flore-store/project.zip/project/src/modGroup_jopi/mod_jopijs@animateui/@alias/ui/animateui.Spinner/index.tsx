import { Spinner } from "../../../shadCN/ui/spinner";
export default Spinner;
