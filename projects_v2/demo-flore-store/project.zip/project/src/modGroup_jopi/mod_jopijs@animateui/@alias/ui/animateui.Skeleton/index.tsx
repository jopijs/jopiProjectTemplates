import { Skeleton } from "../../../shadCN/ui/skeleton";
export default Skeleton;
