import { DialogTitle } from "../../../shadCN/ui/dialog";

export default DialogTitle;
