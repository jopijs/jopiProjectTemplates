import { DropdownMenuShortcut } from "../../../shadCN/ui/dropdown-menu";

export default DropdownMenuShortcut;
