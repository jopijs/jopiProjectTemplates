import { MotionGrid } from "../../../shadCN/ui/motion-grid/index";

export default MotionGrid;
