import { Collapsible } from "../../../shadCN/ui/collapsible";
export default Collapsible;
