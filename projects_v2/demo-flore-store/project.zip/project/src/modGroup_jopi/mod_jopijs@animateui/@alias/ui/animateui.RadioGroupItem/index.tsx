import { RadioGroupItem } from "../../../shadCN/ui/radio-group";

export default RadioGroupItem;
