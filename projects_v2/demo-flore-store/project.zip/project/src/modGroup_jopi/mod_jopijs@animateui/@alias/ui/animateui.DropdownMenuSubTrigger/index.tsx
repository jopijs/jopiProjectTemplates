import { DropdownMenuSubTrigger } from "../../../shadCN/ui/dropdown-menu";

export default DropdownMenuSubTrigger;
