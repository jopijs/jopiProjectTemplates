import { AvatarGroup } from "../../../shadCN/ui/avatar-group/index";

export default AvatarGroup;
