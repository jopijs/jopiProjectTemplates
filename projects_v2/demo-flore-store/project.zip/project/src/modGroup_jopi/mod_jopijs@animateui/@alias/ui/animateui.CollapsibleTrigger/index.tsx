import { CollapsibleTrigger } from "../../../shadCN/ui/collapsible";
export default CollapsibleTrigger;
