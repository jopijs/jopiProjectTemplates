import { SidebarTrigger } from "../../../shadCN/ui/sidebar";
export default SidebarTrigger;
