import { PinnedList } from "../../../shadCN/ui/pinned-list/index";

export default PinnedList;
