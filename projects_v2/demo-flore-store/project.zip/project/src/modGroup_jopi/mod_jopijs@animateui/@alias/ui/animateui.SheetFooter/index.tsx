import { SheetFooter } from "../../../shadCN/ui/sheet";

export default SheetFooter;
