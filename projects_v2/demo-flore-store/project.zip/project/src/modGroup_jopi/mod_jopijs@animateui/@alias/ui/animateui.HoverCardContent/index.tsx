import { HoverCardContent } from "../../../shadCN/ui/hover-card";

export default HoverCardContent;
