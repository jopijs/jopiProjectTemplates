import { ScrollProgress } from "../../../shadCN/ui/scroll-progress/index";

export default ScrollProgress;
