import { AccordionTrigger } from "../../../shadCN/ui/accordion";

export default AccordionTrigger;
