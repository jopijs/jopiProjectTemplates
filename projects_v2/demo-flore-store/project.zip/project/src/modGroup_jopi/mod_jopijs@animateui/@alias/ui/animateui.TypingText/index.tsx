import { TypingText } from "../../../shadCN/ui/typing-text/index";

export default TypingText;
