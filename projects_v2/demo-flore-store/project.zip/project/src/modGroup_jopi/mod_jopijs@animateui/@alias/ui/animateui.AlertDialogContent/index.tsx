import { AlertDialogContent } from "../../../shadCN/ui/alert-dialog";

export default AlertDialogContent;
