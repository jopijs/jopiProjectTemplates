import { Avatar } from "../../../shadCN/ui/avatar";
export default Avatar;
