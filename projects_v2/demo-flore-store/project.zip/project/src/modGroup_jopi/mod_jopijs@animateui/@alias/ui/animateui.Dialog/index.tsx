import { Dialog } from "../../../shadCN/ui/dialog";

export default Dialog;
