import { SlidingNumber } from "../../../shadCN/ui/sliding-number/index";

export default SlidingNumber;
