import { DropdownMenuItem } from "../../../shadCN/ui/dropdown-menu";

export default DropdownMenuItem;
