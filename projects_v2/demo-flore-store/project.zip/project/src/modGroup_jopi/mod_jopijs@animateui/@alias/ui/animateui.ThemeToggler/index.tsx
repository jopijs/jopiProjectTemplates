import { ThemeTogglerButton as ThemeToggler } from "../../../shadCN/ui/theme-toggler/index";

export default ThemeToggler;
