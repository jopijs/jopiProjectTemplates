import { SidebarFooter } from "../../../shadCN/ui/sidebar";
export default SidebarFooter;
