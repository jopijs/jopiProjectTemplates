import { AlertDialogCancel } from "../../../shadCN/ui/alert-dialog";

export default AlertDialogCancel;
