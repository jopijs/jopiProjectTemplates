import { FireworksBackground as FireworksBg } from "../../../shadCN/ui/fireworks-bg/index";

export default FireworksBg;
