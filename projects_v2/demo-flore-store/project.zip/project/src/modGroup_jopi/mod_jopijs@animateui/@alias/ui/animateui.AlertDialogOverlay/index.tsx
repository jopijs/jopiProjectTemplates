import { AlertDialogOverlay } from "../../../shadCN/ui/alert-dialog";

export default AlertDialogOverlay;
