import { BreadcrumbList } from "../../../shadCN/ui/breadcrumb";
export default BreadcrumbList;
