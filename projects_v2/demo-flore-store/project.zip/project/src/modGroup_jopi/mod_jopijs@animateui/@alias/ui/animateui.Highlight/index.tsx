import { Highlight } from "../../../shadCN/ui/highlight";

export default Highlight;
