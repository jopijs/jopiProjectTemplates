import { TabsContent } from "../../../shadCN/ui/tabs";

export default TabsContent;
