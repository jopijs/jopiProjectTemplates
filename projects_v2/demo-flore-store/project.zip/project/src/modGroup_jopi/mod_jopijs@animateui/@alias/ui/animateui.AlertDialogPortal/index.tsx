import { AlertDialogPortal } from "../../../shadCN/ui/alert-dialog";

export default AlertDialogPortal;
