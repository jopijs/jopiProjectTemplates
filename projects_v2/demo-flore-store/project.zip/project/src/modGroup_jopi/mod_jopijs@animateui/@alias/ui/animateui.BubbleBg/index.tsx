import { BubbleBackground as BubbleBg } from "../../../shadCN/ui/bubble-bg/index";

export default BubbleBg;
