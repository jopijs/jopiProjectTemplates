import { RollingText } from "../../../shadCN/ui/rolling-text/index";

export default RollingText;
