import { DropdownMenuGroup } from "../../../shadCN/ui/dropdown-menu";

export default DropdownMenuGroup;
