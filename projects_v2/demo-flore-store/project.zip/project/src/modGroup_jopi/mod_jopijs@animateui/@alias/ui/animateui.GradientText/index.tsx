import { GradientText } from "../../../shadCN/ui/gradient-text/index";

export default GradientText;
