import { TableCell } from "../../../shadCN/ui/table";
export default TableCell;
