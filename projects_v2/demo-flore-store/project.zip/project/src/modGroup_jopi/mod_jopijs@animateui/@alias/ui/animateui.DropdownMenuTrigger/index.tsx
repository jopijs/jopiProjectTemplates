import { DropdownMenuTrigger } from "../../../shadCN/ui/dropdown-menu";

export default DropdownMenuTrigger;
