import { CollapsibleContent } from "../../../shadCN/ui/collapsible";
export default CollapsibleContent;
