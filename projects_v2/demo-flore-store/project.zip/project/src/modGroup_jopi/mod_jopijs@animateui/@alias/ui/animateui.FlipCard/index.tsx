import { FlipCard } from "../../../shadCN/ui/flip-card/index";

export default FlipCard;
