import { AlertDialogDescription } from "../../../shadCN/ui/alert-dialog";

export default AlertDialogDescription;
