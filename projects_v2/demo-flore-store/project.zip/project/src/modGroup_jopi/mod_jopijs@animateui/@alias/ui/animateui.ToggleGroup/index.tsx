import { ToggleGroup } from "../../../shadCN/ui/toggle-group";

export default ToggleGroup;
