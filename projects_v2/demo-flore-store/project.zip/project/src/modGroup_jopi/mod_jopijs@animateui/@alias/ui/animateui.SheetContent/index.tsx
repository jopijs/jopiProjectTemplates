import { SheetContent } from "../../../shadCN/ui/sheet";

export default SheetContent;
