import { BreadcrumbSeparator } from "../../../shadCN/ui/breadcrumb";
export default BreadcrumbSeparator;
