import { Tabs as AnimatedTabs } from "../../../shadCN/ui/animated-tabs/index";

export default AnimatedTabs;
