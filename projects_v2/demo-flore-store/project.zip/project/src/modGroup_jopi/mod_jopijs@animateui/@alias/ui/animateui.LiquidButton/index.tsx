import { LiquidButton } from "../../../shadCN/ui/liquid-button/index";

export default LiquidButton;
