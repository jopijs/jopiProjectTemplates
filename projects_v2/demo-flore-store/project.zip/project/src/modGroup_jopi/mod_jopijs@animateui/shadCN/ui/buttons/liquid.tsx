'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../../lib/utils';
import { Slot } from '../slot';

export type LiquidButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  asChild?: boolean;
};

export function LiquidButton({
  children,
  asChild = false,
  className,
  ...props
}: LiquidButtonProps) {
  const Component = asChild ? Slot : 'button';

  return (
    <Component
      className={cn('relative overflow-hidden outline-none', className)}
      {...props}
    >
      <span className="relative z-10">{children}</span>
      <div
        className="absolute inset-0 z-0 pointer-events-none opacity-0 hover:opacity-100 transition-opacity"
        style={{
          background: 'radial-gradient(circle, var(--liquid-button-background-color) 0%, transparent 70%)',
          backgroundColor: 'var(--liquid-button-color)',
        }}
      />
    </Component>
  );
}
