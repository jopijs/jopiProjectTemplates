import * as React from 'react';

export type ThemeSelection = 'light' | 'dark' | 'system';
export type Resolved = 'light' | 'dark';

export interface ThemeTogglerProps {
  theme?: ThemeSelection;
  resolvedTheme?: Resolved;
  setTheme: (theme: string) => void;
  direction?: 'ltr' | 'rtl';
  onImmediateChange?: (theme: ThemeSelection) => void;
  children: (props: {
    effective: ThemeSelection;
    resolved: Resolved;
    toggleTheme: (theme: ThemeSelection) => void;
  }) => React.ReactNode;
}

export const ThemeToggler = ({
  theme,
  resolvedTheme,
  setTheme,
  onImmediateChange,
  children,
}: ThemeTogglerProps) => {
  const toggleTheme = React.useCallback(
    (newTheme: ThemeSelection) => {
      setTheme(newTheme);
      onImmediateChange?.(newTheme);
    },
    [setTheme, onImmediateChange],
  );

  return (
    <>
      {children({
        effective: theme || 'system',
        resolved: resolvedTheme || 'light',
        toggleTheme,
      })}
    </>
  );
};
