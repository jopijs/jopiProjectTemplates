'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../../lib/utils';
import { Slot } from '../slot';

export type ParticlesEffectProps = React.HTMLAttributes<HTMLDivElement> & {
  animate?: boolean;
};

export function Particles({
  children,
  animate = false,
  className,
  asChild = false,
  ...props
}: {
  children: React.ReactNode;
  animate?: boolean;
  className?: string;
  asChild?: boolean;
} & React.HTMLAttributes<HTMLDivElement>) {
  const Component = asChild ? Slot : 'div';
  return (
    <Component className={cn('relative inline-block', className)} {...props}>
      {children}
    </Component>
  );
}

export function ParticlesEffect({
  className,
  animate,
  style,
  ...props
}: ParticlesEffectProps) {
  if (!animate) return null;

  return (
    <div
      className={cn('absolute inset-0 pointer-events-none', className)}
      style={style}
      {...props}
    >
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute size-1 rounded-full bg-current"
          initial={{ opacity: 0, scale: 0, x: 0, y: 0 }}
          animate={{
            opacity: [0, 1, 0],
            scale: [0, 1, 0],
            x: Math.cos((i * 30 * Math.PI) / 180) * 40,
            y: Math.sin((i * 30 * Math.PI) / 180) * 40,
          }}
          transition={{
            duration: 0.8,
            ease: 'easeOut',
            repeat: i % 2 === 0 ? Infinity : 1, // mix of continuous and one-shot
            repeatDelay: Math.random() * 2,
          }}
          style={{
            left: '50%',
            top: '50%',
          }}
        />
      ))}
    </div>
  );
}
