'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../../lib/utils';

export type FlipButtonProps = {
  children: React.ReactNode;
  className?: string;
};

export function FlipButton({ children, className }: FlipButtonProps) {
  const [isFlipped, setIsFlipped] = React.useState(false);

  return (
    <div
      className={cn('relative perspective-1000', className)}
      onMouseEnter={() => setIsFlipped(true)}
      onMouseLeave={() => setIsFlipped(false)}
    >
      <motion.div
        className="relative w-full h-full transition-all duration-500 preserve-3d"
        animate={{ rotateX: isFlipped ? 180 : 0 }}
      >
        {children}
      </motion.div>
    </div>
  );
}

export type FlipButtonFrontProps = {
  children: React.ReactNode;
  className?: string;
};

export function FlipButtonFront({ children, className }: FlipButtonFrontProps) {
  return (
    <div className={cn('absolute inset-0 backface-hidden', className)}>
      {children}
    </div>
  );
}

export type FlipButtonBackProps = {
  children: React.ReactNode;
  className?: string;
};

export function FlipButtonBack({ children, className }: FlipButtonBackProps) {
  return (
    <div
      className={cn('absolute inset-0 backface-hidden rotate-x-180', className)}
    >
      {children}
    </div>
  );
}
