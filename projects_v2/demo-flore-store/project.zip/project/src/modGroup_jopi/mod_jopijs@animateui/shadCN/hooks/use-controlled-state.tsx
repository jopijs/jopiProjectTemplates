"use client"

import * as React from "react"

export interface UseControlledStateProps<T> {
  value?: T
  defaultValue?: T
  onChange?: (value: T) => void
}

export function useControlledState<T>({
  value,
  defaultValue,
  onChange,
}: UseControlledStateProps<T>): [T, (value: T) => void] {
  const [state, setState] = React.useState<T>(
    value !== undefined ? value : (defaultValue as T)
  )

  const isControlled = value !== undefined
  const currentValue = isControlled ? value : state

  const setValue = React.useCallback(
    (newValue: T) => {
      if (!isControlled) {
        setState(newValue)
      }
      onChange?.(newValue)
    },
    [isControlled, onChange]
  )

  return [currentValue, setValue]
}
