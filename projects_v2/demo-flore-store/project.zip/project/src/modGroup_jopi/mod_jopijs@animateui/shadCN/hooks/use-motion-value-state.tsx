"use client"

import { useEffect, useState } from "react"
import { type MotionValue } from "motion/react"

export function useMotionValueState(value: MotionValue<any>): any {
  const [state, setState] = useState(value.get())

  useEffect(() => {
    return value.on("change", (latest) => {
      setState(latest)
    })
  }, [value])

  return state
}
