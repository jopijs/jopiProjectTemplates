import { useInView, type UseInViewOptions } from 'motion/react';
import * as React from 'react';

export type UseIsInViewOptions = UseInViewOptions & {
  inView?: boolean;
  inViewOnce?: boolean;
  inViewMargin?: string;
};

export function useIsInView<T extends Element>(
  refProp: React.Ref<T> | undefined,
  {
    inView = false,
    inViewOnce = true,
    inViewMargin = '0px',
    ...options
  }: UseIsInViewOptions = {},
) {
  const internalRef = React.useRef<T>(null);
  const ref = (refProp as React.RefObject<T | null>) || internalRef;

  const isInView = useInView(ref, {
    once: inViewOnce,
    margin: inViewMargin as any,
    ...options,
  });

  return {
    ref,
    isInView: inView || isInView,
  };
}
