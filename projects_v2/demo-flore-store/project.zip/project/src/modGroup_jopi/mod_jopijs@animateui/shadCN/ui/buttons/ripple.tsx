'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../../lib/utils';
import { Slot } from '../slot';

export type RippleButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  asChild?: boolean;
  rippleColor?: string;
};

export function RippleButton({
  children,
  asChild = false,
  className,
  rippleColor = 'rgba(255, 255, 255, 0.3)',
  onClick,
  ...props
}: RippleButtonProps) {
  const [ripples, setRipples] = React.useState<
    { id: number; x: number; y: number; size: number }[]
  >([]);

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = e.clientX - rect.left - size / 2;
    const y = e.clientY - rect.top - size / 2;

    const newRipple = {
      id: Date.now(),
      x,
      y,
      size,
    };

    setRipples((prev) => [...prev, newRipple]);
    onClick?.(e);
  };

  const Component = asChild ? Slot : 'button';

  return (
    <Component
      className={cn('relative overflow-hidden outline-none', className)}
      onClick={handleClick}
      {...props}
    >
      <span className="relative z-10">{children}</span>
      <AnimatePresence>
        {ripples.map((ripple) => (
          <motion.span
            key={ripple.id}
            initial={{ scale: 0, opacity: 0.5 }}
            animate={{ scale: 4, opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6, ease: 'linear' }}
            onAnimationComplete={() => {
              setRipples((prev) => prev.filter((r) => r.id !== ripple.id));
            }}
            style={{
              position: 'absolute',
              left: ripple.x,
              top: ripple.y,
              width: ripple.size,
              height: ripple.size,
              backgroundColor: rippleColor,
              borderRadius: '50%',
              pointerEvents: 'none',
              zIndex: 0,
            }}
          />
        ))}
      </AnimatePresence>
    </Component>
  );
}

export type RippleButtonRipplesProps = {
  className?: string;
  style?: React.CSSProperties;
};

export function RippleButtonRipples({
  className,
  style,
}: RippleButtonRipplesProps) {
  return null;
}
