# JopiJS Page Router

A lightweight, SPA (Single Page Application) router designed for JopiJS applications. It automatically integrates with the JopiJS codegen route definitions.

## Features

- **SPA Navigation**: Smooth transitions without full page reloads.
- **Automatic Routing**: Uses the auto-generated `@routes` map.
- **Parameter Support**: Handles dynamic route parameters (e.g., `/user/:id`).
- **Lazy Loading**: Supports `React.lazy` routes with Suspense.
- **History Management**: Integrated with browser history (back/forward support).
- **JopiJS Architecture**: Components and hooks are structured as shared resources (Aliases), allowing for easy extensions or overrides.

## Usage

### 1. Basic Setup

Wrap your application or main layout content with the `<Router>` component. By default, it will render the current matching page.

```tsx
import Router from "@/ui/jopijs.route.Router";

export default function App() {
    return (
        <Router />
    );
}
```

Or with a layout:

```tsx
import Router, { Page } from "@/ui/jopijs.route.Router";
import MyLayout from "./MyLayout";

// If you pass children, use <Page /> to render the matched route content
export default function App() {
    return (
        <Router>
            <MyLayout>
                <Page />
            </MyLayout>
        </Router>
    );
}
```

### 2. Navigation with `<Link>`

Use the `<Link>` component to navigate between pages without reloading.

```tsx
import Link from "@/ui/jopijs.route.Link";

function NavBar() {
    return (
        <nav>
            <Link to="/">Home</Link>
            <Link to="/about">About</Link>
            {/* Use replace to replace the history entry */}
            <Link to="/login" replace>Login</Link>
        </nav>
    );
}
```

### 3. Programmatic Navigation

Use the `useRouter` hook to navigate from code.

```tsx
import useRouter from "@/hooks/jopijs.route.useRouter";

function LoginButton() {
    const { navigate } = useRouter();

    const handleLogin = () => {
        // ... login logic ...
        navigate("/dashboard");
    };

    return <button onClick={handleLogin}>Login</button>;
}
```

### 4. Accessing Parameters

The `useRouter` hook also provides access to current path parameters.

For a route defined as `/product/:id`:

```tsx
import useRouter from "@/hooks/jopijs.route.useRouter";

function ProductPage() {
    const { params } = useRouter();
    
    return <h1>Product ID: {params.id}</h1>;
}
```

## API Reference

The module exports strict TypeScript interfaces to help with development:

- **`IRouteParams`**: Type for the URL parameters object (`Record<string, string>`).
- **`INavigateOptions`**: Options object for navigation (e.g., `{ replace: true }`).
- **`ILinkProps`**: Props accepted by the `<Link />` component (extends `React.AnchorHTMLAttributes`).
- **`IRouterContextType`**: The full shape of the context returned by `useRouter()`.

## How it works

The router imports routes from `@routes` (the JopiJS generated route map). It matches the current `window.location.pathname` against the declared routes:
1. **Exact match** (e.g. `/admin/settings` matches `/admin/settings`)
2. **Pattern match** (e.g. `/users/12` matches `/users/:id`)
3. **404 Fallback** (looks for `/error404` route or displays default message)
