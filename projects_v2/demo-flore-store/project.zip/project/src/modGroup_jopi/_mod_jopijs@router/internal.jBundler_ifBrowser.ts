import { createContext } from 'react';
import React from 'react';
import IRouterContextType from '@/lib/jopijs.route.IRouterContextType';
import IRouteParams from '@/lib/jopijs.route.IRouteParams';
import routesJson from "@/routes/routes.json";

/**
 * Provides the router state (current path, params, navigation function) to the component tree.
 * This is used by the `useRouter()` hook.
 */
export const RouterContext = createContext<IRouterContextType | null>(null);

/**
 * This function determines which component should be rendered based on the current URL path.
 * 
 * It runs on the BROWSER side and uses the `routes` map which contains React.lazy imports.
 * This ensures code splitting: only the code for the matched page is loaded.
 * 
 * @param path The current URL path (e.g. "/users/123")
 * @returns An object containing the matched `Component` (React Component) and extracted `params` (key-value pairs).
 */ 
export async function matchRoute(path: string): Promise<{ Component: React.ComponentType<any> | null, params: IRouteParams }> {
    // 1. Exact match strategy.
    // Checks if the path exists exactly as a key in the routes map.
    // Example: path "/admin/settings" matches key "/admin/settings".
    if ((routesJson as any)[path]) {
        const module = await import((routesJson as any)[path]);
        return { Component: module.default, params: {} };
    }

    // 2. Pattern match strategy.
    // Splits the path into segments and compares them against route definitions with parameters.
    // Example: path "/user/42" (segments: ["user", "42"]) 
    //          matches route "/user/:id" (segments: ["user", ":id"]).
    const pathSegments = path.split('/').filter(Boolean);
    
    for (const routeKey of Object.keys(routesJson)) {
        // Optimization: Only consider dynamic routes (containing ':').
        if (!routeKey.includes(':')) continue;

        const routeSegments = routeKey.split('/').filter(Boolean);
        
        // A route must have the same number of segments to match.
        if (routeSegments.length !== pathSegments.length) continue;

        let match = true;
        const params: IRouteParams = {};

        for (let i = 0; i < routeSegments.length; i++) {
            const rSeg = routeSegments[i];
            const pSeg = pathSegments[i];

            if (rSeg.startsWith(':')) {
                // Determine parameter name (remove ':') and assign value.
                // e.g. ":id" -> "id" = "42"
                params[rSeg.slice(1)] = pSeg;
            } else if (rSeg !== pSeg) {
                // Static segment mismatch (e.g. "user" !== "product").
                match = false;
                break;
            }
        }

        if (match) {
            const module = await import((routesJson as any)[routeKey]);
            return { Component: module.default, params };
        }
    }

    // 3. Fallback (404).
    // If no route matches, return the 404 error page if defined, or a default message.
    if ((routesJson as any)['/error404']) {
        const module = await import((routesJson as any)['/error404']);
        return { Component: module.default, params: {} };
    }

    return { Component: () => React.createElement('div', null, '404 Not Found'), params: {} };
}
