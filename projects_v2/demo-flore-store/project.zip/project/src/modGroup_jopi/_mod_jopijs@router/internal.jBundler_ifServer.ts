import { createContext } from 'react';
import React from 'react';
import IRouterContextType from '@/lib/jopijs.route.IRouterContextType';
import IRouteParams from '@/lib/jopijs.route.IRouteParams';

export const RouterContext = createContext<IRouterContextType | null>(null);

export function matchRoute(path: string): { Component: React.ComponentType<any> | null, params: IRouteParams } {
    return { Component: null, params: {} };
}
