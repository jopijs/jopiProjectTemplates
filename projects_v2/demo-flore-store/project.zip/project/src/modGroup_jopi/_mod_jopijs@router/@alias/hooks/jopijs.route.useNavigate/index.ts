import useRouter from '../jopijs.route.useRouter';

export default function useNavigate() {
    const { navigate } = useRouter();
    return navigate;
}
