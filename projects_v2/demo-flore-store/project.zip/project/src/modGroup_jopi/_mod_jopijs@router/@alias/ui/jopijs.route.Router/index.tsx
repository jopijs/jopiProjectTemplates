import React, { useState, useEffect, startTransition, Suspense } from 'react';
import { RouterContext, matchRoute } from '../../../internal.jBundler_ifServer.ts';
import INavigateOptions from '@/lib/jopijs.route.INavigateOptions';
import useRouter from '@/hooks/jopijs.route.useRouter';

function Page() {
    const { Component, params } = useRouter();
    if (!Component) return null;

    return (
        <Suspense fallback={null}>
            <Component {...params} />
        </Suspense>
    );
}

export default function Router({ children }: { children?: React.ReactNode }) {
    const [currentPath, setCurrentPath] = useState(() => 
        typeof window !== 'undefined' ? window.location.pathname : '/'
    );

    // State to hold the resolved route component and params
    // We initialize with null component and empty params
    const [routeState, setRouteState] = useState<{ Component: React.ComponentType<any> | null, params: any }>({
        Component: null,
        params: {}
    });

    useEffect(() => {
        const onPopState = () => setCurrentPath(window.location.pathname);
        window.addEventListener('popstate', onPopState);
        return () => window.removeEventListener('popstate', onPopState);
    }, []);

    // Effect to resolve the route when path changes
    useEffect(() => {
        let isMounted = true;
        
        // Handle potentially async matchRoute
        Promise.resolve(matchRoute(currentPath)).then((result) => {
            if (isMounted) {
                setRouteState(result);
            }
            })
            .catch((error) => {
                console.error(`[Router] Error resolving route for ${currentPath}:`, error);
        });
        
        return () => { isMounted = false; };
    }, [currentPath]);

    const navigate = (to: string, options?: INavigateOptions) => {
        if (to === currentPath && !options?.replace) return;
        
        if (options?.replace) {
            window.history.replaceState(null, '', to);
        } else {
            window.history.pushState(null, '', to);
        }

        if (typeof startTransition === 'function') {
            startTransition(() => {
                setCurrentPath(to);
            });
        } else {
            setCurrentPath(to);
        }
        
        window.scrollTo(0, 0);
        window.dispatchEvent(new PopStateEvent('popstate'));
    };

    return (
        <RouterContext.Provider value={{ path: currentPath, params: routeState.params, navigate, Component: routeState.Component }}>
            {children || <Page />}
        </RouterContext.Provider>
    );
}
