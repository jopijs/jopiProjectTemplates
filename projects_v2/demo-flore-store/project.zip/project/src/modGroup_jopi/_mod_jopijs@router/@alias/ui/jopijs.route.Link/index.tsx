import React from 'react';
import useRouter from '@/hooks/jopijs.route.useRouter';
import ILinkProps from '@/lib/jopijs.route.ILinkProps';

export default function Link({ to, replace, children, className, ...props }: ILinkProps) {
    const { navigate } = useRouter();

    const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
        if (!e.ctrlKey && !e.metaKey && !e.shiftKey && !e.altKey) {
            e.preventDefault();
            navigate(to, { replace });
        }
    };

    return (
        <a href={to} onClick={handleClick} className={className} {...props}>
            {children}
        </a>
    );
}
