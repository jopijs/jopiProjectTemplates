import useRouter from '../jopijs.route.useRouter';

export default function useLocation() {
    const { path } = useRouter();
    
    if (typeof window !== 'undefined') {
        return {
            pathname: window.location.pathname,
            search: window.location.search,
            hash: window.location.hash
        };
    }

    return {
        pathname: path,
        search: '',
        hash: ''
    };
}
