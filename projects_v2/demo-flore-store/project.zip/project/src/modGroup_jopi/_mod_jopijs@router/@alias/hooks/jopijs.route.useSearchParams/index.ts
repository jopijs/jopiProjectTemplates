import { useMemo } from 'react';
import useRouter from '../jopijs.route.useRouter';

export default function useSearchParams() {
    const { path } = useRouter();

    return useMemo(() => {
        if (typeof window === 'undefined') return new URLSearchParams();
        return new URLSearchParams(window.location.search);
    }, [path]);
}
