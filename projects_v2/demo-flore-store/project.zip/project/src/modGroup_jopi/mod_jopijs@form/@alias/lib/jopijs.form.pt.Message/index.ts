import type {PassThrough_Message} from "../../../interfaces.ts";
export default PassThrough_Message;