import type {PassThrough_Label} from "../../../interfaces.ts";
export default PassThrough_Label;