import type {TypeSubmitFunction} from "../../../interfaces.ts";
export default TypeSubmitFunction;