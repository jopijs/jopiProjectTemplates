import type {PassThrough_Text} from "../../../interfaces.ts";
export default PassThrough_Text;