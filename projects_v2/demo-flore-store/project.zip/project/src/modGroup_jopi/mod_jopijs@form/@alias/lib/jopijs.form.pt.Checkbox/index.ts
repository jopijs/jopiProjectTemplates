import type {PassThrough_Checkbox} from "../../../interfaces.ts";
export default PassThrough_Checkbox;