import type {ISubmitMessage} from "../../../interfaces.ts";
export default ISubmitMessage;