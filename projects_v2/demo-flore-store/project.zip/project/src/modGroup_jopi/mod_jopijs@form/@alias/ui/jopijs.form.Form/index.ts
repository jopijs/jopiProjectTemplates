import {JForm} from "../../../index.ts";
export default JForm;