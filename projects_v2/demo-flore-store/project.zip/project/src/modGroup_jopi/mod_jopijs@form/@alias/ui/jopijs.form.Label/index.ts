import {JFieldLabel} from "../../../index.ts";
export default JFieldLabel;