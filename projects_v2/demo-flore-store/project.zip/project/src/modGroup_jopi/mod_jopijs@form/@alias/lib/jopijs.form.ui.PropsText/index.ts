import type {PropsText} from "../../../interfaces.ts";
export default PropsText;