import type {PropsMessage} from "../../../interfaces.ts";
export default PropsMessage;