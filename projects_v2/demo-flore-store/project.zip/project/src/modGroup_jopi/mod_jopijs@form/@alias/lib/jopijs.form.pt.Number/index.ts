import type {PassThrough_Number} from "../../../interfaces.ts";
export default PassThrough_Number;