import type {PropsAutoField} from "../../../interfaces.ts";
export default PropsAutoField;