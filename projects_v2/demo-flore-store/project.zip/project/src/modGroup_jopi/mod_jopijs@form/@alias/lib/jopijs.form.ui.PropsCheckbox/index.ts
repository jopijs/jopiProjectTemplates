import type {PropsCheckbox} from "../../../interfaces.ts";
export default PropsCheckbox;