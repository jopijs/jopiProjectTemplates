import type {IFormController} from "../../../interfaces.ts";
export default IFormController;