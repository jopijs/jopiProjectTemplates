import {JCheckboxFormField} from "../../../index.ts";
export default JCheckboxFormField;