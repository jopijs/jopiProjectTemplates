// noinspection JSUnusedGlobalSymbols

import React, {useRef} from "react";
import useVariant from "@/hooks/jopijs.variant.useVariant";
import VariantContext from "@/lib/jopijs.variant.Context";

import {
    type PropsAutoField,
    type PropsCheckbox, type PropsMessage, type PropsField,
    type PropsForm,
    type IFormController, type PropsNumber, type PropsSelectFile, type PropsText,
    type PropsLabel
} from "./interfaces.ts";

import {FormContext, JFormControllerImpl} from "./private.ts";
import {useJForm, useFormField, useJFormMessage} from "./hooks.ts";
import useLanguage from "@/hooks/jopijs.lang.useLanguage";
import { selectLang } from "jopijs/ui";

export function JForm({children, className, variants, ...p}: PropsForm & {
    children: React.ReactNode, className?: string, variants?: any
}) {
    const formRef = useRef<HTMLFormElement>(null);
    const ref = useRef<JFormControllerImpl>(new JFormControllerImpl(p, formRef));

    const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        await ref.current.submit();
    };

    return <FormContext.Provider value={ref.current}>
        <VariantContext.Provider value={variants}>
            <form ref={formRef} className={className} onSubmit={onSubmit}>{children}</form>
        </VariantContext.Provider>
    </FormContext.Provider>
}

export function JFormStateListener({custom, ifSubmitted, ifNotSubmitted}: {
    ifSubmitted?: React.ReactNode,
    ifNotSubmitted?: React.ReactNode,
    custom?: (form: IFormController) => React.ReactNode
}) {
    const form = useJForm();

    if (form.submitted || form.submitting) {
        if (ifSubmitted) return ifSubmitted;
    } else {
        if (ifNotSubmitted) return ifNotSubmitted;
    }

    return custom?.(form);
}

function renderField(variantName: string|undefined, p: PropsField) {
    const field = useFormField(p.name);
    if (!field) return <div style={{color: "red"}}><strong>Form error: the field '{p.name}' doesn't exist.</strong></div>;
    const [lang] = useLanguage();

    p = { ...p };
    
    if (p.title === undefined) {
        p.title = selectLang(lang, field.title, field.id);
    }

    if (p.description === undefined) {
        p.description = selectLang(lang, field.description);
    }

    if (p.placeholder === undefined) {
        p.placeholder = selectLang(lang, field.placeholder);
    }

    if (!variantName) {
        // For JAutoField, auto detect the variant.
        variantName = field.variantName;
    }

    let variants = p.variants;
    if (!variants) variants = React.useContext(VariantContext);
    const V = useVariant(variantName, variants, p.renderer);

    return <V {...p} field={field} variants={variants} />;
}

export function JAutoFormField(p: PropsAutoField) {
    return renderField(undefined, p);
}

//region Form Types

export function JFieldLabel(p: PropsLabel) {
    let variants = p.variants;
    if (!variants) variants = React.useContext(VariantContext);
    const V = useVariant("Label", variants, p.renderer);

    return <V {...p} variants={variants} />;
}

export function JFormMessage(p: PropsMessage) {
    const message = useJFormMessage();
    if (!message) return null;

    let variants = p.variants;
    if (!variants) variants = React.useContext(VariantContext);
    const V = useVariant("FormMessage", variants, p.renderer);

    return <V {...p} variants={variants} message={message} />;
}

export function JTextFormField(p: PropsText) {
    return renderField("TextField", p);
}

export function JNumberFormField(p: PropsNumber) {
    return renderField("NumberField", p);
}

export function JCheckboxFormField(p: PropsCheckbox) {
    return renderField("CheckboxField", p);
}

export function JSelectFileField(p: PropsSelectFile) {
    return renderField("SelectFileField", p);
}

//endregion