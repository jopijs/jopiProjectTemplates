import { type Schema, type ValidationErrors } from "jopi-toolkit/jk_schema";
import type { Translatable } from "jopi-toolkit/jk_tools";
import React from "react";

//region Core

export type TypeSubmitFunction = (params: { data: any, form: IFormController, hasFiles: boolean })
                              => Promise<ISubmitMessage|undefined|void> | ISubmitMessage | undefined | void;

/**
 * Control the state of the field.
 */
export interface IFieldController {
    form: IFormController;
    variantName: string;

    name: string;
    type: string;

    error: boolean;
    errorMessage?: string;

    id?: string;
    title?: Translatable;
    description?: Translatable;
    placeholder?: Translatable;

    value: any;
    oldValue: any;
    onChange: (value: any) => void;
    valueConverter: (value: any, isTyping: boolean) => any;

    //region Type String

    minLength?: number;
    errorMessage_minLength?: string;

    maxLength?: number;
    errorMessage_maxLength?: string;

    //endregion

    //region Type Number

    minValue?: number;
    errorMessage_minValue?: string;

    maxValue?: number;
    errorMessage_maxValue?: string;

    allowDecimal?: boolean;
    roundMethod?: "round" | "floor" | "ceil";
    errorMessage_dontAllowDecimal?: string;

    incrStep?: number;

    //endregion

    //region Type File

    maxFileCount?: number;
    errorMessage_maxFileCount?: string;

    acceptFileType?: string;
    errorMessage_invalidFileType?: string;

    maxFileSize?: number;
    errorMessage_maxFileSize?: string;

    //endregion

    //region Type Boolean

    requireTrue?: boolean;
    errorMessage_requireTrue?: string;

    requireFalse?: boolean;
    errorMessage_requireFalse?: string;

    //endregion
}

/**
 * Control the state of the form.
 * Is returned by useForm hook.
 */
export interface IFormController {
    error: boolean;
    submitting: boolean;
    submitted: boolean;
    formMessage?: ISubmitMessage;

    getData<T = any>(): T;
    getFormData(): FormData;
    getSubmitUrl(): string;

    sendFormData(url?: string): Promise<ISubmitMessage>;
    sendJsonData(url?: string): Promise<ISubmitMessage>;
}

/**
 * The message returned when submitting the form.
 */
export interface ISubmitMessage {
    isOk: boolean;
    isSubmitted: boolean;

    message?: string;
    code?: string;

    fieldErrors?: ValidationErrors;
}

//endregion

//region Components props

/**
 * The parameters of the Form component.
 */
export interface PropsForm {
    schema: Schema;
    action?: string;
    submit?: TypeSubmitFunction
}

/**
 * The core of all params for the UI field components.
 */
export interface PropsField {
    name: string;
    title?: React.ReactNode;
    description?: React.ReactNode;
    placeholder?: string;

    variants?: IVariants;
    renderer?: React.FC<any>;

    id?: string;
}

/**
 * The props for the component <FormMessage />.
 */
export interface PropsMessage {
    id?: string;
    className?: string;

    variants?: IVariants;
    renderer?: React.FC<any>;

    isBefore?: boolean;
    message?: ISubmitMessage;

    errorMessage?: React.ReactNode;
    dataErrorMessage?: React.ReactNode|false;
    submittedMessage?: React.ReactNode|false;

    hideIfFieldErrors?: boolean;
}

export interface PropsLabel {
    children: React.ReactNode;
    variants?: IVariants;
    renderer?: React.FC<any>;
    labelFor?: string;
    className?: string;

    field: IFieldController;
}

export interface PropsText extends PropsField {
}

export interface PropsCheckbox extends PropsField {
    defaultChecked?: boolean;
}

export interface PropsSelectFile extends PropsField {
}

export interface PropsNumber extends PropsField {
    minValue?: number;
    maxValue?: number;
    incrStep?: number;
}

export interface PropsAutoField extends
    PropsText,
    PropsNumber,
    PropsSelectFile,
    PropsCheckbox {
}

//endregion

//region PassThrough

export interface PassThrough_Message {
    root: string;
    text: string;
}

export interface PassThrough_Label {
    label: string;
}

export interface PassThrough_Text {
    root: string;
    textContainer: string;
    description: string;
    errorMessage: string;
    title: string;
    input: string;
}

export type PassThrough_Number = PassThrough_Text;

export interface PassThrough_Checkbox {
    root: string;
    textContainer: string;
    description: string;
    errorMessage: string;

    title: string;
    checkBox: string;
}

export interface PassThrough_SelectFile {
    root: string;

    dropZone: string;
    dropZoneIfDragOver: string;
    dropZoneIfNotDragOver: string;

    dropZoneIcon: string;
    dropZoneIconSvg: string;
    dropZoneTitle: string;
    dropZoneSubTitle: string;

    errorMessage: string;

    filePreviewRoot: string;
    filePreviewIcon: string;
    filePreviewIconSvg: string;

    fileTitle: string;
    fileSize: string;
    fileRemove: string;
    fileRemoveSvg: string;
}

//endregion

export interface IVariants {
    /**
     * The className used for error messages.
     */
    clz_ErrorMessage?: string;

    //region FormMessage

    textFormSubmitSuccess?: string;
    textFormSubmitError?: string;
    textFormDataError?: string;

    FormMessage(p: PropsMessage): React.ReactElement|null;
    ptConfirm_FormMessage?: Partial<PassThrough_Message>;
    ptConfirmExtra_FormMessage?: Partial<PassThrough_Message>;
    ptError_FormMessage?: Partial<PassThrough_Message>;
    ptErrorExtra_FormMessage?: Partial<PassThrough_Message>;

    //endregion

    //region FieldLabel

    Label(p: PropsLabel): React.ReactElement;

    pt_FieldLabel?: Partial<PassThrough_Label>;
    ptExtra_FieldLabel?: Partial<PassThrough_Label>;
    ptError_FieldLabel?: Partial<PassThrough_Label>;

    //endregion

    //region TextFormField

    TextField(p: PropsText): React.ReactElement;
    pt_TextFormField?: Partial<PassThrough_Text>;
    ptExtra_TextFormField?: Partial<PassThrough_Text>;
    ptError_TextFormField?: Partial<PassThrough_Text>;

    //endregion

    //region NumberFormField

    NumberField(p: PropsNumber): React.ReactElement;
    pt_NumberFormField?: Partial<PassThrough_Number>;
    ptExtra_NumberFormField?: Partial<PassThrough_Number>;
    ptError_NumberFormField?: Partial<PassThrough_Number>;

    //endregion

    //region CheckboxFormField

    CheckboxField(p: PropsCheckbox): React.ReactElement;
    pt_CheckboxFormField?: Partial<PassThrough_Checkbox>;
    ptExtra_CheckboxFormField?: Partial<PassThrough_Checkbox>;
    ptError_CheckboxFormField?: Partial<PassThrough_Checkbox>;

    //endregion

    //region FileSelectField

    SelectFileField(p: PropsSelectFile): React.ReactElement;

    pt_FileSelectField?: Partial<PassThrough_SelectFile>;
    ptExtra_FileSelectField?: Partial<PassThrough_SelectFile>;
    ptError_FileSelectField?: Partial<PassThrough_SelectFile>;

    textFileSelectFieldTitle?: string;
    textFileSelectFieldSubTitle?: string;
    textFileSelectFieldDragging?: string;

    //endregion

}