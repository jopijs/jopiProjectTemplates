import { MenuManager } from "../../../_menuManager/index.ts";
import { _usePage } from "jopijs/ui";

export default function (): MenuManager {
    return _usePage().valueStore.getValue<MenuManager>("jopijs.menuManager")!
}