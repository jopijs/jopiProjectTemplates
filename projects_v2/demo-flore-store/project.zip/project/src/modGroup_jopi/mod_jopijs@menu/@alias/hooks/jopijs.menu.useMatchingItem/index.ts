import ReactMenuItem from "@/lib/jopijs.menu.Item";
import useMenuManager from "@/hooks/jopijs.menu.useMenuManager";

export default function(): ReactMenuItem|undefined {
    return useMenuManager().getMatchingMenuItem();
}
