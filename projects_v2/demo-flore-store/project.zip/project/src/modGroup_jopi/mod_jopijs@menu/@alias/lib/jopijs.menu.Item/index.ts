import {ReactMenuItem} from "../../../_menuManager/index.ts";
export default ReactMenuItem;