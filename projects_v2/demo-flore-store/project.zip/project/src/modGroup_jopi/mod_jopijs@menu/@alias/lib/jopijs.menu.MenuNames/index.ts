export default {
    LEFT_MENU: "layout.left",
    RIGHT_MENU: "layout.right",
    TOP_MENU: "layout.top",
    USER_ACTIONS: "user.actions"
}