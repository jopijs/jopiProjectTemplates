import {useState} from "react";
import {isServerSide, useEvent} from "jopijs/ui";
import ReactMenuItem from "@/lib/jopijs.menu.Item";
import useMenuManager from "@/hooks/jopijs.menu.useMenuManager";

export default function(name: string): ReactMenuItem[] {
    const menuManager = useMenuManager();
    if (isServerSide) return menuManager.getMenuItems(name);

    // Will refresh one menu change.
    const [_, setCount] = useState(0);

    //TODO: use static events instead (we are inside react.js here)
    useEvent(["app.menu.invalided", "app.menu.activeItemChanged"], () => {
        setCount(count => count + 1)
    });

    return menuManager.getMenuItems(name);
}