import {JopiUiApplication} from "jopijs/ui";
import getMenuManager from "@/lib/jopijs.menu.getManager";

export default function(uiApp: JopiUiApplication) {
    // Allows initializing the menu manager. Don't remove!
    getMenuManager(uiApp);
}