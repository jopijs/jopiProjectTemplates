import { getCookieValue, JopiUiApplication, setCookie, setEventsThisValue } from "jopijs/ui";
import eventLangChange from "@/events/jopijs.lang.change";

export default function uiInit(uiApp: JopiUiApplication) {
    // Allows events to access the app instance.
    setEventsThisValue(uiApp);

    const store = uiApp.valueStore;

    store.addValueProvider<string | undefined>("lang", () => {
        let savedLang = getCookieValue("lang");
        if (!savedLang) savedLang = "en-us";
        return savedLang;
    });

    store.onValueChange<string>("lang", (newValue) => {
        setCookie("lang", newValue);
        eventLangChange.send(newValue);
    });
}