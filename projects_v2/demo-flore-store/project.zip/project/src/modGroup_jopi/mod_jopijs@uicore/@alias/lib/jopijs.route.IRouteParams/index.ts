type IRouteParams = Record<string, string>;
export default IRouteParams;
