export default function Router({ children }: { children?: React.ReactNode }) {
    return <>{children}</>;
}