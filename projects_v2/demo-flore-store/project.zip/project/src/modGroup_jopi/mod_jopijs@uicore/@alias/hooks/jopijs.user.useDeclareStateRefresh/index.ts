import {_usePage} from "jopijs/ui";

export default function() {
    const page = _usePage();

    return () => {
        page.refreshUserInfos();
        page.onRequireRefresh();
    }
}