import {_usePage} from "jopijs/ui";

export default function(): ()=>void {
    const page = _usePage();

    return () => {
        page.logOutUser();
        page.onRequireRefresh();
    }
}