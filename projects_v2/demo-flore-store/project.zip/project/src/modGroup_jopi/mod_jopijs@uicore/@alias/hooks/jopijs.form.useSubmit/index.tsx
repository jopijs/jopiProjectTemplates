import {type FormEvent, useState} from "react";
import {isServerSide} from "jopijs/ui";

/**
 * Allow submitting a form.
 *
 * @param onFormReturns
 *      A function which is called when the form call returns positively.
 * @param url
 *      An optional url to url.
 * @returns
 *      Return an array of two elements:
 *          - Set function allowing to submit the form.
 *            It takes in arg the event sent by Form.onSubmit
 *          - Set value of the form, or undefined if not submit.
 */
export default function<T = any>(onFormReturns?: (data: T) => void, url?: string): UseFormSubmitResponse<T> {
    if (isServerSide) {
        return [() => {}, undefined, false]
    }

    const [state, setState] = useState<T|undefined>(undefined);
    const [isSending, setIsSending] = useState(false);

    async function f(e: FormEvent<HTMLFormElement>) {
        e.preventDefault();
        url = url || window.location.href;

        const formData = new FormData(e.currentTarget);
        setIsSending(true);

        try {
            const response = await fetch(url!, {
                method: 'POST',
                body: formData,
                credentials: 'include'
            });

            if (response.ok) {
                let v = await response.json() as T;
                setState(v);
                if (onFormReturns) onFormReturns(v);
            } else {
                console.error("useFormSubmit - Not 200 response", response);
            }
        } catch (e) {
            console.error("useFormSubmit - Network error", e);
        }
        finally {
            setIsSending(false);
        }
    }

    return [f, state, isSending];
}

type UseFormSubmitResponse<T> = [(e: FormEvent<HTMLFormElement>) => void, T | undefined, boolean];