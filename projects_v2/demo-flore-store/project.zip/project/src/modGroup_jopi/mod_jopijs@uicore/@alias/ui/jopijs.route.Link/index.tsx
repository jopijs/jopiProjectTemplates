import ILinkProps from '@/lib/jopijs.route.ILinkProps';

export default function Link({ to, replace, children, className, ...props }: ILinkProps) {
    return (
        <a href={to} className={className} {...props}>
            {children}
        </a>
    );
}
