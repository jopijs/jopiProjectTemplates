export default interface INavigateOptions {
    replace?: boolean;
}
