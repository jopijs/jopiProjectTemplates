import React from 'react';
import IRouteParams from '@/lib/jopijs.route.IRouteParams';
import INavigateOptions from '@/lib/jopijs.route.INavigateOptions';

export default interface IRouterContextType {
    path: string;
    params: IRouteParams;
    navigate: (to: string, options?: INavigateOptions) => void;
    Component: React.ComponentType<any> | null;
}
