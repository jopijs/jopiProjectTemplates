export default function ({children}: {children: React.ReactNode}) {
    return children;
}