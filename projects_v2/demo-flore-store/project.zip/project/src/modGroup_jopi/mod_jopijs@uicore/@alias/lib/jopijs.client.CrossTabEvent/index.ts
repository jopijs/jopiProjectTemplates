/**
 * Allows to emit and listen to events from other browser tabs.
 */
export default class CrossTabEvent {
    private channel: BroadcastChannel;
    private listeners: Array<(data: any) => void> = [];

    constructor(eventName: string) {
        this.channel = new BroadcastChannel("jopi.event|" + eventName);
        
        // Listen to messages from other tabs
        this.channel.onmessage = (msg: MessageEvent) => {
            const data = msg.data;
            this.dispatchLocal(data);
        };
    }

    /**
     * Dispatch event to listeners in the CURRENT tab.
     */
    private dispatchLocal(data: any) {
        this.listeners.forEach(cb => cb(data));
    }

    /**
     * Emit an event to OTHER tabs.
     * @param data The payload
     * @param includeSelf If true, also triggers listeners in the current tab. Default false.
     */
    public emit(data: any = null, includeSelf: boolean = false): void {
        this.channel.postMessage(data);
        
        if (includeSelf) {
            this.dispatchLocal(data);
        }
    }

    /**
     * Listen for an event from other tabs (or self if emitted with includeSelf: true)
     * @param callback Function to call when event is received
     * @returns Unsubscribe function
     */
    public listen(callback: (data: any) => void): () => void {
        this.listeners.push(callback);

        // Return unsubscribe function
        return () => {
            const index = this.listeners.indexOf(callback);
            if (index > -1) this.listeners.splice(index, 1);
        };
    }
}