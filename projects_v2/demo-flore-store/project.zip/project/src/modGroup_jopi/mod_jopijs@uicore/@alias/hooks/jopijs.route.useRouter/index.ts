import React from 'react';
import IRouterContextType from '@/lib/jopijs.route.IRouterContextType';
import INavigateOptions from '@/lib/jopijs.route.INavigateOptions';

export default function useRouter(): IRouterContextType {
    return {
        path: typeof window !== 'undefined' ? window.location.pathname : '/',
        params: {},
        navigate: (to: string, options?: INavigateOptions) => {
            if (typeof window !== 'undefined') {
                if (options?.replace) {
                    window.location.replace(to);
                } else {
                    window.location.href = to;
                }
            }
        },
        Component: null
    };
}
