import {useState} from "react";
import {isServerSide} from "jopijs/ui";

export default function<T = any>(onFormReturns?: (data: T) => void, url?: string): UseSendPostDataResponse<T> {
    if (isServerSide) {
        return [() => {}, undefined, false]
    }

    const [state, setState] = useState<T|undefined>(undefined);
    const [isSending, setIsSending] = useState(false);

    async function f(data: T) {
        url = url || window.location.href;

        try {
            setIsSending(true);

            const response = await fetch(url!, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(data),
                credentials: 'include'
            });

            if (response.ok) {
                let v = await response.json() as T;
                setState(v);
                if (onFormReturns) onFormReturns(v);
            } else {
                console.error("useSendPostData - Not 200 response", response);
            }
        } catch (e) {
            console.error("useSendPostData - Network error", e);
        }
        finally {
            setIsSending(false);
        }
    }

    return [f, state, isSending];
}

type UseSendPostDataResponse<T> = [(data: T) => void, T | undefined, boolean];