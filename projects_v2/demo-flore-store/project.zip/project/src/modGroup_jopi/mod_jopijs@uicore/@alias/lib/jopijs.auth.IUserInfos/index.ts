import type {UserInfos} from "jopijs";

// Note: is also found into `mod_jopijs@uicore`.
export default UserInfos;