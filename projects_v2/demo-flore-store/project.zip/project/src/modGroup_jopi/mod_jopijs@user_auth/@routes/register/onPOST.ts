import {JopiRequest} from "jopijs";
import getAuthController from "@/lib/jopijs.auth.getAuthController";

export default async function (req: JopiRequest) {
    const controller = getAuthController();
    return controller.tryRegisterNewUser(req);
}