import React, { useState } from "react";
import useFormSubmit from "@/hooks/jopijs.form.useSubmit";
import RegisterForm from "@/ui/jopijs.auth.registerForm";

export default function() {
    const [errorCode, setErrorCode] = useState<string | null>(null);
    const [isSuccess, setIsSuccess] = useState(false);

    const [submitForm] = useFormSubmit((res: any) => {
        if (res.isOk) {
            setIsSuccess(true);
            setErrorCode(null);
        } else {
            setIsSuccess(false);
            setErrorCode(res.code || "UNKNOWN");
        }
    });

    return <RegisterForm 
        errorCode={errorCode} 
        isSuccess={isSuccess} 
        isAuhFailed={!!errorCode}
        onSubmitForm={submitForm} 
    />;
}