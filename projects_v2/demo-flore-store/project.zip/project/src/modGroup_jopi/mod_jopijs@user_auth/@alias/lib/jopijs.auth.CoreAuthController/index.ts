import IUserInfos from "@/lib/jopijs.auth.IUserInfos";
import UserEntry from "@/lib/jopijs.auth.IUserEntry";
import IAuthData from "@/lib/jopijs.auth.IAuthData";
import { JopiRequest } from "jopijs";

export default abstract class CoreAuthController {
    constructor() {
    }

    async tryRegisterNewUser(req: JopiRequest): Promise<Response> {
        const body = await req.req_getBodyData() as any;
            const data = {
                login: body.login || body.name,
                password: body.password
            };
            
            let existingUser = await this.findUser(data);
            if (existingUser) return req.res_jsonResponse({isOk: false, code: "USER_ALREADY_EXISTS"});
            
            const newUser = await this.addUser(data);
            if (!newUser) return req.res_jsonResponse({isOk: false, code: "CANNOT_CREATE_USER"});
            
            return req.res_jsonResponse({isOk: true});
    }

    async tryLoginUser(req: JopiRequest): Promise<Response> {
        const data = await req.req_getBodyData();
        const authResult = await req.user_tryAuthWithJWT(data);

        // Will automatically set a cookie containing information.
        // It why we don't return these information here.
        return req.res_jsonResponse({isOk: authResult.isOk});
    }
    
    abstract addUser(newUserInfos: Omit<IUserInfos, "id">): Promise<UserEntry | undefined>;
    abstract checkAuthData(fromBDD: IAuthData, fromBrowser: IAuthData): Promise<boolean>;

    /**
     * Search a user in the database and returns it.
     *
     * @param loginInfo
     *      The information about the user, as send by the browser.
     * @returns
     *      Return an object `UserEntry` if the user is found or `undefined`.
     *      This response will be processed by `jopijs.auth.checkAuthData`.
     */
    abstract findUser(loginInfo: IAuthData): Promise<UserEntry | undefined>;
}