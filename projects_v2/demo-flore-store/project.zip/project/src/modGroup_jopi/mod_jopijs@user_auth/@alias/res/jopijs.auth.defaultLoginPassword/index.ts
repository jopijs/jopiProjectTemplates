import res from '../../../defaultLoginPassword.json';
export default res;