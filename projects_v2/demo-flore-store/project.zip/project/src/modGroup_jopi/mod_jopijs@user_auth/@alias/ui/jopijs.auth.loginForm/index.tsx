import { FormEvent } from "react";
import { usePageTitle } from "jopijs/ui";

interface LoginFormProps {
    onSubmitForm: (e: FormEvent<HTMLFormElement>) => void;
    isAuhFailed: boolean;
}

export default function LoginForm({ onSubmitForm, isAuhFailed }: LoginFormProps) {
    usePageTitle("Login");

    return (
        <main>
            <h1>Login</h1>
            <form method="POST" onSubmit={onSubmitForm}>
                <div>
                    <label htmlFor="login">login</label>
                    <br />
                    <input type="text" id="login" name="login" style={{ border: '1px solid black', padding: '2px' }} />
                </div>
                <br />
                <div>
                    <label htmlFor="password">password</label>
                    <br />
                    <input type="password" id="password" name="password" style={{ border: '1px solid black', padding: '2px' }} />
                </div>
                <br />
                <button type="submit">Login</button>

                {isAuhFailed && (
                     <div style={{ color: 'red', marginTop: '10px' }}>
                        Authentication failed. Please check your credentials.
                     </div>
                )}
            </form>
        </main>
    );
}
