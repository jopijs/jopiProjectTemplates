import res from '../../../user.gen.json';
export default res;