import AuthController from "@/lib/jopijs.auth.AuthController";

export default function(): AuthController {
    return gAuthController
}

const gAuthController = new AuthController();