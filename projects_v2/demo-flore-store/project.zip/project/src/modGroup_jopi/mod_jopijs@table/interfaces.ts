import {type Table, type CellContext, type HeaderContext} from "@tanstack/react-table";

import * as React from "react";
import * as jk_schema from "jopi-toolkit/jk_schema";
import type {IActionContext, JDataTable} from "jopi-toolkit/jk_data";

//region Rendering

/**
 * Allows overriding the rendering rule for a field.
 *
 * Here we have two possibilities:
 * - Merging these rules with the current rendering rules.
 * - Overriding the current rendering rules.
 *
 * The rules here have a main difference with the base class `jk_schema.ScOnTableRenderingInfo`
 * that allows directly using a React component for rendering cell and column header.
 */
export interface IFieldRenderingRules extends Omit<jk_schema.ScOnTableRenderingInfo, "rendererForCell" | "rendererForHeader"> {
    /**
     * Allows merging or replacing the default settings for the field.
     * Default is merging.
     */
    mergeMode?: "replace" | "merge";

    rendererForCell?: string|TypeCellRendererProvider;
    rendererForHeader?: string|TypeCellRendererProvider;
}

/**
 * Allows overriding the rendering rule for a field.
 *
 * Override `jk_schema.Field` by replacing `onTableRendering`
 * with a version where we can directly use a React component for rendering cell and column header.
 */
export interface IFieldWithRenderer extends Omit<jk_schema.Field, "onTableRendering"> {
    onTableRendering?: IFieldRenderingRules;
}

export type TypeCellRenderer = (row: CellContext<any, any>) => React.ReactNode;
export type TypeCellRendererProvider = (p: IVariantCellRendererParams) => TypeCellRenderer;

export type TypeHeaderRenderer = (row: HeaderContext<any, any>) => React.ReactNode;
export type TypeValueRenderer = (value: React.ReactNode) => React.ReactNode;

/**
 * This object is sent to the component rendering the table.
 * It contains the main element to display:
 * - The table itself.
 * - The filter input.
 * - The page selector.
 * - The column selector.
 * - The statistics.
 */
export interface ITableLayoutRendererParams {
    /**
     * Is set to true if data are loading.
     */
    isLoadingData: boolean;

    /**
     * Is set to true if the data are refreshing in the background.
     */
    isRefreshingData: boolean;

    variants: IVariants;

    table: React.ReactElement;
    filter?: false | React.ReactNode;
    pageSelector?: false | React.ReactNode;
    columnsSelector?: false | React.ReactNode;
    toggleSelected?: false | React.ReactNode;
    statistics?: false | React.ReactNode;
    groupActions?: false | React.ReactNode;
}

//endregion

//region Actions

export interface IActionItem {
    title?: string;
    onClick?: (data: any, context: IActionContext) => void;
    separator?: true;
}

export type TypeActionsProvider = (data: any, context: IActionContext) => (IActionItem[])|undefined;

//endregion

//region Call params

export interface ICreateColumnsParams extends TableComponentProps {
}

export interface IVariantColumnHeaderRendererParams {
    fieldId: string;
    field: IFieldWithRenderer;

    canSort?: boolean;
    canEdit?: boolean;

    title: string;

    builderParams: ICreateColumnsParams;

    variants: IVariants;
}

export interface IVariantCellRendererParams extends IVariantColumnHeaderRendererParams {}

export interface IVariantColumnSelectorRendererParams {
    table: Table<any>;
    isLoadingData?: boolean;
}

export interface IVariantPageSelectorRendererParams {
    table: Table<any>;
    isLoadingData?: boolean;
}

export interface IVariantToggleSelectedRendererParams {
    table: Table<any>;
    showSelectedOnly: boolean;
    setShowSelectedOnly: (show: boolean) => void;
    isLoadingData?: boolean;
}

export interface IVariantGroupActionsRendererParams {
    table: Table<any>;
    actions?: TypeActionsProvider;
    dataSource?: JDataTable;
    lang: string;
}

export interface IVariantStatisticsRendererParams {
    table: Table<any>;
    isLoadingData?: boolean;
}

export interface IVariantTableRenderParams {
    table: Table<any>;
    ifNoContent: React.ReactNode;
}

export interface IVariantFilterRendererParams {
    table: Table<any>;
    filterField?: string;
    placeholder?: string
    isLoadingData?: boolean;

    filter: string;
    setFilter: (filter: string) => void;
}

//endregion

/**
 * The props of the component displaying the table.
 */
export interface TableComponentProps {
    data?: any[];
    dataSource?: JDataTable;
    schema?: jk_schema.Schema;

    variants: IVariants;
    children?: React.ReactNode;
    showColumnsSelector?: boolean;

    filterPlaceholder?: string;
    filterField?: string;
    showFilter?: boolean;

    enableEditing?: boolean;
    canSelectColumns?: boolean;

    /**
     * The maximum number of row to show.
     */
    pageSize?: number;

    /**
     * The default currency to use (USD, EURO, ...).
     */
    defaultCurrency?: string;

    /**
     * The default local to use for formating value (fr-FR, en-US, ...).
     */
    defaultLocal?: string;

    /**
     * Allow overriding the rendering information for the columns.
     *
     * Note: type FieldRenderingRules is equivalent to jk_schema.ScOnTableRenderingInfo
     *       but allow directly using a CellRenderer as rendererForCell and rendererForHeader.
     */
    columnsOverride?: Record<string, IFieldRenderingRules>;

    /**
     * Allows adding actions to the table.
     * The provider will evaluate the row and return corresponding actions.
     */
    actions?: TypeActionsProvider;

    /**
     * The field to use as the unique identifier for the row.
     * Default is "id".
     */
    rowIdField?: string;
}

export interface IVariants {
    /**
     * The with of the select row.
     * If not set, the default value is 40px.
     */
    selectRowWidth?: number;

    /**
     * The width of the action row.
     * If not set, the default value is 40px.
     */
    actionRowWidth?: number;

    createActionCell: (actions: TypeActionsProvider|undefined, proxy: JDataTable|undefined, lang: string) => TypeCellRenderer;
    selectRowsHeaderRenderer: () => TypeHeaderRenderer|string;
    selectRowsCellRenderer: () => TypeCellRenderer;

    // Cell rendering
    //
    wrapCellValue: (params: IVariantCellRendererParams) => TypeValueRenderer;
    cellRenderer: (params: IVariantCellRendererParams) => TypeCellRenderer;
    cellRenderer_currency?: (params: IVariantCellRendererParams) => TypeCellRenderer;
    cellRenderer_percent?: (params: IVariantCellRendererParams) => TypeCellRenderer;
    cellRenderer_decimal?: (params: IVariantCellRendererParams) => TypeCellRenderer;
    cellRenderer_number?: (params: IVariantCellRendererParams) => TypeCellRenderer;
    //
    columnHeaderRenderer: (params: IVariantColumnHeaderRendererParams) => TypeHeaderRenderer|string;

    tableRenderer: (params: IVariantTableRenderParams) => React.ReactElement;
    layoutRenderer: (items: ITableLayoutRendererParams) => React.ReactNode;

    // UI Components
    //
    statisticsRenderer: (params: IVariantStatisticsRendererParams) => React.ReactNode;
    pageSelectorRenderer: (params: IVariantPageSelectorRendererParams) => React.ReactNode;
    columnsSelectorRenderer: (params: IVariantColumnSelectorRendererParams) => React.ReactNode;
    filterRenderer: (params: IVariantFilterRendererParams) => React.ReactNode;
    groupActionsRenderer: (params: IVariantGroupActionsRendererParams) => React.ReactNode;
    toggleSelectedRenderer: (params: IVariantToggleSelectedRendererParams) => React.ReactNode;

    loadingScreenRenderer: (p: {text: React.ReactNode}) => React.ReactNode;
    loadingScreenText: React.ReactNode;

    [renderer: string]: any;
}