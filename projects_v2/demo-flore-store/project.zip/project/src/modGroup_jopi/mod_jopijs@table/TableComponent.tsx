// noinspection DuplicatedCode

import {
    type ColumnFiltersState, getCoreRowModel, getFilteredRowModel, getPaginationRowModel, getSortedRowModel,
    type SortingState, useReactTable, type VisibilityState, type ColumnDef, type PaginationState
} from "@tanstack/react-table";

import * as React from "react";
import * as jk_schema from "jopi-toolkit/jk_schema";
import type {
    TypeCellRenderer, IVariantCellRendererParams, TypeCellRendererProvider, IVariantColumnHeaderRendererParams,
    ICreateColumnsParams,
    IFieldRenderingRules,
    IFieldWithRenderer,
    TableComponentProps
} from "./interfaces.ts";
import {useState} from "react";

import {type JDataReadParams} from "jopi-toolkit/jk_data";
import {useQuery} from '@tanstack/react-query'
import useLanguage from '@/hooks/jopijs.lang.useLanguage';

function getNormalizedScheme(params: ICreateColumnsParams): Record<string, IFieldWithRenderer> {
    function merge(baseRules: jk_schema.ScOnTableRenderingInfo|undefined, newRules: IFieldRenderingRules) {
        if (!baseRules) return newRules;
        if (newRules.mergeMode === "replace") return newRules;
        return {...baseRules, ...newRules};
    }

    if (!params.columnsOverride) {
        return params.schema!.desc;
    }

    let fields = params.schema!.desc;
    let res: Record<string, IFieldWithRenderer> = {};

    for (const [fieldId, field] of Object.entries(fields)) {
        let override = params.columnsOverride[fieldId];

        if (override) {
            let field2: IFieldWithRenderer = {...field};
            field2.onTableRendering = merge(field.onTableRendering, override);
            res[fieldId] = field2;
        } else {
            res[fieldId] = field;
        }
    }

    return res;
}

function calcColumnsVisibility(params: ICreateColumnsParams): VisibilityState {
    let result: VisibilityState = {};
    let fields = getNormalizedScheme(params);

    for (const [fieldId, field] of Object.entries(fields)) {
        if (field.onTableRendering?.defaultHidden) {
            result[fieldId] = false;
        }
    }

    return result;
}

function createColumns<T>(params: ICreateColumnsParams, lang: string): ColumnDef<T>[] {
    function getCellCoreRenderer(p: IVariantCellRendererParams): TypeCellRenderer {
        if (p.field.onTableRendering?.rendererForCell) {
            let rendererValue = p.field.onTableRendering!.rendererForCell;

            if (typeof rendererValue === "string") {
                if (p.canEdit) rendererValue += "__edit";
                let renderer = params.variants[rendererValue];
                if (renderer) return (renderer as TypeCellRendererProvider)(p);

                if (p.canEdit) {
                    renderer = params.variants[rendererValue];
                    if (renderer) return (renderer as TypeCellRendererProvider)(p);
                }
            } else {
                return rendererValue(p);
            }
        }

        // number car be displayed as decimal /percent / currency or simple number.
        //
        if (p.field.type==="number") {
            let fieldNumber = p.field as jk_schema.ScNumber;
            let displayType = fieldNumber.displayType;

            let renderer: undefined | ((params: IVariantCellRendererParams) => TypeCellRenderer);

            if (displayType==="currency") {
                renderer = params.variants.cellRenderer_currency;
            } else if (displayType==="percent") {
                renderer = params.variants.cellRenderer_percent;
            } else if (displayType==="decimal") {
                renderer = params.variants.cellRenderer_decimal;
            }

            if (!renderer) {
                renderer = params.variants.cellRenderer_number;
            }

            if (renderer) {
                return renderer(p);
            }
        }

        return params.variants.cellRenderer(p);
    }

    let fields = getNormalizedScheme(params);
    let result: ColumnDef<T>[] = [];

    if (params.canSelectColumns) {
        result.push({
            id: "!select",

            header: params.variants.selectRowsHeaderRenderer(),
            cell:params.variants.selectRowsCellRenderer(),

            enableSorting: false,
            enableHiding: false,

            size: params.variants.selectRowWidth ? params.variants.selectRowWidth : 40
        })
    }

    for (const [fieldId, field] of Object.entries(fields)) {
        if (field.onTableRendering?.alwaysHidden) continue;

        let canHide = field.onTableRendering?.enableHiding;
        if (canHide===undefined) canHide = true;

        let canSort = field.onTableRendering?.enableSorting !== false;
        let canEdit = params.enableEditing === true;

        let title = field.id;
        //
        if (field.title) {
            if (typeof field.title === "string") {
                title = field.title;
            } else {
                title = field.title[lang];
            }
        }

        if (field.onTableRendering?.title) title = field.onTableRendering!.title;

        const p: IVariantColumnHeaderRendererParams = {
            builderParams: params, variants: params.variants,
            fieldId, field, canSort, canEdit, title
        };

        const cellRenderer = getCellCoreRenderer(p);
        const headerRenderer = params.variants.columnHeaderRenderer(p);

        let growStrategy = field.onTableRendering?.columnGrow;

        result.push({
            accessorKey: fieldId,
            enableSorting: p.canSort,
            enableHiding: canHide,

            cell: cellRenderer,
            header: headerRenderer,

            enableResizing: growStrategy !== "takeAllPlace"
        });
    }

    if (params.actions || params.dataSource) {
        result.push({
            id: "!actions",

            cell: params.variants.createActionCell(params.actions, params.dataSource, lang),

            enableSorting: false,
            enableHiding: false,

            size: params.variants.actionRowWidth ? params.variants.actionRowWidth : 40
        });
    }

    return result;
}

export function TableComponent(p: TableComponentProps) {
    p = {...p};
    if (p.dataSource) p.schema = p.dataSource.schema;
    if (!p.schema) throw new Error("A schema must be provided.");

    const [lang] = useLanguage();
    const [sorting, setSorting] = React.useState<SortingState>([]);

    const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([]);
    const [rowSelection, setRowSelection] = React.useState({});
    const [showSelectedOnly, setShowSelectedOnly] = React.useState(false);

    const [columnVisibility, setColumnVisibility] = React.useState<VisibilityState>(() => calcColumnsVisibility(p));
    const columns = React.useMemo(() => createColumns(p, lang), [lang]);

    const [page, setPage] = useState<PaginationState>({pageIndex: 0, pageSize: p.pageSize || 20});
    const [filter, setFilter] = React.useState("");

    const [previousQueryData, setPreviousQueryData] = useState<any>(undefined);

    function doSetFilter(newValue: string) {
        setFilter(newValue);
        setPage({pageIndex: 0, pageSize: page.pageSize});

        if (p.filterField) {
            return tTable.getColumn(p.filterField)?.setFilterValue(newValue)
        } else {
            return tTable.setGlobalFilter(newValue);
        }
    }
    
    function doSetSorting(sorting: SortingState) {
        setSorting(sorting);
        setPage({pageIndex: 0, pageSize: page.pageSize});
    }

    let queryData: any = undefined;

    // Data are loading / fetching state
    //
    // -- Workflow--
    // 1- isLoadingData is true
    // 2- TanStack takes data from the local cache
    //    --> isLoadingData = false
    //    + we show the cached data
    // 3- In the background, TanStack loads data from the server
    //    --> isRefreshingData = true
    // 4- Data are loaded from the server
    //    --> isRefreshingData = true
    //    + we show the refreshed data
    //
    let isLoadingData = false;
    let isRefreshingData = false;
    let refetchTableData: (() => void) | undefined = undefined;


    function doSetShowSelectedOnly(show: boolean) {
        setShowSelectedOnly(show);
        if (show) {
            setPage({ ...page, pageIndex: 0 });
        }
    }

    if (p.dataSource) {
        // Prepare the query key/params
        const queryParams: any = {
            page, 
            sorting,
        };

        if (showSelectedOnly) {
            // "Show selected only" mode:
            // - We ignore the global search filter (usually) to show all selected items.
            // - We filter by ID using the current selection.
            //
            // Data sample: { "123": true, "456": false, "789": true }.
            //
            const idField = p.rowIdField || "id";
            // Filter, only items with true value
            const selectedIds = Object.keys(rowSelection).filter(k => (rowSelection as any)[k]);
            
            // Fix: TanStack table stores keys as strings.
            // If the actual ID is a number, we must convert it back to number
            // otherwise the backend filter might fail (strict type check).
            //
            let idsToFilter: any[] = selectedIds;
            const rowsForTypeCheck = previousQueryData?.rows || [];
            
            if (rowsForTypeCheck.length > 0) {
                 // Take a sample to know if is number or string.
                const sampleId = rowsForTypeCheck[0][idField];
                
                // Convert to number if needed
                if (typeof sampleId === 'number') {
                    idsToFilter = selectedIds.map(id => Number(id));
                }
            }

            // Create the filter, only selected items.
            //
            queryParams.fieldFilters = {
                [idField]: [{
                    constraint: "$in",
                    value: idsToFilter as any
                }]
            };

            // Adapt page size, to show all selected items in one go.
            //
            queryParams.page = {
                pageIndex: 0,
                pageSize: Math.max(selectedIds.length, 20) 
            };
        } else {
            // Standard mode
            if (filter) {
                queryParams.filter = {field: p.filterField, value: filter};
            }
        }

        const query = useQuery({
            queryKey: ["dsTable", p.dataSource!.name, queryParams],

            queryFn: async (ctx) => {
                return p.dataSource?.read(ctx.queryKey[2] as JDataReadParams);
            },

            // The placeholder data are date returned while
            // loading the initial data set. Here where use the previous data set.
            // Doing that avoids screen flickering.
            //
            placeholderData: previousQueryData
        });

        // dataUpdatedAt allows knowing we are not
        // using the local cache nor the data placeholder.
        //
        isLoadingData = (query.isLoading === true) || (!query.dataUpdatedAt);

        isRefreshingData = query.isFetching === true;

        queryData = query.data;

        // It allows avoiding emptying when no cached data are available.
        if (previousQueryData != queryData) setPreviousQueryData(queryData);

        refetchTableData = query.refetch;
    }

    const rawData = p.dataSource ? queryData?.rows || [] : p.data!;

    const tableData = React.useMemo(() => {
        if (!showSelectedOnly) return rawData;
        
        // When showing selected only, we filter the current data.
        // Note: For server-side data, this only filters the *currently loaded page.
        //
        const idField = p.rowIdField || "id";
        //
        return rawData.filter((r: any) => {
            const id = r[idField];

            if (id !== undefined) {
                // Is a selected row?
                return (rowSelection as Record<string, boolean>)[String(id)];
            }
            
            return false; 
        });
    }, [rawData, showSelectedOnly, rowSelection, p.rowIdField]);

    const tTable = useReactTable({
        state: {
            sorting,
            columnFilters,
            columnVisibility,
            rowSelection,
            pagination: page
        },

        data: tableData,
        rowCount: p.dataSource ? queryData?.total : undefined,
        manualPagination: p.dataSource ? true : undefined,
        manualSorting: p.dataSource ? true : undefined,

        columns: columns,
        onPaginationChange: setPage,

        onSortingChange: (updater) => {
            const newSorting = typeof updater === 'function' ? updater(sorting) : updater;
            doSetSorting(newSorting);
        },

        onColumnFiltersChange: setColumnFilters,
        getCoreRowModel: getCoreRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
        getSortedRowModel: getSortedRowModel(),
        getFilteredRowModel: getFilteredRowModel(),
        onColumnVisibilityChange: setColumnVisibility,
        onRowSelectionChange: setRowSelection,

        getRowId: (row: any, index: number) => {
            const idField = p.rowIdField || "id";
            const id = row[idField];
            // If the ID is present, we use it. 
            // Otherwise, we fallback to the index which will cause the selection bug
            // but at least it won't crash.
            return id !== undefined ? String(id) : String(index);
        },

        meta: {
            refresh: () => refetchTableData?.()
        }
    });

    return p.variants.layoutRenderer({
        isLoadingData: isLoadingData,
        isRefreshingData: !isLoadingData && isRefreshingData,

        variants: p.variants,

        table: p.variants.tableRenderer({table: tTable, ifNoContent: p.children}),

        filter: (p.showFilter!==false) && p.variants.filterRenderer({
            table: tTable,
            isLoadingData: isRefreshingData,
            filterField: p.filterField,
            placeholder: p.filterPlaceholder,
            filter, setFilter: doSetFilter
        }),

        toggleSelected: p.variants.toggleSelectedRenderer({
            table: tTable,
            showSelectedOnly,
            setShowSelectedOnly: doSetShowSelectedOnly,
            isLoadingData: isRefreshingData
        }),

        columnsSelector: (p.showColumnsSelector!==false) && p.variants.columnsSelectorRenderer({table: tTable, isLoadingData: isRefreshingData}),
        statistics: p.variants.statisticsRenderer({table: tTable, isLoadingData: isRefreshingData}),
        pageSelector: p.variants.pageSelectorRenderer({table: tTable, isLoadingData: isRefreshingData}),
        groupActions: p.variants.groupActionsRenderer({table: tTable, actions: p.actions, dataSource: p.dataSource, lang})
    });
}