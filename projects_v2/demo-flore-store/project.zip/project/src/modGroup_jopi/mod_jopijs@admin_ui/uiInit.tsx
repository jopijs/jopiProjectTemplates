import {JopiUiApplication} from "jopijs/ui";
import MenuNames from "@/lib/jopijs.menu.MenuNames";
import getMenuManager from "@/lib/jopijs.menu.getManager";
import eventLogOut from "@/events/admin.user.logout";

import {
  BadgeCheck,
  Bell,
  CreditCard,
  LogOut,
  Sparkles,
} from "lucide-react"

export default function(myModule: JopiUiApplication) {
    const menuManager = getMenuManager(myModule);

    menuManager.addMenuBuilder(MenuNames.USER_ACTIONS, (menu) => {       
        menu.set(["Upgrade to Pro"], {url: "/user/", icon: Sparkles});     
        menu.set(["Account"], {url: "/user/", icon: BadgeCheck});
        menu.set(["-1"], {url: "/user/", icon: BadgeCheck, title: "-"});
        menu.set(["Billing"], {url: "/user/", icon: CreditCard});
        menu.set(["Notifications"], {url: "/user/", icon: Bell});
        menu.set(["Logout"], {
            url: "#", 
            icon: LogOut,
            onClick: () => {
                eventLogOut.send();
            }
        });
    });
}