import {jopiApp} from "jopijs";

// > This file 'index.ts' is our application entry-point.
//   It's executed once the application starts.

// `jopiApp.startApp` allows starting our application.
jopiApp.startApp(

    // `import.meta` is a JavaScript feature allowing use to know
    // what is the full-path of this source code file.
    //
    // The JavaScript engine updates `import.meta` for each file
    // with information on this file.
    //
    import.meta,

    // Reference to the website.
    // Allows configuring it.
    //
    webSite => {
        /*webSite.configure_behaviors()
            .setCookieDefaults({
                sameSite: "None",
                secure: true
            })
            .DONE_configure_behaviors();

            // Allows generating a local dev certificate.
            // The tool "mkcert" must be installed on your system.
            //
            webSite.add_httpCertificate()
                .generate_localDevCert()
                .DONE_add_httpCertificate();*/

            // CORS is enabled by default.
            // Here it will allow you to add allowed sources.
            //
            //webSite.configure_cors()
            //    .add_allowedHost("http://mywebsiteA")
            //    .add_allowedHost("http://mywebsiteB")
            //    .DONE_configure_cors();

            // This setting allows slowing down the HTTP request for data-sources.
            // It's useful if you want to test some wait indicators.
            //
            //webSite.configure_devBehaviors()
            //    .slowDownHttpDataSources(500)
            //    .DONE_configure_devBehaviors()
    }
);