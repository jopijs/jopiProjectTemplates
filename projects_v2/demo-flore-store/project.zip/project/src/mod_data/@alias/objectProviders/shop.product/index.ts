import DataController from "@/lib/shop.controller.product";
import IProduct from "@/lib/shop.IProduct";
import IDbProduct from "@/lib/shop.IDbProduct";

const db = new DataController();

import type { ObjectProvider } from "jopijs";

export default <ObjectProvider>{
    getDefaultSubCache() {
        return "en-us";
    },
    
    async getValue(productId?: number, lang: string = "en-us") {
        if (!productId) return {};
    
        let found: IDbProduct | undefined;
    
        for await (const product of db.iterateProducts()) {
            if (product.id === productId) {
                found = product;
                break;
            }
        }
        
        if (!found) return {};
    
        const product: IProduct = {
            ...found as any,
            slug: found.slug,
            name: found.name[lang as keyof typeof found.name],
            description: found.description[lang as keyof typeof found.name]
        };
    
        return { value: product };
    }
}