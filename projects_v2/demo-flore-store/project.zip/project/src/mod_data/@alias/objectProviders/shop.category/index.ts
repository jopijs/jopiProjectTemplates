import DataController from "@/lib/shop.controller.product";

const db = new DataController();

import type { ObjectProvider } from "jopijs";

export default <ObjectProvider>{
    getDefaultSubCache() {
        return "en-us";
    },

    async getValue(id?: string) {
        if (id) {
            const category = await db.getCategory(id);
    
            if (!category) {
                return { value: [] };
            }
    
            return { value: category.productIds };
        }
    
        const allCategories = await db.getAllCategories();
        const result: Record<string, any> = {};
    
        for (const cat of allCategories) {
            result[cat.id] = cat;
        }
    
        return { value: result };
    }
}