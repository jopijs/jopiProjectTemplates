import DataController from "@/lib/shop.controller.product";
import getProduct from "@/objectProviders/shop.product";

const db = new DataController();

import type { ObjectProvider } from "jopijs";

export default <ObjectProvider>{
    getDefaultSubCache() {
        return "en-us";
    },
    
    async getValue(slug?: string, lang: string = "en-us") {
        if (!slug) return {};
    
        let productId = await db.getProductIdBySlug(slug);
        if (productId === undefined) return {};
        
        const value = await getProduct.useSubCache(lang).getValue(productId);

        return {
            // Note: this will be added to the cache.
            // It's not a duplicate, since the object instance is the same.
            // It will take the same memory place.
            //
            value
        }
    }
}