import * as jk_fs from "jopi-toolkit/jk_fs";
import { logDataController } from "./_logs.ts";
import IDbProduct from "@/lib/shop.IDbProduct";
import ICategory from "@/lib/shop.ICategory";

export interface DataControllerConfig {
    dataRoot?: string;
}

/**
 * DataController manages the JSON-based file storage for products and categories.
 * It provides a localized product data system where each product and category is stored
 * in its own JSON file for better maintainability and performance.
 */
export default class DataController {
    /** Root directory where JSON data files are stored */
    private dataRoot: string;

    /**
     * @param config - Configuration for the data controller
     * @param config.dataRoot - Optional custom path for the data directory. Defaults to './data/json-data'.
     */
    constructor(config?: DataControllerConfig) {
        this.dataRoot = jk_fs.resolve(config?.dataRoot || jk_fs.join('data', 'json-data'));
    }

    /** Returns the absolute path to the products directory */
    private get productsPath() { return jk_fs.join(this.dataRoot, 'products'); }
    
    /** Returns the absolute path to the categories directory */
    private get categoriesPath() { return jk_fs.join(this.dataRoot, 'categories'); }

    private _isInit = false;

    /**
     * Initializes the data storage by ensuring the required directories exist.
     * Uses jk_fs.mkDir which handles recursive directory creation.
     */
    private async init() {
        if (this._isInit) return;
        this._isInit = true;

        await jk_fs.mkDir(this.productsPath);
        await jk_fs.mkDir(this.categoriesPath);
    }

    /**
     * Retrieves a single product by its numeric ID.
     * @param id - The unique numeric ID of the product.
     * @returns The Product object if found, or undefined if the file doesn't exist or is invalid.
     */
    async getProduct(id: number): Promise<IDbProduct | undefined> {
        logDataController.spam(`Getting product ${id}`);
        return await jk_fs.readJsonFromFile<IDbProduct>(jk_fs.join(this.productsPath, `${id}.json`));
    }

    /**
     * Finds a product ID by its unique slug.
     * Uses the product iterator to search through all product files.
     * @param slug - The slug to search for.
     * @returns The product ID if found, or undefined if no product matches the slug.
     */
    async getProductIdBySlug(slug: string): Promise<number | undefined> {
        logDataController.spam(`Searching for product ID with slug: ${slug}`);

        for await (const product of this.iterateProducts()) {
            if (product.slug === slug) {
                return product.id;
            }
        }
        
        return undefined;
    }

    /**
     * Iterates over all products stored in the products directory using an async generator.
     * This avoids loading all product JSON contents into memory at once.
     * @yields Product objects one by one.
     */
    async *iterateProducts(): AsyncGenerator<IDbProduct> {
        await this.init();

        try {
            const files = await jk_fs.listDir(this.productsPath);
            for (const file of files) {
                // Only process files with .json extension
                if (file.isFile && file.name.endsWith('.json')) {
                    const product = await jk_fs.readJsonFromFile<IDbProduct>(file.fullPath);
                    if (product) {
                        yield product;
                    }
                }
            }
        } catch (error) {
            logDataController.error(`Error iterating products directory: ${error}`);
        }
    }

    /**
     * Saves or updates a product file.
     * Automatically triggers a category index rebuild unless specified otherwise.
     * @param product - The product object to save.
     * @param autoRebuildCategories - If true, automatically rebuilds the category index files.
     */
    async saveProduct(product: IDbProduct, autoRebuildCategories = true) {
        logDataController.spam(`Saving product ${product.id}`);

        await this.init();
        const filePath = jk_fs.join(this.productsPath, `${product.id}.json`);
        await jk_fs.writeTextToFile(filePath, JSON.stringify(product, null, 2));
        
        if (autoRebuildCategories) {
            await this.rebuildCategories();
        }
    }

    /**
     * Rebuilds all category JSON files.
     * This function scans all products and creates an index file for each category
     * containing the list of product IDs belonging to that category.
     * This optimizes category-based product lookups.
     */
    async rebuildCategories() {
        logDataController.spam('Rebuilding categories...');

        await this.init();
        const categoryMap = new Map<string, number[]>();

        // 1. Group all product IDs by their categories using the iterator
        for await (const product of this.iterateProducts()) {
            if (product.categories && Array.isArray(product.categories)) {
                for (const categoryId of product.categories) {
                    if (!categoryMap.has(categoryId)) {
                        categoryMap.set(categoryId, []);
                    }

                    categoryMap.get(categoryId)!.push(product.id);
                }
            }
        }

        // 2. Generate an index file per category (e.g., categories/bouquets.json)
        for (const [catId, productIds] of categoryMap) {
            const category: ICategory = {
                id: catId,
                productIds: productIds.sort((a, b) => a - b)
            };
            
            await jk_fs.writeTextToFile(
                jk_fs.join(this.categoriesPath, `${catId}.json`),
                JSON.stringify(category, null, 2)
            );
        }
    }
    
    /**
     * Retrieves the index for a specific category.
     * @param id - The category slug/ID (e.g., 'bouquets').
     * @returns The Category object containing product IDs, or null if not found.
     */
    async getCategory(id: string): Promise<ICategory | undefined> {
        logDataController.spam(`Getting category ${id}`);
        return await jk_fs.readJsonFromFile<ICategory>(jk_fs.join(this.categoriesPath, `${id}.json`));
    }

    /**
     * Retrieves all categories stored in the categories directory.
     * @returns An array of Category objects.
     */
    async getAllCategories(): Promise<ICategory[]> {
        logDataController.spam('Getting all categories');

        await this.init();
        const files = await jk_fs.listDir(this.categoriesPath);
        const categories: ICategory[] = [];

        for (const file of files) {
            if (file.isFile && file.name.endsWith('.json')) {
                const cat = await jk_fs.readJsonFromFile<ICategory>(file.fullPath);
                if (cat) categories.push(cat);
            }
        }

        return categories;
    }

    /**
     * Utility method to migrate data from a single large index.json file
     * to the new split-file architecture.
     * 
     * TODO: remove
     * @param legacyIndexData - The data from the old index.json file.
     */
    async importFromLegacyIndex(legacyIndexData: { products: IDbProduct[] }) {
        await this.init();
        logDataController.info(`Importing ${legacyIndexData.products.length} products...`);
        
        for (const product of legacyIndexData.products) {
            // Save product without rebuilding categories every time for performance
            await this.saveProduct(product, false);
        }
        
        logDataController.info('Rebuilding categories...');
        // Perform a single category rebuild at the end of import
        await this.rebuildCategories();
        logDataController.info('Import done.');
    }
}
