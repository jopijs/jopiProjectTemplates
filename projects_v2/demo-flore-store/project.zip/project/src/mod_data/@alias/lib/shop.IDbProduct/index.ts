import IProduct from "@/lib/shop.IProduct";

export default interface IDbProduct extends Omit<IProduct, "name" | "description"> {
    name: Record<string, string>;
    description: Record<string, string>;
}