import {getLogger} from "jopi-toolkit/jk_logs";

export const logDataController = getLogger("shop.product.controller");