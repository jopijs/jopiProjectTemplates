export default interface Category {
    id: string;
    productIds: number[];
}
