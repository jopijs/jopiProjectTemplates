# @jopijs/jopimod_cart

This module manages the shopping cart features for the application. It handles product storage, price calculations, persistence, and synchronization across browser tabs.

## Role of the Module

The `mod_cart` acts as the central engine for e-commerce shopping experiences. Its key responsibilities include:

-   **State Management**: maintains the current list of items in the cart.
-   **Calculations**: Automatically computes sub-totals, taxes, shipping fees, and the grand total.
-   **Persistence**: Saves cart state in cookies to persist across page reloads and sessions.
-   **Synchronization**: Synchronizes cart state across multiple open tabs using `CrossTabEvent`.
-   **Product Resolution**: Verifies product details against the source of truth (`productsData`) to ensure valid prices and names.

## Structure

-   `@routes/cart`: The main route displaying the full cart page.
-   `@alias/lib/shop.ui.cartController`: The logic core (Singleton) controlling cart operations.
-   `@alias/hooks/shop.useCart`: A React hook for accessing the cart state reactively.
-   `@alias/ui`: UI components like `CartWidget`, `CartPageContent`, `InvoicePDF`.

## API Reference

### Events

Use these events to modify the cart state from anywhere in the application.

*   `shop.cart.add.product`: Trigger this to add an item.
    -   **Payload**: `ICartItem` (e.g. `{ id: 123, name: "Rose", price: 10, quantity: 1 }`)
*   `shop.cart.update.quantity`: Trigger this to increment/decrement item quantity.
    -   **Payload**: `{ productId: number, quantity: number }` (quantity is a delta, e.g. `1` or `-1`)
*   `shop.cart.updated`: Listen to this to react to cart changes.
    -   **Payload**: `ICart` (the full cart object)

### Hooks

*   `useCart()`: Returns the reactive `ICart` object. It automatically re-renders your component when `shop.cart.updated` is fired.

### CartController

*   **Access**: `CartController.get(uiApp)`
*   **Methods**:
    -   `getCart()`: Get current state (non-reactive).
    -   `addProduct(...)`: Internal logic for adding products.
    -   `updateQuantity(...)`: Internal logic for changing quantities.
    -   `saveCart()`: Persist to cookie.

## Examples

### Adding a Product to Cart

**Important:** You should never access `CartController` directly to add products. Instead, use the global event definition.

```typescript
import eventAddProduct from "@/events/shop.cart.add.product";

export const AddButton = ({ product }) => {
    
    const handleAdd = () => {
        eventAddProduct.send({
            id: product.id,
            name: product.name,
            price: product.price,
            quantity: 1
        });
    };

    return <button onClick={handleAdd}>Add to Cart</button>;
};
```

### Displaying Cart Summary

Use the `useCart` hook to build a dynamic cart summary that updates automatically.

```typescript
import useCart from "@/hooks/shop.useCart";

export const CartSummary = () => {
    const cart = useCart();

    if (cart.items.length === 0) return <div>Your cart is empty</div>;

    return (
        <div className="cart-summary">
            <h2>Total: {cart.total}€</h2>
            <p>{cart.items.length} items</p>
        </div>
    );
};
```
