import { JopiUiApplication } from "jopijs/ui";
import CartController from "@/lib/shop.ui.cartController";

export default function (uiApp: JopiUiApplication) {
    uiApp.valueStore.addValueProvider("shop.ui.cartController", () => {
        return new CartController();
    });
}