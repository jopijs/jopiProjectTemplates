import { JopiPageDataProvider } from "jopijs";
import getProduct from "@/objectProviders/shop.product";
import CartController from "@/lib/shop.server.cartController";

export default {
    async getDataForCache({ req }) {
        const controller = new CartController(req);
        const cart = controller.getCart();
        
        const items = cart.items || [];
        const lang = req.cookie_getReqCookie("lang", "en-us") || "en-us";
        
        const refreshedItems = await Promise.all(items.map(async (item: any) => {
            const p = await getProduct.get({ productId: item.id, lang });
            
                if (p) {
                    return { 
                        ...item, 
                        name: p.name,
                        price: p.price,
                        image: p.image
                    };
                }
            
                return item;
        }));

        return { items: refreshedItems };
    }
} as JopiPageDataProvider;