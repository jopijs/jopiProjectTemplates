
export default interface ICartItem {
    _id: string;
    name: string;
    price: number;
    image: string;
    quantity: number;
    slug?: string;
}
