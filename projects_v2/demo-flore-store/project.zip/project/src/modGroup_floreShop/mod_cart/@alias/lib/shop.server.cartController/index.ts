import CoreCartController from "../coreCartController.ts";
import { JopiRequest } from "jopijs";

export default class CartController extends CoreCartController {
    constructor(private readonly req: JopiRequest) {
        super();
    }

    protected readCookie(cookie: string): string | undefined {
        return this.req.cookie_getReqCookie(cookie);
    }

    protected setCookie(cookie: string, value: string): void {
        this.req.cookie_addCookieToRes(cookie, value);
    }
}