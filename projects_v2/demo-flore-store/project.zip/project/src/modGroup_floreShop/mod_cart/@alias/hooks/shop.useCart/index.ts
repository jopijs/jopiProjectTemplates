import { useStoreValue } from 'jopijs/ui';
import CartController from '@/lib/shop.ui.cartController';
import eventCartUpdated from "@/events/shop.cart.updated";
import { useState } from 'react';

export default function userCart() {
    const [_, setCount] = useState(0);

    // Allows refreshing the caller component when cart is updated.
    eventCartUpdated.reactListener(() => {
        setCount(c => c + 1);
    });

    const [controller] = useStoreValue<CartController>("shop.ui.cartController");
    return controller.getCart();
}