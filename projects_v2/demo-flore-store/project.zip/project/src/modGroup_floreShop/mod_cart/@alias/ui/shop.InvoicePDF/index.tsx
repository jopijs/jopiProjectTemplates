
import React from 'react';
import { Page, Text, View, Document, StyleSheet, Font } from '@react-pdf/renderer';
import ICart from '@/lib/shop.ICart';

// Register a standard font if we wanted custom ones, but we'll stick to standard PDF fonts
// Helvetica is clean and classic. Times-Roman for a touch of elegance.

const styles = StyleSheet.create({
  page: {
    padding: 40,
    fontFamily: 'Helvetica',
    fontSize: 10,
    color: '#333',
    lineHeight: 1.5,
  },
  // Header Section
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 40,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6',
  },
  brandContainer: {
    flexDirection: 'column',
  },
  brand: {
    fontSize: 24,
    fontFamily: 'Helvetica-Bold',
    color: '#111827',
    marginBottom: 0,
    letterSpacing: 2,
  },

  invoiceInfo: {
    alignItems: 'flex-end',
  },
  invoiceTitle: {
    fontSize: 24,
    fontFamily: 'Helvetica-Bold',
    color: '#111827',
    marginBottom: 8,
  },
  invoiceDetailRow: {
    flexDirection: 'row',
    marginBottom: 2,
  },
  invoiceLabel: {
    color: '#6b7280',
    marginRight: 8,
    width: 60,
    textAlign: 'right',
  },
  invoiceValue: {
    color: '#374151',
    fontFamily: 'Helvetica-Bold',
    width: 90,
    textAlign: 'right',
  },

  // Company & Client Info
  infoSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 40,
  },
  infoColumn: {
    width: '45%',
  },
  infoTitle: {
    fontSize: 10,
    fontFamily: 'Helvetica-Bold',
    color: '#9ca3af',
    marginBottom: 8,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  infoText: {
    fontSize: 10,
    color: '#374151',
    marginBottom: 2,
  },

  // Table
  tableContainer: {
    marginBottom: 30,
    borderRadius: 4,
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#f9fafb',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
    paddingVertical: 10,
    paddingHorizontal: 8,
    alignItems: 'center',
  },
  headerCell: {
    fontSize: 9,
    fontFamily: 'Helvetica-Bold',
    color: '#4b5563',
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  tableRow: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6',
    paddingVertical: 12,
    paddingHorizontal: 8,
    alignItems: 'center',
  },
  cellFirst: {
    width: '50%',
  },
  cellRest: {
    width: '16.6%',
    textAlign: 'right',
  },
  cellText: {
    fontSize: 10,
    color: '#1f2937',
  },
  cellTextMuted: {
    fontSize: 10,
    color: '#6b7280',
  },

  // Totals
  totalsContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 10,
  },
  totalsBox: {
    width: '40%',
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 6,
  },
  totalRowFinal: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
    paddingTop: 12,
    borderTopWidth: 2,
    borderTopColor: '#111827',
  },
  totalLabel: {
    fontSize: 10,
    color: '#6b7280',
  },
  totalValue: {
    fontSize: 10,
    fontFamily: 'Helvetica-Bold',
    color: '#111827',
  },
  finalTotalLabel: {
    fontSize: 12,
    fontFamily: 'Helvetica-Bold',
    color: '#111827',
  },
  finalTotalValue: {
    fontSize: 16,
    fontFamily: 'Helvetica-Bold',
    color: '#111827',
  },

  // Footer
  footer: {
    position: 'absolute',
    bottom: 40,
    left: 40,
    right: 40,
    textAlign: 'center',
    borderTopWidth: 1,
    borderTopColor: '#f3f4f6',
    paddingTop: 20,
  },
  footerText: {
    fontSize: 9,
    color: '#9ca3af',
    marginBottom: 4,
  },
});

interface InvoicePDFProps {
    cart: ICart;
    date: string;
    invoiceId: string;
}

const InvoicePDF = ({ cart, date, invoiceId }: InvoicePDFProps) => (
  <Document>
    <Page size="A4" style={styles.page}>
      
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.brandContainer}>
          <Text style={styles.brand}>JOPIFLORES</Text>
        </View>
        <View style={styles.invoiceInfo}>
          <Text style={styles.invoiceTitle}>INVOICE</Text>
          <View style={styles.invoiceDetailRow}>
            <Text style={styles.invoiceLabel}>NO.</Text>
            <Text style={styles.invoiceValue}>#{invoiceId.split('-')[1]}</Text>
          </View>
          <View style={styles.invoiceDetailRow}>
            <Text style={styles.invoiceLabel}>DATE</Text>
            <Text style={styles.invoiceValue}>{date}</Text>
          </View>
        </View>
      </View>

      {/* Info Section */}
      <View style={styles.infoSection}>
        <View style={styles.infoColumn}>
          <Text style={styles.infoTitle}>FROM</Text>
          <Text style={{ ...styles.infoText, fontFamily: 'Helvetica-Bold', marginBottom: 4 }}>JopiFlores Inc.</Text>
          <Text style={styles.infoText}>123 Floral Avenue</Text>
          <Text style={styles.infoText}>75001 Paris, France</Text>
          <Text style={styles.infoText}>contact@jopiflores.com</Text>
        </View>
        <View style={styles.infoColumn}>
          <Text style={styles.infoTitle}>BILL TO</Text>
          <Text style={styles.infoText}>Valued Customer</Text>
          <Text style={styles.infoText}>(Guest Checkout)</Text>
        </View>
      </View>

      {/* Table */}
      <View style={styles.tableContainer}>
        {/* Table Header */}
        <View style={styles.tableHeader}>
          <Text style={[styles.headerCell, styles.cellFirst]}>ITEM DESCRIPTION</Text>
          <Text style={[styles.headerCell, styles.cellRest, { textAlign: 'center' }]}>QTY</Text>
          <Text style={[styles.headerCell, styles.cellRest]}>PRICE</Text>
          <Text style={[styles.headerCell, styles.cellRest]}>AMOUNT</Text>
        </View>

        {/* Table Rows */}
        {cart.items.map((item, index) => (
          <View style={styles.tableRow} key={item.id}>
            <View style={styles.cellFirst}>
                <Text style={{ ...styles.cellText, fontFamily: 'Helvetica-Bold' }}>{item.name}</Text>
                <Text style={{ fontSize: 9, color: '#9ca3af', marginTop: 2 }}>Item #{item.id}</Text>
            </View>
            <Text style={[styles.cellText, styles.cellRest, { textAlign: 'center' }]}>{item.quantity}</Text>
            <Text style={[styles.cellText, styles.cellRest]}>€{item.price.toFixed(2)}</Text>
            <Text style={[styles.cellText, styles.cellRest, { fontFamily: 'Helvetica-Bold' }]}>
                €{(item.price * item.quantity).toFixed(2)}
            </Text>
          </View>
        ))}
      </View>

      {/* Totals */}
      <View style={styles.totalsContainer}>
        <View style={styles.totalsBox}>
            <View style={styles.totalRow}>
                <Text style={styles.totalLabel}>Subtotal</Text>
                <Text style={styles.totalValue}>€{cart.subTotal.toFixed(2)}</Text>
            </View>
            <View style={styles.totalRow}>
                <Text style={styles.totalLabel}>Shipping</Text>
                <Text style={styles.totalValue}>
                    {cart.shipping === 0 ? 'Free' : `€${cart.shipping.toFixed(2)}`}
                </Text>
            </View>
            <View style={styles.totalRow}>
                <Text style={styles.totalLabel}>Taxes (Included)</Text>
                <Text style={styles.totalValue}>€{cart.taxes.toFixed(2)}</Text>
            </View>
            <View style={styles.totalRowFinal}>
                <Text style={styles.finalTotalLabel}>TOTAL</Text>
                <Text style={styles.finalTotalValue}>€{cart.total.toFixed(2)}</Text>
            </View>
        </View>
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>Thank you for your business!</Text>
        <Text style={styles.footerText}>JopiFlores Inc. - SAS au capital de 10 000 € - SIRET 123 456 789 00012</Text>
      </View>
    </Page>
  </Document>
);

export default InvoicePDF;
