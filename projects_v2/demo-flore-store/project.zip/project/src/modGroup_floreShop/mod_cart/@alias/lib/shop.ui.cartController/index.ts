import { getCookieValue, setCookie, JopiUiApplication } from "jopijs/ui";
import CrossTabEvent from "@/lib/jopijs.client.CrossTabEvent";
import eventCartUpdated from "@/events/shop.cart.updated";
import CoreCartController from "../coreCartController.ts";

export default class CartController extends CoreCartController {
    private crossTab?: CrossTabEvent;

    constructor() {
        super();
        this.crossTab = new CrossTabEvent("shop.cart.sync");
    }

    static get(app: JopiUiApplication): CartController {
        return app.valueStore.getValue<CartController>("shop.ui.cartController")!;
    }

    protected init() {
        super.init();

        if (this.crossTab) {
            // Listen for updates from other tabs
            this.crossTab.listen(() => {
                this._cart = this.loadInitialCart();
                this.updateTotals();
                eventCartUpdated.send(this._cart);
            });
        }
    }

    protected saveCart() {
        super.saveCart();
        eventCartUpdated.send(this.getCart());
        if (this.crossTab) this.crossTab.emit(null);
    }

    protected readCookie(cookie: string): string | undefined {
        return getCookieValue(cookie);
    }

    protected setCookie(cookie: string, value: string): void {
        setCookie(cookie, value);
    }
}
