import ICart from "@/lib/shop.ICart";
import ICartItem from "@/lib/shop.ICartItem";

export default abstract class CoreCartController {
    protected _cart!: ICart;
    
    protected init() {
        if (this._isInit) return;
        this._isInit = true;

        this._cart = this.loadInitialCart();
        this.updateTotals();
    }
    //
    private _isInit = false;

    /**
     * Updates the cart items with fresh data from the server (PageData).
     * This ensures prices and details are up to date.
     */
    updateItems(refreshedItems: ICartItem[]) {
        this.getCart().items = refreshedItems;
        this.updateTotals();
        this.saveCart();
    }

    getCart(): ICart {
        this.init();
        return this._cart;
    }

    invalidateCache() {
        this.init();
        this.updateTotals();
    }

    protected updateTotals() {
        const items = this.getCart().items;
        const subTotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const taxes = subTotal * 0.20;
        const shipping = subTotal > 100 ? 0 : 9.99;
        const total = subTotal + shipping;
        
        const cart = this.getCart();
        cart.subTotal = subTotal;
        cart.taxes = taxes;
        cart.shipping = shipping;
        cart.total = total;
    }

    addProduct(product: ICartItem) {
        const items = this.getCart().items;
        
        // Check if the product is already in the cart
        const existingItemIndex = items.findIndex((item: ICartItem) => item.id === product.id);
        let newItems = [...items];

        if (existingItemIndex > -1) {
            const existingItem = newItems[existingItemIndex];
            
            // Update quantity
            const quantityToAdd = product.quantity || 1;
            const currentQuantity = existingItem.quantity || 0;

            newItems[existingItemIndex] = {
                ...existingItem,
                quantity: currentQuantity + quantityToAdd
            };
        } else {
            // Add new item with default quantity if missing
            newItems.push({ 
                ...product, 
                quantity: product.quantity || 1
            });
        }

        this.getCart().items = newItems;
        this.updateTotals();
        this.saveCart();
    }

    updateQuantity(productId: number, delta: number) {
        const items = this.getCart().items;
        
        const existingItemIndex = items.findIndex((item: ICartItem) => item.id === productId);
        if (existingItemIndex === -1) return;

        let newItems = [...items];
        const existingItem = newItems[existingItemIndex];
        const newQuantity = (existingItem.quantity || 0) + delta;

        if (newQuantity <= 0) {
            newItems.splice(existingItemIndex, 1);
        } else {
            newItems[existingItemIndex] = {
                ...existingItem,
                quantity: newQuantity
            };
        }

        this.getCart().items = newItems;
        this.updateTotals();

        this.saveCart();
    }

    protected loadInitialCart(): ICart {
        const defaultCart: ICart = { items: [], taxes: 0, subTotal: 0, shipping: 0, total: 0 };

        // Always an empty cart on server side.
        // Allows an clean cache content.
        //
        //if (isServerSide) return defaultCart;

        const saved = this.readCookie("cart.content");
        if (!saved) return defaultCart;
        
        try {
            const parsed = JSON.parse(decodeURIComponent(saved));
            const items: ICartItem[] = parsed.items || [];
            return { ...defaultCart, items };
        } catch { 
            return defaultCart; 
        }
    }

    protected saveCart() {
        this.setCookie("cart.content", encodeURIComponent(JSON.stringify(this.getCart())));
    }

    protected abstract readCookie(cookie: string): string | undefined;
    protected abstract setCookie(cookie: string, value: string): void;
}