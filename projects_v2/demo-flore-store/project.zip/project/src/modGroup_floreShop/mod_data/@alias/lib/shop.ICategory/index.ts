export default interface Category {
    _id: string;
    productIds: string[];
}
