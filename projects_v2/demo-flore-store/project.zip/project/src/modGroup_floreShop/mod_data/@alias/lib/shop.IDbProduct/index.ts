import IProduct from "@/lib/shop.IProduct";

export default interface IDbProduct extends Omit<IProduct, "_id" | "name" | "description"> {
    _id?: string;
    name: Record<string, string>;
    description: Record<string, string>;
}