export default interface IProduct {
    _id: string;
    name: string;
    price: number;
    image: string;
    slug: string;
    description: string;
    categories: string[];
}
