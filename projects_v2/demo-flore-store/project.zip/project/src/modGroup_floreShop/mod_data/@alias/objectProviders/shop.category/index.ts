import type { ObjectProvider } from "jopijs";
import { getDbEngineRef } from "jopi-filedb";

const dbEngine = getDbEngineRef();

export default <ObjectProvider<
    { categoryName: string },
    { productIds: string[] }
>>
{
    async get(params) {
        const view = dbEngine.ref.getCollection("shop.products").getView("categoryToProducts");
        const productIds: string[] = [];
        const categoryName = params.categoryName;
        
        await view.forEach(undefined, (row) => {
            if (row.k === categoryName) {
                productIds.push(row.i);
            }
        });

        return {productIds};
    }
}