import type { ObjectProvider } from "jopijs";
import getProduct from "@/objectProviders/shop.product";
import type IProduct from "@/lib/shop.IProduct";

import { getDbEngineRef } from "jopi-filedb";
const dbEngine = getDbEngineRef();

export default <ObjectProvider<{slug: string, lang?: string}, IProduct>>{
    async get(params) {
        if (!params.lang) params.lang = "en-us";
        if (!params.slug) return;
    
        const view = await dbEngine.ref.getCollection("shop.products").getView("slugToId");
        let productId: string | undefined;

        await view.forEach(undefined, (row) => {
            if (row.k === params.slug) {
                productId = row.i;
            }
        });

        if (!productId) return;
        
        const res = await getProduct.get({ productId, lang: params.lang });
        return res;
    }
}