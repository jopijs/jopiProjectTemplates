import IProduct from "@/lib/shop.IProduct";
import IDbProduct from "@/lib/shop.IDbProduct";
import type { ObjectProvider } from "jopijs";
import { getDbEngineRef } from "jopi-filedb";

const dbEngine = getDbEngineRef();

export default <ObjectProvider<
    {productId: string, lang?: string},
    IProduct
>>{    
    async get(params) {
        if (!params.lang) params.lang = "en-us";
        
        const collection = await dbEngine.ref.getCollection<IDbProduct>("shop.products");
        let iDbProduct = await collection.readItem(params.productId);
        if (!iDbProduct) return;
  
        const product: IProduct = {
            ...iDbProduct as any,
            slug: iDbProduct.slug,
            name: iDbProduct.name[params.lang as keyof typeof iDbProduct.name],
            description: iDbProduct.description[params.lang as keyof typeof iDbProduct.name]
        };
    
        return product;
    }
}