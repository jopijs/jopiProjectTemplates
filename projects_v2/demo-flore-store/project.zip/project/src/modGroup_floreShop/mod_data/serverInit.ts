import { JopiWebSiteBuilder } from "jopijs";
import * as jk_fs from "jopi-toolkit/jk_fs";
import { DbEngine, JsonFileStoreFactory, newView, newView_AlwaysInMemCache, useDbEngine } from "jopi-filedb";
import IDbProduct from "@/lib/shop.IDbProduct";

export default async function (_webSite: JopiWebSiteBuilder) {
    const factory = new JsonFileStoreFactory(jk_fs.join("data", "jopidb"));
    const db = new DbEngine(factory);
    useDbEngine(db);

    db.declareCollection({
        name: 'shop.products',
        isStructured: true,
        views: [
            newView('categoryToProducts',
                async (emit, value: IDbProduct) => {
                    if (value.categories) {
                        const productId = value._id;

                        for (let cat of value.categories) {
                            // The row id is already the productId.
                            await emit(cat);
                        }
                    }
                }
            ),
            newView('slugToId',
                async (emit, value: IDbProduct) => {
                    // The row id is already the productId.
                    await emit(value.slug);
                }
            )
        ]
    });

    //await db.getCollection("shop.products").rebuildView("categoryToProducts");
   // await db.getCollection("shop.products").rebuildView("slugToId");
}