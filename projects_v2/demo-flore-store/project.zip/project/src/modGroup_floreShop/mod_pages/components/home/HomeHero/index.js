"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = HomeHero;
var page_home_1 = require("@/translations/page.home");
var lang_useLanguage_1 = require("@/hooks/lang.useLanguage");
var website_heroBasket_1 = require("@/res/website.heroBasket");
var website_CurvedDivider_1 = require("@/ui/website.CurvedDivider");
function HomeHero() {
    var lang = (0, lang_useLanguage_1.default)()[0];
    var tr = (0, page_home_1.default)(lang);
    return (<section className="bg-jopi-primary text-white pt-[60px] pb-[160px] relative overflow-hidden text-center z-10 transition-colors duration-300">
            <div className="container mx-auto px-4 relative z-20 flex flex-col items-center">
                <p className="text-[24px] md:text-[32px] text-jopi-accent mb-2 transform -rotate-2" style={{ fontFamily: 'var(--font-hand)' }}>
                    {tr.hero_subtitle()}
                </p>
                <h1 className="text-[48px] md:text-[64px] leading-tight font-normal mb-6" style={{ fontFamily: 'var(--font-futura-alt)' }}>
                    {tr.hero_title()}
                </h1>
                <p className="text-[18px] md:text-[20px] mb-10 max-w-2xl opacity-90 leading-relaxed font-light mx-auto relative z-50">
                    {tr.hero_description()}
                </p>
                <div className="mb-12 relative z-50">
                    <a href="/bouquets" className="bg-jopi-primary border border-white text-white px-8 py-3 rounded text-[15px] font-bold hover:bg-white hover:text-jopi-primary transition-all shadow-lg tracking-wide cursor-pointer inline-block">
                        {tr.hero_cta()}
                    </a>
                </div>

                {/* Main Hero Image Centered and Overlapping */}
                <div className="relative z-0 -mb-[280px] w-full max-w-[800px] pointer-events-none">
                    <img src={website_heroBasket_1.default} alt="Spring Flowers in Wicker Basket" width={1024} height={1024} className="w-full h-auto drop-shadow-2xl object-contain hover:scale-105 transition-transform duration-700"/>
                </div>
            </div>

            {/* Curved Divider */}
            <website_CurvedDivider_1.default />
        </section>);
}
