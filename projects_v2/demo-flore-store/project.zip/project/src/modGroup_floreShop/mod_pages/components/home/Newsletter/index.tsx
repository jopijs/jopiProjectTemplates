import trProvider from "@/translations/ui.home.Newsletter";
import useLanguage from "@/hooks/lang.useLanguage";

export default function Newsletter() {
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    return (
        <section className="py-24 bg-white text-center">
            <div className="container mx-auto px-4 max-w-2xl">
                <h2 className="text-3xl md:text-4xl font-bold mb-4">{tr.title()}</h2>
                <p className="text-gray-500 mb-8 text-sm">
                    {tr.legal_prefix()} <a href="#" className="underline">{tr.legal_terms()}</a> {tr.legal_and()} <a href="#" className="underline">{tr.legal_privacy()}</a>.
                </p>
                <form className="flex flex-col sm:flex-row gap-4">
                    <input
                        type="email"
                        placeholder={tr.placeholder()}
                        className="grow px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-jopi-primary"
                    />
                    <button type="button" className="bg-jopi-primary text-white px-8 py-3 rounded-md font-bold hover:opacity-90 transition-all whitespace-nowrap">
                        {tr.btn_submit()}
                    </button>
                </form>
            </div>
        </section>
    );
}
