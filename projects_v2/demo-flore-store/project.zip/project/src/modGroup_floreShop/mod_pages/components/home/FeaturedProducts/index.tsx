const imgWedding = "/flore-shop/wedding-events.png";
const imgWildflower = "/flore-shop/wildflower-bunch.png";
const imgDried = "/flore-shop/dried-flowers.png";
const imgOrchids = "/flore-shop/luxury-orchids.png";

export default function FeaturedProducts() {
    return (
        <section className="py-24 bg-white relative z-0">
            <style>{`
                .no-scrollbar::-webkit-scrollbar {
                    display: none;
                }
                .no-scrollbar {
                    -ms-overflow-style: none;
                    scrollbar-width: none;
                }
            `}</style>
            <div className="container mx-auto px-4 mb-12 flex flex-col md:flex-row justify-between items-end">
                <div className="md:max-w-[650px]">
                    <h2 className="text-[32px] md:text-[42px] font-bold text-black leading-[1.15]" style={{ fontFamily: 'var(--font-futura-alt)' }}>
                        Fresh bouquets and gifts for <br className="hidden md:block" /> every special occasion
                    </h2>
                </div>
                <div className="flex space-x-3 mt-6 md:mt-0">
                    <button
                        onClick={() => document.getElementById('product-carousel')?.scrollBy({ left: -320, behavior: 'smooth' })}
                        className="w-12 h-12 rounded-full border border-gray-300 flex items-center justify-center hover:border-gray-800 transition-colors cursor-pointer group"
                    >
                        <span className="text-xl text-gray-500 group-hover:text-gray-800">←</span>
                    </button>
                    <button
                        onClick={() => document.getElementById('product-carousel')?.scrollBy({ left: 320, behavior: 'smooth' })}
                        className="w-12 h-12 rounded-full border border-gray-300 flex items-center justify-center hover:border-gray-800 transition-colors cursor-pointer group"
                    >
                        <span className="text-xl text-gray-500 group-hover:text-gray-800">→</span>
                    </button>
                </div>
            </div>

            <div className="container mx-auto px-4">
                {/* Scrollable Container */}
                <div id="product-carousel" className="flex gap-6 overflow-x-auto pb-8 snap-x scroll-smooth no-scrollbar">
                    {[
                        { title: 'Classic Roses', desc: 'Timeless elegance for romance and appreciation.', img: 'https://images.unsplash.com/photo-1562690868-60bbe7293e94?auto=format&fit=crop&q=80&w=400' },
                        { title: 'Spring Tulips', desc: 'Bright and cheerful blooms to celebrate the season.', img: 'https://images.unsplash.com/photo-1520763185298-1b434c919102?auto=format&fit=crop&q=80&w=400' },
                        { title: 'Wedding & Events', desc: 'Custom arrangements for your perfect day.', img: imgWedding },
                        { title: 'Potted Plants', desc: 'Long-lasting greenery for home and office.', img: 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&q=80&w=400' },
                        { title: 'Wildflower Bunch', desc: 'Rustic charm for a natural, bohemian look.', img: imgWildflower },
                        { title: 'Dried Flowers', desc: 'Sustainable beauty that lasts forever.', img: imgDried },
                        { title: 'Luxury Orchids', desc: 'Exotic sophistication for modern spaces.', img: imgOrchids },
                        { title: 'Subscriptions', desc: 'Fresh blooms delivered to your door monthly.', img: 'https://images.unsplash.com/photo-1527061011665-3652c757a4d4?auto=format&fit=crop&q=80&w=400' },
                    ].map((p, i) => (
                        <div key={i} className="min-w-[280px] md:min-w-[320px] snap-start bg-jopi-light-gray rounded-sm overflow-hidden flex flex-col hover:shadow-lg transition-shadow duration-300 cursor-pointer group">
                            <div className="h-[280px] p-0 flex items-end justify-center bg-white">
                                <img src={p.img} alt={p.title} className="w-full h-full object-cover shadow-sm transform group-hover:scale-105 transition-transform duration-500" />
                            </div>
                            <div className="px-8 pb-10 pt-6 grow">
                                <h3 className="font-bold text-[22px] mb-3 text-[#1a1a1a]" style={{ fontFamily: 'var(--font-futura-alt)' }}>{p.title}</h3>
                                <p className="text-[#555] text-[15px] leading-[1.6] font-light">{p.desc}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
