import React from 'react';
import Layout from '@/ui/website.layout';
import PageHero from '@/ui/website.PageHero';
import Newsletter from '../../components/home/Newsletter';
import CallToAction from '../../components/home/CallToAction';

import useLanguage from '@/hooks/jopijs.lang.useLanguage';
import trProvider from '@/translations/page.occasions';

const imgWedding = "/flore-shop/wedding-events.png";
const imgOrchids = "/flore-shop/luxury-orchids.png";
const imgDried = "/flore-shop/dried-flowers.png";

export default function OccasionsPage() {
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    const occasions = [
        { id: 1, title: tr.occ_wedding(), image: imgWedding, color: "bg-pink-50" },
        { id: 2, title: tr.occ_birthday(), image: imgOrchids, color: "bg-blue-50" },
        { id: 3, title: tr.occ_sympathy(), image: imgDried, color: "bg-gray-50" },
        { id: 4, title: tr.occ_anniversary(), image: imgWedding, color: "bg-purple-50" },
        { id: 5, title: tr.occ_new_baby(), image: imgOrchids, color: "bg-green-50" },
        { id: 6, title: tr.occ_just_because(), image: imgDried, color: "bg-yellow-50" },
    ];

    return (
        <Layout>
            <main className="bg-white min-h-screen">
                <PageHero
                    title={tr.hero_title()}
                    subtitle={tr.hero_subtitle()}
                    description={tr.hero_description()}
                />

                <section className="container mx-auto px-4 py-20">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {occasions.map((item) => (
                            <div key={item.id} className={`group relative h-80 rounded-lg overflow-hidden cursor-pointer shadow-sm hover:shadow-xl transition-all duration-500 ${item.color}`}>
                                <div className="absolute inset-0 flex items-center justify-center p-8 z-10">
                                    <div className="bg-white/90 backdrop-blur-sm px-8 py-4 rounded-sm text-center transform group-hover:scale-105 transition-transform duration-500">
                                        <h3 className="text-2xl font-bold text-gray-800" style={{ fontFamily: 'var(--font-futura-alt)' }}>{item.title}</h3>
                                        <span className="text-jopi-primary text-sm font-medium mt-2 block opacity-0 group-hover:opacity-100 transition-opacity duration-300 transform translate-y-2 group-hover:translate-y-0">{tr.view_collection()}</span>
                                    </div>
                                </div>
                                <img
                                    src={item.image}
                                    alt={item.title}
                                    className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity duration-700 mix-blend-multiply"
                                />
                            </div>
                        ))}
                    </div>
                </section>

                <Newsletter />
                <CallToAction />
            </main>
        </Layout>
    );
}
