import { usePageData } from "jopijs/ui";
import Layout from '@/ui/website.layout';
import ProductCard from '@/ui/shop.ProductCard';
import IProduct from "@/lib/shop.IProduct";

import useLanguage from '@/hooks/jopijs.lang.useLanguage';
import trProvider from '@/translations/page.bouquets';

import PageHero from '@/ui/website.PageHero';
import Newsletter from '../../components/home/Newsletter';
import CallToAction from '../../components/home/CallToAction';

export default function BouquetsPage() {
    const { items: bouquets } = usePageData() as { items: IProduct[] | undefined };
    const [lang] = useLanguage();
    const tr = trProvider(lang);
    
    return (
        <Layout>
            <main className="bg-white min-h-screen">
                <PageHero
                    title={tr.hero_title()}
                    subtitle={tr.hero_subtitle()}
                    description={tr.hero_description()}
                />

                <section className="container mx-auto px-4 py-20">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                        {bouquets?.map(product => (
                            <ProductCard
                                key={product._id}
                                id={`bouquets-page-${product._id}`}
                                product={product}
                                addToCartLabel={tr.add_to_cart()}
                            />
                        ))}
                    </div>
                </section>

                <Newsletter />
                <CallToAction />
            </main>
        </Layout>
    );
}
