import { usePageData } from "jopijs/ui";
import ProductCard from "@/ui/shop.ProductCard";
import Layout from '@/ui/website.layout';
import trProvider from "@/translations/page.plants";
import useLanguage from "@/hooks/jopijs.lang.useLanguage";
import PageHero from '@/ui/website.PageHero';

export default function CategoryPage() {
    const { items: products = [], global } = usePageData() as { items: any[], global: { category: string } };
    const category = global?.category || "";
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    // Map slug to translation keys
    const titleKey = `categories_${category}_title` as keyof typeof tr;
    const descKey = `categories_${category}_description` as keyof typeof tr;
    
    // Safety check for dynamic key access
    const title = (tr[titleKey] as Function)?.() || category;
    const description = (tr[descKey] as Function)?.() || "";

    return (
        <Layout>
             <main className="bg-white min-h-screen pb-20">
                <PageHero
                    title={title}
                    subtitle="Plants"
                    description={description}
                />
                 <div className="container mx-auto px-4 py-16">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12">
                        {products.map((product, idx) => (
                             <ProductCard
                                key={product.id}
                                id={`category-page-${product.id}`}
                                product={product}
                                addToCartLabel={tr.common_add_to_cart()}
                            />
                        ))}
                    </div>
                     {products.length === 0 && (
                        <div className="text-center py-20">
                            <p className="text-xl text-gray-500">{tr.product_not_found?.() || "No products found"}</p>
                        </div>
                    )}
                 </div>
            </main>
        </Layout>
    );    
}
