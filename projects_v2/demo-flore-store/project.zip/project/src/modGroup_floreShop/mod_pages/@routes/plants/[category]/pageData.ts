import { JopiPageDataProvider } from "jopijs";
import getCategory from "@/objectProviders/shop.category";
import getProduct from "@/objectProviders/shop.product";
import IProduct from "@/lib/shop.IProduct";

export default {
    async getDataForCache({req}) {
        const category = req.req_urlParts.category!;
        const lang = req.cookie_getReqCookie("lang", "en-us")!;
        
        const products = await getCategoryProducts(category, lang);
        
        return {
            items: products,
            global: { category },
            seed: products.map((p: any) => p._id),
            itemKey: "_id"
        };
    },

    async getRefreshedData({ seed }: {seed: string[]}) {
        // Seed contains product IDs
        return {
            items: await getProductsPrice(seed),
            itemKey: "_id"
        };
    }
} as JopiPageDataProvider;

export async function getProductsPrice(ids: string[]) {
    if (!ids || ids.length === 0) return [];

    const products = await Promise.all(ids.map(async (id) => {
        const res = await getProduct.get({productId: id});
        const val = (res && 'value' in (res as any)) ? (res as any).value : res;
        return val ? { _id: val._id, price: val.price } : null;
    }));

    return products.filter((p) => !!p);
}

export async function getCategoryProducts(categorySlug: string, lang: string = "en-us") {
    const mapping: Record<string, string> = {
        'dried': 'plants.dried',
        'potted': 'plants.potted',
        'succulents': 'plants.succulents'
    };

    const catId = mapping[categorySlug];
    if (!catId) return [];

    const catRes = await getCategory.get({ categoryName: catId });
    if (!catRes) return [];
    
    if (catRes.productIds.length > 0) {
        const products = await Promise.all((catRes.productIds as string[]).map(async (productId) => {
            const res = await getProduct.get({productId, lang});
            const val = (res && 'value' in (res as any)) ? (res as any).value : res;
            return val ?? null;
        }));

        return products.filter((p): p is IProduct => !!p);
    }

    return [];
}