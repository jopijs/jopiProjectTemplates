"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
var website_layout_1 = require("@/translations/website.layout");
function default_1(config) {
    var translations = {};
    for (var _i = 0, supportedLangs_1 = website_layout_1.supportedLangs; _i < supportedLangs_1.length; _i++) {
        var lang = supportedLangs_1[_i];
        translations[lang] = (0, website_layout_1.default)(lang).menu_occasions();
    }
    config.menu_addToTopMenu(["Occasions"], {
        translations: translations,
        priority: -50
    });
}
