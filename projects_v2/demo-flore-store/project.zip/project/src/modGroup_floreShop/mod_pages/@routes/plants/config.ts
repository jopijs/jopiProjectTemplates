import { JopiRouteConfig } from "jopijs";
import { getAllTranslationsFor } from "@/translations/website.layout";

export default function (config: JopiRouteConfig) {
    config.menu_addToTopMenu(["Plants"], {
        translations: getAllTranslationsFor("menu_plants"),
        priority: -20
    });
}
