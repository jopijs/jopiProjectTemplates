import { JopiPageDataProvider } from "jopijs";
import getProductFromSlug from "@/objectProviders/shop.slug2productId";
import getProductFromId from "@/objectProviders/shop.product";

export default {
    async getDataForCache({req}) {
        let productSlug = req.req_urlParts.productSlug!;
        const lang = req.cookie_getReqCookie("lang", "en-us")!;
        const product = await getProductFromSlug.get({ slug: productSlug, lang });
        
        if (!product) {
            return {items: []};
        }
    
        return {
            items: [product],
            seed: product._id,
            itemKey: "_id"
        } as any;
    },

    async getRefreshedData({ seed, req }) {
        const productId = seed as string;
        const lang = req.cookie_getReqCookie("lang", "en-us")!;
        const product = await getProductFromId.get({productId, lang});
        return {items: [{_id: productId, price: product.price}]};
    }
} as JopiPageDataProvider;