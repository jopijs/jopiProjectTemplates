import { JopiRouteConfig } from "jopijs";
import { getAllTranslationsFor } from "@/translations/website.layout";

export default function (config: JopiRouteConfig) {
    config.menu_addToTopMenu(["Care Guide"], {
        translations: getAllTranslationsFor("menu_care_guide"),
        priority: -40
    });
}
