import { JopiRouteConfig } from "jopijs";
import { getAllTranslationsFor } from "@/translations/website.layout";

export default function (config: JopiRouteConfig) {
    config.menu_addToTopMenu(["Workshops"], {
        translations: getAllTranslationsFor("menu_workshops"),
        priority: -30
    });
}
