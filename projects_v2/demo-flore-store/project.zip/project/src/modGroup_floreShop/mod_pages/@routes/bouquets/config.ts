import { JopiRouteConfig } from "jopijs";
import { getAllTranslationsFor } from "@/translations/website.layout";

export default function (config: JopiRouteConfig) {
    config.menu_addToTopMenu(["Bouquets"], {
        translations: getAllTranslationsFor("menu_bouquets"),
        priority: -10
    });
}
