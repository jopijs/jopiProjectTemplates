import { JopiPageDataProvider } from "jopijs";
import shopProduct from "@/objectProviders/shop.product";
import shopCategory from "@/objectProviders/shop.category";

export default {
    async getDataForCache({ req }) {
        const lang = req.cookie_getReqCookie("lang", "en-us")!;
        const allBouquets = await getProducts_bouquets(lang);

        const res = {
            items: allBouquets,
            seed: allBouquets.map(p => p._id),
            itemKey: "_id"
        };

        return res;
    },

    async getRefreshedData({ seed }: {seed: string[]}) {
        const prices = await getPricesFromIds(seed);
        let items = seed.map((id: string) => ({ _id: id, price: prices[id] }));
        return { items: items };
    }
} as JopiPageDataProvider;

async function getProducts_bouquets(lang: string) {
    let { productIds } = await shopCategory.get({ categoryName: "bouquets" });
    if (!productIds) return [];

    const products = await Promise.all(productIds.map((id: any) => shopProduct.get({productId: id, lang})));
    return products.filter((p: any) => !!p);
}

async function getPricesFromIds(ids: string[]) {
    let res: Record<string, number> = {};

    for (const id of ids) {
        const product = await shopProduct.get({productId: id});
        
        if (product) {
            // We increase the price for the demo.
            res[id] = product.price * 5;
        }
    }

    return res;
}