import { JopiWebSiteBuilder } from "jopijs";

export default function serverInit(webSite: JopiWebSiteBuilder) {
    // Apply cache rules to our page.
    // Here we will use a sub-cache for each language.
    //
    webSite.configure_htmlCache()
        .add_cacheRules({
            routeSelector: {
                // Apply cache to all our routes.
                //
                include: ["/",
                    "/admin",
                    "/bouquets",
                    "/care-guide",
                    "/occasions",
                    "/plants",
                    "/product/*",
                    "/subscriptions",
                    "/workshops"
                ]
            },

            beforeCheckingCache: async (req) => {
                let lang = req.cookie_getReqCookie("lang");
        
                // The main cache is en-us.
                if (!lang || (lang=="en-us")) return;

                // For other languages, use a sub-cache.
                // Why? It allows the server to send the same content as what we will see in the browser.
                //
                // This avoid flickering, since without that:
                //      1- Prebuild HTML from the server render the english version
                //      2- React is mounted and render a translated page. Here: flickering.
                //
                // It's very small but visible.
                //
                // Note: next version of JopiJS will probably allows
                //       to avoid that through some render tips.

                req.htmlCache_useCache(req.htmlCache_getSubCache(lang));
            }
        })
        .END_configure_htmlCache();
}