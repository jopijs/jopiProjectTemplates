import img from "./image.png";
export default img;
