import React from "react";
import trProvider from "@/translations/page.login";
import shopBg from "./shop_bg.png";
import logo from "./logo.png";
import Layout from "@/ui/website.layout";

import defaultLoginPassword from "@/res/jopijs.auth.defaultLoginPassword";
import useLanguage from "@/hooks/lang.useLanguage";

const defaultLogin = (defaultLoginPassword as any).login;
const defaultPassword = (defaultLoginPassword as any).password;

interface MyProps {
    isAuhFailed: boolean;
    onSubmitForm: (e: React.FormEvent<HTMLFormElement>) => void;
}

export default function ({ isAuhFailed, onSubmitForm }: MyProps) {
    const [lang] = useLanguage();
    const tr = trProvider(lang);
    
    return (
        <Layout>
            <div className="w-full min-h-screen flex font-sans">
                <div className="hidden lg:block flex-1 relative bg-gray-50">
                    <img src={shopBg} alt="Florist Shop" className="absolute inset-0 w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/20 mix-blend-multiply"></div>
                    <div className="absolute bottom-10 left-10 text-white p-6 max-w-md backdrop-blur-sm bg-black/10 rounded-xl">
                        <p className="text-2xl font-light italic">"{tr.loginQuoteText()}"</p>
                        <p className="mt-2 text-sm opacity-90">{tr.loginQuoteAuthor()}</p>
                    </div>
                </div>

                <div className="flex-1 flex flex-col items-center justify-center bg-white p-6 sm:p-12 relative">
                    {/* Mobile background hint */}
                    <div className="absolute inset-0 lg:hidden z-0 opacity-5">
                        <img src={shopBg} className="w-full h-full object-cover" alt="Background" />
                    </div>

                    <form onSubmit={(e) => onSubmitForm(e)}
                          className="w-full max-w-sm flex flex-col items-center justify-center relative z-10">
                        
                        <div className="mb-10 flex flex-col items-center">
                            <img src={logo} alt="Jopi Flores" className="h-60 w-auto object-contain" />
                        </div>

                        <h2 className="text-2xl text-gray-900 font-semibold tracking-tight">{tr.signIn()}</h2>
                        <p className="text-sm text-gray-500 mt-2 text-center">{tr.welcomeBack()}</p>

                        {isAuhFailed && (
                            <div className="mt-8 w-full p-4 bg-red-50 border border-red-100 rounded-lg flex flex-col items-center animate-fade-in">
                                <div className="flex items-center gap-2 text-red-600">
                                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                    <span className="text-sm font-medium">{tr.invalidIdentifierOrPassword()}</span>
                                </div>
                                <p className="text-xs text-red-500 mt-1">{tr.checkMailOrPassword()}</p>
                            </div>
                        )}

                        <div className={isAuhFailed ? "mt-6" : "mt-10"}></div>

                        <div className="w-full space-y-4">
                            <div className={`group flex items-center w-full px-4 h-12 rounded-full border transition-colors duration-200 bg-white ${
                                isAuhFailed ? 'border-red-300 bg-red-50/30' : 'border-gray-200 focus-within:border-jopi-primary focus-within:ring-1 focus-within:ring-jopi-primary/20'
                            }`}>
                                <svg className={`w-5 h-5 transition-colors ${isAuhFailed ? 'text-red-400' : 'text-gray-400 group-focus-within:text-jopi-primary'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                </svg>
                                <input 
                                    name="login" 
                                    type="text" 
                                    required 
                                    defaultValue={defaultLogin} 
                                    placeholder={tr.loginPlaceholder()}
                                    className={`ml-3 bg-transparent outline-none text-sm w-full h-full ${
                                        isAuhFailed ? 'text-red-900 placeholder-red-400' : 'text-gray-900 placeholder-gray-400'
                                    }`}
                                />
                            </div>

                            <div className={`group flex items-center w-full px-4 h-12 rounded-full border transition-colors duration-200 bg-white ${
                                isAuhFailed ? 'border-red-300 bg-red-50/30' : 'border-gray-200 focus-within:border-jopi-primary focus-within:ring-1 focus-within:ring-jopi-primary/20'
                            }`}>
                                <svg className={`w-5 h-5 transition-colors ${isAuhFailed ? 'text-red-400' : 'text-gray-400 group-focus-within:text-jopi-primary'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                                </svg>
                                <input 
                                    name="password" 
                                    type="password" 
                                    required 
                                    defaultValue={defaultPassword} 
                                    placeholder={tr.passwordPlaceholder()}
                                    className={`ml-3 bg-transparent outline-none text-sm w-full h-full ${
                                        isAuhFailed ? 'text-red-900 placeholder-red-400' : 'text-gray-900 placeholder-gray-400'
                                    }`}
                                />
                            </div>
                        </div>

                        <button type="submit"
                                className="mt-8 w-full h-12 rounded-full text-white bg-jopi-primary hover:bg-jopi-primary/90 hover:shadow-lg hover:shadow-jopi-primary/20 transition-all duration-200 font-medium tracking-wide">
                            {tr.signIn()}
                        </button>
                        
                        <p className="text-gray-500 text-sm mt-6">
                            {tr.dontHaveAccount()} <a className="text-jopi-primary font-medium hover:underline decoration-2 underline-offset-2" href="/register">{tr.signUp()}</a>
                        </p>
                    </form>
                </div>
            </div>
        </Layout>
    );
};