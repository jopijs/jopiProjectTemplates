export interface CurvedDividerProps {
    className?: string;
    fill?: string;
}

export default function CurvedDivider({ className = "", fill = "fill-white" }: CurvedDividerProps) {
    return (
        <div className={`absolute bottom-0 left-0 w-full z-10 leading-none -mb-px ${className}`}>
            <svg 
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 1440 100" 
                width="1440" 
                height="100" 
                className={`w-full h-auto block ${fill}`}
                style={{ aspectRatio: '1440/100' }}
            >
                <path d="M0,0 C480,100 960,100 1440,0 L1440,100 L0,100 Z" fill="currentColor"></path>
            </svg>
        </div>
    );
}
