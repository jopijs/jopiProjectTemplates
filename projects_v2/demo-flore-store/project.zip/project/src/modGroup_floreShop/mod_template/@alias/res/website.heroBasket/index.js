"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var image_png_1 = require("./image.png");
exports.default = image_png_1.default;
