import useMenu from '@/hooks/jopijs.menu.useMenu';
import MenuNames from '@/lib/jopijs.menu.MenuNames';
import useLanguage from '@/hooks/jopijs.lang.useLanguage';

export default function Menu() {
    const menuItems = useMenu(MenuNames.TOP_MENU);
    const [currentLang] = useLanguage();
    // Use a default language to prevent flickering of raw keys while language loads
    const lang = currentLang || 'en-us';

    return (
        <nav className="hidden md:flex space-x-6 h-full items-center">
            {menuItems.map(item => {
                // Determine title based on language, handling potential key formats
                const title = item.translations?.[lang] || item.translations?.[lang.replace('-', '_')] || item.title;

                return (
                    <a
                        key={item.key}
                        href={item.url === "" ? "/" : item.url}
                        className={`text-[13px] font-semibold uppercase tracking-wide transition-colors duration-200 outline-none ${item.isActive ? 'text-jopi-primary' : 'text-jopi-text hover:text-jopi-primary'}`}
                    >
                        {title}
                    </a>
                );
            })}
        </nav>
    );
}