import { JopiPageDataProvider } from "jopijs";
import getProduct from "@/objectProviders/shop.product";

export default {
    async getDataForCache({req}) {
        const cartCookie = req.cookie_getReqCookie("cart.content");
        if (!cartCookie) return { items: [] };

        const parsed = JSON.parse(cartCookie);
        const items = parsed.items || [];
        
        const refreshedItems = await Promise.all(items.map(async (item: any) => {
            const p = await getProduct.getValue(item.id);
            
                if (p && p.value) {
                    return { 
                        ...item, 
                        name: p.name,
                        price: p.price,
                        image: p.image
                    };
                }
            
                return item;
        }));

        return { items: refreshedItems };
    }
} as JopiPageDataProvider;