
import CartPageContent from '@/ui/shop.CartPageContent';

export default CartPageContent;
