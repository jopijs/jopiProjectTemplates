import CartPageContent from '@/ui/shop.CartPageContent';
import { usePageData, useStoreValue } from "jopijs/ui";
import CartController from "@/lib/shop.ui.cartController";
import { useEffect } from "react";

export default function CartPage() {
    const { items } = usePageData() as any;
    const [controller] = useStoreValue<CartController>("shop.ui.cartController");

    useEffect(() => {
        // If we received verified items from the server (meaning not undefined)
        // we update the controller to ensure consistency (e.g. updated prices)
        if (items && controller) {
            controller.updateItems(items);
        }
    }, [items, controller]);

    return <CartPageContent />;
}
