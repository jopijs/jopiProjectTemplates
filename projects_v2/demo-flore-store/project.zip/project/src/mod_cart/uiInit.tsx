import { JopiUiApplication } from "jopijs/ui";
import CartController from "@/lib/shop.cartController";

export default function (uiApp: JopiUiApplication) {
    uiApp.valueStore.addValueProvider("shop.cartController", () => {
        return new CartController(uiApp.valueStore);
    });
}