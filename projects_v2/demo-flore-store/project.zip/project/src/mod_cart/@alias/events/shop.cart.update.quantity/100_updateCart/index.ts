import { JopiUiApplication } from "jopijs/ui";
import CartController from "@/lib/shop.ui.cartController";

export default function (this: JopiUiApplication, { productId, quantity }: { productId: number, quantity: number }) {
    const controller = CartController.get(this)!;
    controller.updateQuantity(productId, quantity);
}
