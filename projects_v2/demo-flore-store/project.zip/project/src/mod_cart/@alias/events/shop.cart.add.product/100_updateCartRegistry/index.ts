import { JopiUiApplication } from "jopijs/ui"; 
import ICartItem from "@/lib/shop.ICartItem";
import CartController from "@/lib/shop.ui.cartController";

export default function (this: JopiUiApplication, product: ICartItem) {
    const controller = CartController.get(this);
    controller.addProduct(product);
}