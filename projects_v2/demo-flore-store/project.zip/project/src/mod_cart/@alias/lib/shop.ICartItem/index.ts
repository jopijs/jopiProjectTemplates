
export default interface ICartItem {
    id: number;
    name: string;
    price: number;
    image: string;
    quantity: number;
    slug?: string;
}
