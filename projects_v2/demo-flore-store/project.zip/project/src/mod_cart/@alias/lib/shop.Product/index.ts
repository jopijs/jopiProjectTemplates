export default interface Product {
    id: string | number;
    name: string;
    price: number;
    image: string;
}
