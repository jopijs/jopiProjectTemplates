import { getCookieValue, setCookie, JopiUiApplication, IsValueStore } from "jopijs/ui";
import { CrossTabEvent } from "../../../../mod_jopijs@uicore/@alias/lib/jopijs.client.CrossTabEvent";
import ICart from "@/lib/shop.ICart";
import ICartItem from "@/lib/shop.ICartItem";
import eventCartUpdated from "@/events/shop.cart.updated";
import productsData from "@/res/products";

export default class CartController {
    private cart!: ICart;
    private crossTab: CrossTabEvent;

    constructor(private readonly store: IsValueStore) {
        this.crossTab = new CrossTabEvent("shop.cart.sync");
        this.init();
    }

    static get(app: JopiUiApplication): CartController {
        return app.valueStore.getValue<CartController>("shop.cartController")!;
    }

    private init() {
        this.cart = this.loadInitialCart();
        this.updateTotals();

        // Listen for updates from other tabs
        this.crossTab.listen(() => {
            this.cart = this.loadInitialCart();
            this.updateTotals();
            eventCartUpdated.send(this.cart);
        });
    }

    getCart(): ICart {
        return this.cart;
    }

    invalidateCache() {
        this.updateTotals();
    }

    private updateTotals() {
        const items = this.cart.items;
        const subTotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const taxes = subTotal * 0.20;
        const shipping = subTotal > 100 ? 0 : 9.99;
        const total = subTotal + shipping;
        
        this.cart.subTotal = subTotal;
        this.cart.taxes = taxes;
        this.cart.shipping = shipping;
        this.cart.total = total;
    }

    private loadInitialCart(): ICart {
        const saved = getCookieValue("cart.content");
        const defaultCart: ICart = { items: [], taxes: 0, subTotal: 0, shipping: 0, total: 0 };
        
        if (!saved) return defaultCart;
        
        try {
            const parsed = JSON.parse(saved);
            const items: ICartItem[] = parsed.items || [];
            
            // Refresh items from source of truth to ensure stable image paths
            const validItems = items.map(item => {
                const product = this.findProductById(item.id);
                if (product) {
                    return {
                        ...item,
                        name: product.name,
                        price: product.price,
                        image: product.image
                    };
                }
                return item;
            });

            return { ...defaultCart, items: validItems };
        } catch { 
            return defaultCart; 
        }
    }

    saveCart() {
        setCookie("cart.content", JSON.stringify(this.cart));
        eventCartUpdated.send(this.cart);
        this.crossTab.emit(null);
    }

    addProduct(product: ICartItem) {
        const items = this.cart.items;
        
        // Check if the product is already in the cart
        const existingItemIndex = items.findIndex((item: ICartItem) => item.id === product.id);
        let newItems = [...items];

        if (existingItemIndex > -1) {
            const existingItem = newItems[existingItemIndex];
            
            // Update quantity
            const quantityToAdd = product.quantity || 1;
            const currentQuantity = existingItem.quantity || 0;

            newItems[existingItemIndex] = {
                ...existingItem,
                quantity: currentQuantity + quantityToAdd
            };
        } else {
            // Add new item with default quantity if missing
            newItems.push({ 
                ...product, 
                quantity: product.quantity || 1
            });
        }

        this.cart.items = newItems;
        this.updateTotals();
        this.saveCart();
    }

    updateQuantity(productId: number, delta: number) {
        const items = this.cart.items;
        
        const existingItemIndex = items.findIndex((item: ICartItem) => item.id === productId);
        if (existingItemIndex === -1) return;

        let newItems = [...items];
        const existingItem = newItems[existingItemIndex];
        const newQuantity = (existingItem.quantity || 0) + delta;

        if (newQuantity <= 0) {
            newItems.splice(existingItemIndex, 1);
        } else {
            newItems[existingItemIndex] = {
                ...existingItem,
                quantity: newQuantity
            };
        }

        this.cart.items = newItems;
        this.updateTotals();
        this.saveCart();
    }

    findProductById(id: number): ICartItem | undefined {
        // Search in bouquets
        const bouquet = productsData.bouquets.find(p => p.id === id);
        if (bouquet) return bouquet as unknown as ICartItem;

        // Search in plants
        for (const category of Object.values(productsData.plants)) {
            const plant = category.find((p: any) => p.id === id);
            if (plant) return plant as unknown as ICartItem;
        }

        return undefined;
    }
}
