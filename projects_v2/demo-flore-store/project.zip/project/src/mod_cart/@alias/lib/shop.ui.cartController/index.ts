import { getCookieValue, setCookie, JopiUiApplication, IsValueStore, isServerSide } from "jopijs/ui";
import CrossTabEvent from "@/lib/jopijs.client.CrossTabEvent";
import ICart from "@/lib/shop.ICart";
import ICartItem from "@/lib/shop.ICartItem";
import eventCartUpdated from "@/events/shop.cart.updated";

export default class CartController {
    private cart!: ICart;
    private crossTab: CrossTabEvent;

    constructor(private readonly store: IsValueStore) {
        this.crossTab = new CrossTabEvent("shop.cart.sync");
        this.init();
    }

    static get(app: JopiUiApplication): CartController {
        return app.valueStore.getValue<CartController>("shop.ui.cartController")!;
    }

    private init() {
        this.cart = this.loadInitialCart();
        this.updateTotals();

        // Listen for updates from other tabs
        this.crossTab.listen(() => {
            this.cart = this.loadInitialCart();
            this.updateTotals();
            eventCartUpdated.send(this.cart);
        });
    }

    /**
     * Updates the cart items with fresh data from the server (PageData).
     * This ensures prices and details are up to date.
     */
    updateItems(refreshedItems: ICartItem[]) {
        this.cart.items = refreshedItems;
        this.updateTotals();
        this.saveCart();
    }

    getCart(): ICart {
        return this.cart;
    }

    invalidateCache() {
        this.updateTotals();
    }

    private updateTotals() {
        const items = this.cart.items;
        const subTotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const taxes = subTotal * 0.20;
        const shipping = subTotal > 100 ? 0 : 9.99;
        const total = subTotal + shipping;
        
        this.cart.subTotal = subTotal;
        this.cart.taxes = taxes;
        this.cart.shipping = shipping;
        this.cart.total = total;
    }

    private loadInitialCart(): ICart {
        const defaultCart: ICart = { items: [], taxes: 0, subTotal: 0, shipping: 0, total: 0 };

        // Always an empty cart on server side.
        // Allows an clean cache content.
        //
        //if (isServerSide) return defaultCart;

        const saved = getCookieValue("cart.content");
        if (!saved) return defaultCart;
        
        try {
            const parsed = JSON.parse(saved);
            const items: ICartItem[] = parsed.items || [];
            return { ...defaultCart, items };
        } catch { 
            return defaultCart; 
        }
    }

    saveCart() {
        setCookie("cart.content", JSON.stringify(this.cart));
        eventCartUpdated.send(this.cart);
        this.crossTab.emit(null);
    }

    addProduct(product: ICartItem) {
        const items = this.cart.items;
        
        // Check if the product is already in the cart
        const existingItemIndex = items.findIndex((item: ICartItem) => item.id === product.id);
        let newItems = [...items];

        if (existingItemIndex > -1) {
            const existingItem = newItems[existingItemIndex];
            
            // Update quantity
            const quantityToAdd = product.quantity || 1;
            const currentQuantity = existingItem.quantity || 0;

            newItems[existingItemIndex] = {
                ...existingItem,
                quantity: currentQuantity + quantityToAdd
            };
        } else {
            // Add new item with default quantity if missing
            newItems.push({ 
                ...product, 
                quantity: product.quantity || 1
            });
        }

        this.cart.items = newItems;
        this.updateTotals();
        this.saveCart();
    }

    updateQuantity(productId: number, delta: number) {
        const items = this.cart.items;
        
        const existingItemIndex = items.findIndex((item: ICartItem) => item.id === productId);
        if (existingItemIndex === -1) return;

        let newItems = [...items];
        const existingItem = newItems[existingItemIndex];
        const newQuantity = (existingItem.quantity || 0) + delta;

        if (newQuantity <= 0) {
            newItems.splice(existingItemIndex, 1);
        } else {
            newItems[existingItemIndex] = {
                ...existingItem,
                quantity: newQuantity
            };
        }

        this.cart.items = newItems;
        this.updateTotals();
        this.saveCart();
    }

}
