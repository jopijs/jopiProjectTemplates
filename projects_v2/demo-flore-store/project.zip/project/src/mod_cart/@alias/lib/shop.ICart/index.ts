
import ICartItem from "@/lib/shop.ICartItem";

export default interface ICart {
    items: ICartItem[];
    taxes: number;
    subTotal: number;
    shipping: number;
    total: number;
}
