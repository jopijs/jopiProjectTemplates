import trProvider from '@/translations/page.cart';
import useLanguage from '@/hooks/jopijs.lang.useLanguage';
import useCartContent from '@/hooks/shop.useCart';
import { PDFDownloadLink } from '@react-pdf/renderer';
import InvoicePDF from '@/ui/shop.InvoicePDF';
import { isBrowserSide } from 'jopijs/ui';

export default function PdfInvoiceComposite() {
    const [lang] = useLanguage();
    const tr = trProvider(lang);
    const cart = useCartContent();
   
    return isBrowserSide && (
        <div className="mt-4 flex justify-center">
            <PDFDownloadLink
                document={<InvoicePDF cart={cart} date={new Date().toLocaleDateString()} invoiceId={`INV-${Date.now()}`} />}
                fileName="invoice.pdf"
                className="text-sm text-gray-500 hover:text-gray-900 underline cursor-pointer transition-colors"
            >
                {({ loading }) =>
                    loading ? 'Generation...' : tr.download_invoice()
                }
            </PDFDownloadLink>
        </div>
    )
}
