import useCartContent from '@/hooks/shop.useCart';
import trProvider from '@/translations/page.cart';
import useLanguage from '@/hooks/jopijs.lang.useLanguage';

export default function() {
    const cart = useCartContent();
    const tax = cart.taxes;
    const [lang] = useLanguage();
    const tr = trProvider(lang);
    
    return (
        <>
            <span className="text-gray-500 text-sm">{tr.taxes_estimated()}</span>
            <span className="text-gray-600 text-sm text-right">€{tax.toFixed(2)}</span>
        </>
    );
}
