import useCartContent from '@/hooks/shop.useCart';
import trProvider from '@/translations/page.cart';
import useLanguage from '@/hooks/jopijs.lang.useLanguage';

export default function CartTitleComposite() {
    const cart = useCartContent();
    const items = cart?.items || [];
    const [lang] = useLanguage();
    const tr = trProvider(lang);
    
    return (
        <h1 className="text-3xl font-serif text-gray-900 mb-10 flex items-center gap-4">
            {tr.cart_title()}
            <span className="text-sm font-sans font-normal text-gray-400 bg-white px-4 py-1.5 rounded-full border border-gray-100 shadow-sm">
                {tr.items_plural(items.length, { count: items.length })}
            </span>
        </h1>
    );
}
