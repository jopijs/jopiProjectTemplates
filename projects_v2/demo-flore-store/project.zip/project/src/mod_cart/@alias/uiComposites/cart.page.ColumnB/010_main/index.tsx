import CartSummary from '@/uiComposites/cart.page.Summary';
import trProvider from '@/translations/page.cart';
import useLanguage from '@/hooks/jopijs.lang.useLanguage';

export default function CartSummaryComposite() {
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    return (
        <div className="flex flex-col gap-6">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 lg:p-8">
                <div className="grid grid-cols-[1fr_auto] gap-y-5 items-baseline">
                    <CartSummary />
                </div>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 lg:p-8">
                <button className="w-full bg-gray-900 hover:bg-black text-white py-4 rounded-xl font-medium shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-200">
                    {tr.proceed_to_checkout()}
                </button>
                <p className="text-xs text-center text-gray-400 mt-4">
                    {tr.secure_checkout_stripe()}
                </p>
            </div>
        </div>
    );
}
