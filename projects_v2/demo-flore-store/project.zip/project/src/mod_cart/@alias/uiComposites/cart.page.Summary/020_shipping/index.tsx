import useCartContent from '@/hooks/shop.useCart';
import trProvider from '@/translations/page.cart';
import useLanguage from '@/hooks/jopijs.lang.useLanguage';

export default function() {
    const cart = useCartContent();
    const shipping = cart.shipping;
    const [lang] = useLanguage();
    const tr = trProvider(lang);
    
    return (
        <>
            <span className="text-gray-600">{tr.shipping()}</span>
            <span className="text-gray-900 font-medium text-right">
                {shipping === 0 ? tr.free() : `€${shipping.toFixed(2)}`}
            </span>
        </>
    );
}
