import useCartContent from '@/hooks/shop.useCart';
import trProvider from '@/translations/page.cart';
import useLanguage from '@/hooks/jopijs.lang.useLanguage';

export default function() {
    const cart = useCartContent();
    const total = cart.total;
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    return (
        <>
            <span className="text-gray-900 font-medium">{tr.total()}</span>
            <span className="text-gray-900 font-bold text-xl text-right">€{total.toFixed(2)}</span>
        </>
    );
}