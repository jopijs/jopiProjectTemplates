import useCartContent from '@/hooks/shop.useCart';
import trProvider from '@/translations/page.cart';
import useLanguage from '@/hooks/jopijs.lang.useLanguage';

export default function() {
    const cart = useCartContent();
    const total = cart.total;
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    return (
        <>
            <span className="text-lg font-medium text-gray-900">{tr.total()}</span>
            <div className="text-right flex flex-col">
                <span className="text-2xl font-serif text-gray-900">€{total.toFixed(2)}</span>
                <span className="text-xs text-gray-400 text-right mt-1">{tr.including_vat()}</span>
            </div>
        </>
    );
}