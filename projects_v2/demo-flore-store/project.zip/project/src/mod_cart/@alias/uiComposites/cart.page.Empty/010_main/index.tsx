import EmptyCart from '@/ui/shop.EmptyCart';

export default function CartEmptyComposite() {
    return <EmptyCart />;
}
