export default function() {
    return <div className="col-span-2 border-t border-gray-100 my-2"></div>;
}