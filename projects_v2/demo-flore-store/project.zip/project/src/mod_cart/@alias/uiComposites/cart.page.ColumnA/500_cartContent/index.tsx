import useCartContent from '@/hooks/shop.useCart';
import eventUpdateQuantity from "@/events/shop.cart.update.quantity";
import CartItemList from '@/ui/shop.CartItemList';

export default function() {
    const cart = useCartContent();
    const items = cart?.items || [];

    const handleUpdateQuantity = (id: number, newQuantity: number) => {
        const item = items.find(i => i.id === id);
        if (!item) return;

        const delta = newQuantity - item.quantity;
        if (delta === 0) return;

        eventUpdateQuantity.send({ productId: id, quantity: delta });
    };

    const handleRemove = (id: number) => {
        const item = items.find(i => i.id === id);
        if (!item) return;
        
        // Remove entire quantity
        eventUpdateQuantity.send({ productId: id, quantity: -item.quantity });
    };

    return (
        <CartItemList 
            items={items}
            onUpdateQuantity={handleUpdateQuantity}
            onRemove={handleRemove}
        />
    );
}
