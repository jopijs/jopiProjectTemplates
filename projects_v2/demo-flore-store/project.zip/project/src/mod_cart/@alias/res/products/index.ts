import D from "./index.json";
export default D;