
import Layout from '@/ui/website.layout';
import useCartContent from '@/hooks/shop.useCart';

import CartEmpty from '@/uiComposites/cart.page.Empty';
import CartTitle from '@/uiComposites/cart.page.Title';
import CartColumnA from '@/uiComposites/cart.page.ColumnA';
import CartColumnB from '@/uiComposites/cart.page.ColumnB';

export default function CartPageContent() {
    const cart = useCartContent();
    const items = cart?.items || [];
    
    return (
        <Layout>
            <main className="bg-gray-50 min-h-screen py-12 lg:py-20">
                <div className="container mx-auto px-4 max-w-6xl">
                    {items.length > 0 ? (
                        <>
                            <CartTitle />

                            <div className="flex flex-col lg:flex-row gap-8 items-start">
                                <div className="flex-1 w-full">
                                    <CartColumnA />
                                </div>
                                <div className="lg:w-96 shrink-0 w-full lg:sticky lg:top-8">
                                    <CartColumnB />
                                </div>
                            </div>
                        </>
                    ) : (
                        <CartEmpty />
                    )}
                </div>
            </main>
        </Layout>
    );
}
