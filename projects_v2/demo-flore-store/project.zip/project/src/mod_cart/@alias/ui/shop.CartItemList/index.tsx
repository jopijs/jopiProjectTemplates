import ICartItem from "@/lib/shop.ICartItem";
import CartItem from "@/ui/shop.CartItem";

export interface CartItemListProps {
    items: ICartItem[];
    onUpdateQuantity: (id: number, quantity: number) => void;
    onRemove: (id: number) => void;
    className?: string;
}

export default function CartItemList({ items, onUpdateQuantity, onRemove, className }: CartItemListProps) {
    return (
        <div className={`bg-white rounded-2xl shadow-sm border border-gray-100 p-6 lg:p-8 ${className || ""}`}>
            <div className="flex flex-col">
                {items.map(item => (
                    <CartItem 
                        key={item.id} 
                        item={item} 
                        onUpdateQuantity={onUpdateQuantity}
                        onRemove={onRemove}
                    />
                ))}
            </div>
        </div>
    );
}
