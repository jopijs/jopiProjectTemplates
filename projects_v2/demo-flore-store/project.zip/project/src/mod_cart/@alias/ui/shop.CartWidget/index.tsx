import { useState, useEffect } from 'react';
import useCartContent from '@/hooks/shop.useCart';
import { isServerSide } from "jopijs/ui";

export default function CartWidget() {
    // Avoid flickering on SSR
    if (isServerSide) return null;

    const [isVisible, setIsVisible] = useState(false);
    const cart = useCartContent();
    const cartCount = cart.items.reduce((acc, item) => acc + item.quantity, 0);

    useEffect(() => {
        // Trigger fade in once client-side hooks have initialized
        const timer = requestAnimationFrame(() => {
            setIsVisible(true);
        });
        return () => cancelAnimationFrame(timer);
    }, []);

    return (
        <a href="/cart" className="relative group cursor-pointer mr-2 block">
             <button className="text-gray-700 group-hover:text-jopi-primary transition-colors cursor-pointer">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
             </button>
             {cartCount > 0 && (
                 <span className={`absolute -top-2 -right-2 bg-jopi-primary text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full border-2 border-white transition-opacity duration-1000 ease-in-out ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
                    {cartCount}
                </span>
             )}
        </a>
    );
}

