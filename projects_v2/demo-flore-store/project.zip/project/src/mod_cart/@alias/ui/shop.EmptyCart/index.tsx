import React from 'react';
import trProvider from '@/translations/page.cart';
import useLanguage from '@/hooks/jopijs.lang.useLanguage';

export interface EmptyCartProps {
    className?: string;
}

export default function EmptyCart({ className }: EmptyCartProps) {
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    return (
        <div className={`flex flex-col items-center justify-center py-20 bg-white rounded-2xl shadow-sm border border-gray-100 ${className || ""}`}>
            <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mb-6">
                <svg className="w-10 h-10 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                </svg>
            </div>
            <h2 className="text-xl font-medium text-gray-900 mb-2">{tr.empty_title()}</h2>
            <p className="text-gray-500 mb-8">{tr.empty_subtitle()}</p>
            <a href="/" className="px-8 py-3 bg-gray-900 text-white rounded-xl hover:bg-black transition-colors shadow-lg hover:shadow-xl hover:-translate-y-0.5 transform duration-200">
                {tr.start_shopping()}
            </a>
        </div>
    );
}
