import React from 'react';
import CheckRoles from "@/ui/jopijs.user.CheckRoles";

import TopBarA from "@/uiComposites/website.layout.TopBarA";
import TopBarB from "@/uiComposites/website.layout.TopBarB";
import FooterA from "@/uiComposites/website.layout.FooterA";
import FooterB from "@/uiComposites/website.layout.FooterB";

import useLanguage from '@/hooks/jopijs.lang.useLanguage';
import trProvider from "@/translations/website.layout";

import FadeIn from "@/ui/website.FadeIn";

function LayoutContent({ children }: { children: React.ReactNode }) {
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    return (
        <div className="min-h-screen flex flex-col bg-white">
            <CheckRoles roles={["admin"]}>
                <div className="bg-linear-to-r from-red-700 to-red-600 text-white py-2 px-4 text-center text-xs font-bold uppercase tracking-widest shadow-md relative z-60">
                    <div className="container mx-auto flex items-center justify-center gap-3">
                        <svg className="w-4 h-4 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                        </svg>
                        <span>{tr.admin_banner_text()}</span>
                    </div>
                </div>
            </CheckRoles>

            {/* Sticky Header */}
            <header className="sticky top-0 z-50 bg-white border-b border-gray-200">
                <div className="container mx-auto px-4 flex items-center justify-between" style={{ height: '65px' }}>
                    <div className="flex items-center space-x-8 h-full">
                        <TopBarA />
                    </div>
                    <FadeIn className="flex items-center space-x-5">
                        <TopBarB />
                    </FadeIn>
                </div>
            </header>

            {/* Main Content */}
            <main className="grow">
                {children}
            </main>

            {/* Footer */}
            <footer className="bg-gray-100 py-16 border-t border-gray-200">
                <div className="container mx-auto px-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
                        <FooterA />
                    </div>
                    <div className="mt-16 pt-8 border-t border-gray-200 flex flex-col md:flex-row justify-between items-center text-xs text-gray-500">
                        <FooterB />
                    </div>
                </div>
            </footer>
        </div>
    );
}

export default function Layout({ children }: { children: React.ReactNode }) {
    return (
        <LayoutContent>{children}</LayoutContent>
    );
}
