import React from 'react';
import eventCartAddProduct from "@/events/shop.cart.add.product";
import IProduct from "@/lib/shop.IProduct";

interface ProductCardProps {
    id: string;
    product: IProduct;
    addToCartLabel: string;
    className?: string;
    style?: React.CSSProperties;
}

export default function ProductCard({ id, product, addToCartLabel, className = "", style }: ProductCardProps) {
    const link = `/product/${product.slug || product.id}`;

    return (
        <a
            href={link}
            id={id}
            className={`group cursor-pointer block ${className}`}
            style={style}
            data-product-id={product.id}
        >
            <div className="relative aspect-[4/5] bg-gray-50 rounded-sm overflow-hidden mb-5">
                <img
                    src={product.image}
                    alt={product.name}
                    width={400}
                    height={500}
                    decoding="sync"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute top-4 right-4 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <button 
                        className="bg-white/90 backdrop-blur-md p-2 rounded-full shadow-sm hover:shadow-md hover:bg-white transition-all"
                        onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            eventCartAddProduct.send(product);
                        }}
                    >
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                        </svg>
                    </button>
                </div>
                <div 
                    className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300 bg-white/95 backdrop-blur-sm flex justify-between items-center border-t border-gray-100"
                    onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        eventCartAddProduct.send(product);
                    }}
                >
                    <span className="text-sm font-medium text-gray-900">{addToCartLabel}</span>
                    <span className="text-lg font-light text-gray-500 hover:text-gray-900">+</span>
                </div>
            </div>
            <div className="flex justify-between items-start">
                <h3 className="text-lg font-medium text-gray-900 group-hover:text-jopi-green transition-colors">
                    {product.name}
                </h3>
                <span className="text-gray-900 font-medium">€{product.price.toFixed(2)}</span>
            </div>
        </a>
    );
}
