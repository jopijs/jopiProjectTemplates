import React from "react";
import trProvider from "@/translations/page.login";
import shopBg from "../jopijs.auth.loginForm/shop_bg.png";
import logo from "../jopijs.auth.loginForm/logo.png";
import Layout from "@/ui/website.layout";
import useLanguage from "@/hooks/lang.useLanguage";
import IUserInfos from "@/lib/jopijs.auth.IUserInfos";

interface MyProps  {
    user: IUserInfos;
    doLogOutUser: () => void;
}

export default function ({ user, doLogOutUser }: MyProps) {
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    return (
        <Layout>
            <div className="w-full min-h-screen flex font-sans">
                {/* Left Side: Image (Hidden on mobile) */}
                <div className="hidden lg:block flex-1 relative bg-gray-50">
                    <img src={shopBg} alt="Florist Shop" className="absolute inset-0 w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/20 mix-blend-multiply"></div>
                    <div className="absolute bottom-10 left-10 text-white p-6 max-w-md backdrop-blur-sm bg-black/10 rounded-xl">
                        <p className="text-2xl font-light italic">"{tr.alreadyLoggedQuoteText()}"</p>
                        <p className="mt-2 text-sm opacity-90">{tr.alreadyLoggedQuoteAuthor()}</p>
                    </div>
                </div>

                {/* Right Side: Content */}
                <div className="flex-1 flex flex-col items-center justify-center bg-white p-6 sm:p-12 relative">
                    {/* Mobile background hint */}
                    <div className="absolute inset-0 lg:hidden z-0 opacity-5">
                        <img src={shopBg} className="w-full h-full object-cover" alt="Background" />
                    </div>

                    <div className="w-full max-w-sm flex flex-col items-center justify-center relative z-10">
                        
                        <div className="mb-10 flex flex-col items-center">
                            <img src={logo} alt="Jopi Flores" className="h-60 w-auto object-contain" />
                        </div>

                        <h2 className="text-2xl text-gray-900 font-semibold tracking-tight text-center">
                            {tr.alreadyLoggedInAs({name: user.id})}
                        </h2>
                        
                        <p className="text-sm text-gray-500 mt-4 text-center">
                            {tr.switchAccountText()}
                        </p>

                        <button 
                            onClick={doLogOutUser}
                            className="mt-10 w-full h-12 rounded-full text-white bg-jopi-primary hover:bg-jopi-primary/90 hover:shadow-lg hover:shadow-jopi-primary/20 transition-all duration-200 font-medium tracking-wide flex items-center justify-center cursor-pointer"
                        >
                            {tr.logOut()}
                        </button>
                        
                        <a 
                            href="/"
                            className="mt-6 text-jopi-primary font-medium hover:underline decoration-2 underline-offset-2"
                        >
                            {tr.backToHome()}
                        </a>
                    </div>
                </div>
            </div>
        </Layout>
    );
};