import { useState, useEffect, ReactNode } from 'react';
import { isServerSide } from "jopijs/ui";

interface FadeInProps {
    children: ReactNode;
    duration?: number;
    className?: string;
}

export default function FadeIn({ children, duration = 1000, className = "" }: FadeInProps) {
    if (isServerSide) return null;

    const [isVisible, setIsVisible] = useState(false);

    useEffect(() => {
        const timer = requestAnimationFrame(() => {
            setIsVisible(true);
        });
        return () => cancelAnimationFrame(timer);
    }, []);

    return (
        <div 
            className={`transition-opacity ease-in-out ${isVisible ? 'opacity-100' : 'opacity-0'} ${className}`}
            style={{ transitionDuration: `${duration}ms` }}
        >
            {children}
        </div>
    );
}
