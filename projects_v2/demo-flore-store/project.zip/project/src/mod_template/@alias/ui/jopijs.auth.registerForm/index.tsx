import React from "react";
import trProvider from "@/translations/page.login";
import shopBg from "./shop_bg.png";
import logo from "./logo.png";
import Layout from "@/ui/website.layout";
import useLanguage from "@/hooks/lang.useLanguage";

interface MyProps {
    isAuhFailed?: boolean;
    errorCode?: string | null;
    isSuccess?: boolean;
    onSubmitForm: (e: React.FormEvent<HTMLFormElement>) => void;
}

export default function ({ isAuhFailed, errorCode, isSuccess, onSubmitForm }: MyProps) {
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    // Determine the error message
    let errorMessage = null;
    if (errorCode === "USER_ALREADY_EXISTS") {
        errorMessage = tr.userAlreadyExists();
    } else if (errorCode === "CANNOT_CREATE_USER") {
        errorMessage = tr.cannotCreateUser();
    } else if (isAuhFailed) {
        errorMessage = tr.registrationFailed();
    }
    
    return (
        <Layout>
            <div className="w-full min-h-screen flex font-sans">
                <div className="hidden lg:block flex-1 relative bg-gray-50">
                    <img src={shopBg} alt="Florist Shop" className="absolute inset-0 w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/20 mix-blend-multiply"></div>
                    <div className="absolute bottom-10 left-10 text-white p-6 max-w-md backdrop-blur-sm bg-black/10 rounded-xl">
                        <p className="text-2xl font-light italic">"{tr.registerQuoteText()}"</p>
                        <p className="mt-2 text-sm opacity-90">{tr.registerQuoteAuthor()}</p>
                    </div>
                </div>

                <div className="flex-1 flex flex-col items-center justify-center bg-white p-6 sm:p-12 relative">
                    {/* Mobile background hint */}
                    <div className="absolute inset-0 lg:hidden z-0 opacity-5">
                        <img src={shopBg} className="w-full h-full object-cover" alt="Background" />
                    </div>
                    
                    {isSuccess ? (
                        <div className="w-full max-w-sm flex flex-col items-center justify-center relative z-10 animate-fade-in">
                            <div className="mb-10 flex flex-col items-center">
                                <img src={logo} alt="Jopi Flores" className="h-60 w-auto object-contain" />
                            </div>
                            
                            <div className="w-full p-6 bg-green-50 border border-green-100 rounded-xl flex flex-col items-center text-center">
                                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4 text-green-600">
                                    <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                                    </svg>
                                </div>
                                <h2 className="text-2xl text-gray-900 font-semibold mb-2">{tr.accountCreated()}</h2>
                                <p className="text-gray-600 mb-8">{tr.joinCommunity()}</p>
                                
                                <a href="/login" 
                                   className="w-full h-12 flex items-center justify-center rounded-full text-white bg-jopi-primary hover:bg-jopi-primary/90 hover:shadow-lg transition-all duration-200 font-medium">
                                    {tr.logIn()}
                                </a>
                            </div>
                        </div>
                    ) : (
                        <form onSubmit={(e) => onSubmitForm(e)}
                              className="w-full max-w-sm flex flex-col items-center justify-center relative z-10">
                            
                            <div className="mb-10 flex flex-col items-center">
                                <img src={logo} alt="Jopi Flores" className="h-60 w-auto object-contain" />
                            </div>

                            <h2 className="text-2xl text-gray-900 font-semibold tracking-tight">{tr.createAccount()}</h2>
                            <p className="text-sm text-gray-500 mt-2 text-center">{tr.joinCommunity()}</p>

                            {errorMessage && (
                                <div className="mt-8 w-full p-4 bg-red-50 border border-red-100 rounded-lg flex flex-col items-center animate-fade-in">
                                    <div className="flex items-center gap-2 text-red-600">
                                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                        </svg>
                                        <span className="text-sm font-medium">{errorMessage}</span>
                                    </div>
                                    <p className="text-xs text-red-500 mt-1">{tr.checkDetails()}</p>
                                </div>
                            )}

                            <div className={errorMessage ? "mt-6" : "mt-10"}></div>

                            <div className="w-full space-y-4">
                                <div className={`group flex items-center w-full px-4 h-12 rounded-full border transition-colors duration-200 bg-white ${
                                    errorMessage ? 'border-red-300 bg-red-50/30' : 'border-gray-200 focus-within:border-jopi-primary focus-within:ring-1 focus-within:ring-jopi-primary/20'
                                }`}>
                                    <svg className={`w-5 h-5 transition-colors ${errorMessage ? 'text-red-400' : 'text-gray-400 group-focus-within:text-jopi-primary'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                    </svg>
                                    <input 
                                        name="login" 
                                        type="text" 
                                        required 
                                        placeholder={tr.usernameOrEmailPlaceholder()}
                                        className={`ml-3 bg-transparent outline-none text-sm w-full h-full ${
                                            errorMessage ? 'text-red-900 placeholder-red-400' : 'text-gray-900 placeholder-gray-400'
                                        }`}
                                    />
                                </div>

                                <div className={`group flex items-center w-full px-4 h-12 rounded-full border transition-colors duration-200 bg-white ${
                                    errorMessage ? 'border-red-300 bg-red-50/30' : 'border-gray-200 focus-within:border-jopi-primary focus-within:ring-1 focus-within:ring-jopi-primary/20'
                                }`}>
                                    <svg className={`w-5 h-5 transition-colors ${errorMessage ? 'text-red-400' : 'text-gray-400 group-focus-within:text-jopi-primary'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                                    </svg>
                                    <input 
                                        name="password" 
                                        type="password" 
                                        required 
                                        placeholder={tr.passwordPlaceholder()}
                                        className={`ml-3 bg-transparent outline-none text-sm w-full h-full ${
                                            errorMessage ? 'text-red-900 placeholder-red-400' : 'text-gray-900 placeholder-gray-400'
                                        }`}
                                    />
                                </div>
                            </div>

                            <button type="submit"
                                    className="mt-8 w-full h-12 rounded-full text-white bg-jopi-primary hover:bg-jopi-primary/90 hover:shadow-lg hover:shadow-jopi-primary/20 transition-all duration-200 font-medium tracking-wide">
                                {tr.signUp()}
                            </button>
                            
                            <p className="text-gray-500 text-sm mt-6">
                                {tr.alreadyHaveAccount()} <a className="text-jopi-primary font-medium hover:underline decoration-2 underline-offset-2" href="/login">{tr.logIn()}</a>
                            </p>
                        </form>
                    )}
                </div>
            </div>
        </Layout>
    );
};
