import trProvider from "@/translations/website.layout";
import useLanguage from '@/hooks/jopijs.lang.useLanguage';

export default function Menu() {
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    return (
         <div className="md:col-span-2 lg:col-span-1">
            <h4 className="font-bold text-sm mb-4 uppercase tracking-wider text-gray-900">{tr.footer_col4_title()}</h4>
            <p className="text-gray-600 text-sm mb-4">{tr.footer_newsletter_title()}</p>
            <div className="flex flex-col space-y-2">
                <input type="email" placeholder={tr.footer_newsletter_placeholder()} className="bg-white border border-gray-300 rounded px-4 py-2 text-sm focus:outline-none focus:border-jopi-primary" />
                <button className="bg-jopi-primary text-white px-4 py-2 rounded text-sm font-bold uppercase tracking-wider hover:bg-opacity-90 transition-colors">
                    {tr.footer_newsletter_btn()}
                </button>
            </div>
        </div>
    );
}