import CartWidget from "@/ui/shop.CartWidget";

export default CartWidget;