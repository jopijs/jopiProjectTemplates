import trProvider from "@/translations/website.layout";
import useLanguage from '@/hooks/jopijs.lang.useLanguage';

export default function Menu() {
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    return (
        <div>
            <h4 className="font-bold text-sm mb-4 uppercase tracking-wider text-gray-900">{tr.footer_col3_title()}</h4>
            <ul className="space-y-3 text-sm text-gray-600">
                <li><a href="#" className="hover:text-jopi-primary transition-colors">{tr.footer_col3_link1()}</a></li>
                <li><a href="/care-guide" className="hover:text-jopi-primary transition-colors">{tr.footer_col3_link2()}</a></li>
                <li><a href="#" className="hover:text-jopi-primary transition-colors">{tr.footer_col3_link3()}</a></li>
                <li><a href="#" className="hover:text-jopi-primary transition-colors">{tr.footer_col3_link4()}</a></li>
            </ul>
        </div>
    );
}