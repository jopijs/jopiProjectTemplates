import trProvider from "@/translations/website.layout";
import useLanguage from '@/hooks/jopijs.lang.useLanguage';
import imgLogoWide from "@/res/website.logoWide";

export default function Menu() {
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    return (
        <div className="md:col-span-2 lg:col-span-1">
            <img src={imgLogoWide} alt="Jopi" className="h-10 mb-6" />
            <p className="text-gray-500 text-sm mb-4 leading-relaxed">
                {tr.footer_tagline()}
            </p>
            <div className="flex space-x-4">
                {/* Social placeholders */}
                <div className="w-8 h-8 rounded-full bg-gray-200 hover:bg-jopi-primary transition-colors cursor-pointer"></div>
                <div className="w-8 h-8 rounded-full bg-gray-200 hover:bg-jopi-primary transition-colors cursor-pointer"></div>
                <div className="w-8 h-8 rounded-full bg-gray-200 hover:bg-jopi-primary transition-colors cursor-pointer"></div>
            </div>
        </div>
    );
}