import imgLogoWide from "@/res/website.logoWide";

export default function Logo() {
    return (
        <a href="/" className="shrink-0 flex items-center h-full decoration-0 mr-4">
            <img src={imgLogoWide} alt="JOPI" className="h-16 w-auto" width={64} height={64} />
        </a>
    );
}