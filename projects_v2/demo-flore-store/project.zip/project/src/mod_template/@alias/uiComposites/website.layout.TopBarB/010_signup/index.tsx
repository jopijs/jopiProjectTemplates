// import { useState, useEffect } from 'react';
import trProvider from "@/translations/website.layout";
import useLanguage from '@/hooks/jopijs.lang.useLanguage';
import useLocation from '@/hooks/jopijs.page.useLocation';
import useUserGetInfos from "@/hooks/jopijs.user.useGetInfos";
import { isServerSide } from "jopijs/ui";

export default function Signup() {
    // Avoid flickering
    if (isServerSide) return null;
    
    const [lang] = useLanguage();
    const tr = trProvider(lang);
    const { pathname } = useLocation();
    const isActive = pathname === '/register';
    
    const userInfos = useUserGetInfos();

    if (userInfos) return null;

    return (
        <a 
            href="/register" 
            className={`text-[13px] font-semibold ${isActive ? 'text-jopi-primary' : 'text-jopi-text hover:text-jopi-primary'}`}
        >
            {tr.auth_sign_up()}
        </a>
    );
}