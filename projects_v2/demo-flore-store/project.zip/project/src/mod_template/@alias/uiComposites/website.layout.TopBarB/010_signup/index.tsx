import { useState, useEffect } from 'react';
import trProvider from "@/translations/website.layout";
import useLanguage from '@/hooks/jopijs.lang.useLanguage';
import useLocation from '@/hooks/jopijs.page.useLocation';
import useUserGetInfos from "@/hooks/jopijs.user.useGetInfos";
import { isServerSide } from "jopijs/ui";

export default function Signup() {
    // Avoid flickering
    if (isServerSide) return null;
    
    const [isVisible, setIsVisible] = useState(false);
    const [lang] = useLanguage();
    const tr = trProvider(lang);
    const { pathname } = useLocation();
    const isActive = pathname === '/register';
    
    const userInfos = useUserGetInfos();

    useEffect(() => {
        // Create a small delay to ensure the browser has painted the initial opacity-0 state
        const timer = requestAnimationFrame(() => {
            setIsVisible(true);
        });
        return () => cancelAnimationFrame(timer);
    }, []);

    if (userInfos) return null;

    return (
        <a 
            href="/register" 
            className={`text-[13px] font-semibold transition-opacity duration-1000 ease-in-out ${isVisible ? 'opacity-100' : 'opacity-0'} ${isActive ? 'text-jopi-primary' : 'text-jopi-text hover:text-jopi-primary'}`}
        >
            {tr.auth_sign_up()}
        </a>
    );
}