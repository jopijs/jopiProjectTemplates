import useLanguage from '@/hooks/jopijs.lang.useLanguage';

export default function LangSelector() {
    const [lang, setLang] = useLanguage();
    
    return (
        <div className="flex items-center">
            <select
                value={lang}
                onChange={(e) => setLang(e.target.value)}
                className="text-[13px] font-bold text-gray-700 bg-transparent border-none outline-none cursor-pointer hover:text-jopi-primary uppercase"
            >
                <option value="fr-fr">FR</option>
                <option value="en-us">EN</option>
            </select>
        </div>
    );
}