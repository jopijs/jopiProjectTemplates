import trProvider from "@/translations/website.layout";
import useLanguage from '@/hooks/jopijs.lang.useLanguage';

export default function Copyright() {
    const [lang] = useLanguage();
    const tr = trProvider(lang);
    
    return <p>{tr.footer_copyright()}</p>
}