import trProvider from "@/translations/website.layout";
import useLanguage from '@/hooks/jopijs.lang.useLanguage';

export default function Copyright() {
    const [lang] = useLanguage();
    const tr = trProvider(lang);
    
    return (
        <div className="flex space-x-4 mt-4 md:mt-0">
            <a href="#" className="hover:text-jopi-primary">{tr.footer_privacy()}</a>
            <a href="#" className="hover:text-jopi-primary">{tr.footer_terms()}</a>
        </div>
    )
}