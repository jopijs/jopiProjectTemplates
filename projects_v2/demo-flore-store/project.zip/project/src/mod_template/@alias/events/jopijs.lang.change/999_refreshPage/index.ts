export default function() {
    window.location.reload();
}
