const img = "/jopi/logo-wide.png";
export default img;
