const img = "/jopi/error-404.png";
export default img;
