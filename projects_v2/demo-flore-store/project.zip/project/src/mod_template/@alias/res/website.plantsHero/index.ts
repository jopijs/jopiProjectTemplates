const img = "/jopi/plants_hero_banner.png";
export default img;
