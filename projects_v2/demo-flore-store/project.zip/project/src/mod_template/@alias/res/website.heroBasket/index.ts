const img = "/jopi/hero-basket.png";
export default img;
