import {RouterLink} from "../../lib/_router/index";

export default RouterLink;