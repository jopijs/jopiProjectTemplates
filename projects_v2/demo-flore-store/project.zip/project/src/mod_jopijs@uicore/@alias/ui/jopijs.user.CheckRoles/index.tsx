import React from "react";
import useUserHasOneOfThisRoles from "@/hooks/jopijs.user.useHasOneOfThisRoles";

export default function({roles, children}: {
    roles: string[],
    children: React.ReactNode
}) {
    return useUserHasOneOfThisRoles(roles) ? children : null;
}