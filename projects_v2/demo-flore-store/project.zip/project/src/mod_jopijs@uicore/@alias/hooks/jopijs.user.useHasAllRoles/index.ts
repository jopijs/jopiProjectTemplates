import useUserInfos from "@/hooks/jopijs.user.useGetInfos";

/**
 * Returns true if the user has all the given roles.
 */
export default function(roles: string[]): boolean {
    if (roles.length === 0) return true;

    let userInfos = useUserInfos();
    if (!userInfos) return false;

    let userRoles = userInfos.roles;
    if (!userRoles) return false;

    return !!roles.every(role => userRoles.includes(role));
}