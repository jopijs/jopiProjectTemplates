import { useStoreValue } from 'jopijs/ui';

export default function useLanguage() {
    return useStoreValue<string>("lang");
}