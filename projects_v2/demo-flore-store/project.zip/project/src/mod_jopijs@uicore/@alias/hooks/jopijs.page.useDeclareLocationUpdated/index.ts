export default function() {
    // Nothing to do.
    // To override if using a Router.
}