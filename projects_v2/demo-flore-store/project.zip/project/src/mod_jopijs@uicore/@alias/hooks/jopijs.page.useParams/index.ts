import {useParams} from "jopijs/ui";
export default useParams;