import {useRouterLocation} from "../../lib/_router/index.ts";
export default useRouterLocation;