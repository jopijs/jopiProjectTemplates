import {useState} from "react";

/**
 * Allow refreshing the React component.
 */
export default function() {
    const [_, setCount] = useState(0);
    return () => setCount(old => old + 1);
}