import React from "react";
import VariantContext from "@/lib/jopijs.variant.Context";

export default function useVariant<T extends React.FC>(name: string, variants: any|undefined, forceRenderer?: T|undefined) {
    if (forceRenderer) return forceRenderer;

    if (variants) {
        let renderer = (variants as any)[name];
        if (renderer) return renderer;
    }

    const ctxVariants = React.useContext(VariantContext);
    return ctxVariants[name];
}