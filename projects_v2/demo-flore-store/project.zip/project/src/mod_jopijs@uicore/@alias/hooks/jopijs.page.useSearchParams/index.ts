import {useRouterSearchParams} from "../../lib/_router/index.ts";
export default useRouterSearchParams;