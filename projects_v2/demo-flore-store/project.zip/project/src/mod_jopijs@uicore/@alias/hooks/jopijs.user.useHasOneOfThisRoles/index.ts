import useUserInfos from "@/hooks/jopijs.user.useGetInfos";

/**
 * Returns true if the user has at least one of the given roles.
 */
export default function(roles: string[]): boolean {
    if (roles.length === 0) return false;

    let userInfos = useUserInfos();
    if (!userInfos) return false;

    let userRoles = userInfos.roles;
    if (!userRoles) return false;

    let found = roles.find(role => userRoles.includes(role));
    return (found !== undefined);
}