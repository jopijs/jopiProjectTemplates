import {_usePage} from "jopijs/ui";
import IUserInfos from "@/lib/jopijs.auth.IUserInfos";

export default function(): IUserInfos|undefined {
    return _usePage().getUserInfos();
}