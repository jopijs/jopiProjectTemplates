export default function(url: string, formData: FormData): Promise<Response> {
    return fetch(url, {
        method: 'POST',
        body: formData,
        credentials: 'include'
    });
}