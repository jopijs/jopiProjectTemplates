import React from "react";

export default React.createContext<any>({});