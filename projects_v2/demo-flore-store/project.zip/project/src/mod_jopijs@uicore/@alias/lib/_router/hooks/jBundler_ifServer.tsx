// noinspection JSUnusedGlobalSymbols

import {useServerRequest} from "jopijs/ui";
import React from "react";

export type NavigateFunction = (to: string) => void;

export function useRouterNavigate(): NavigateFunction {
    // Server-side can't change the page.
    return () => {};
}

export function useRouterSearchParams(): URLSearchParams {
    return useServerRequest().req_urlInfos!.searchParams;
}

interface Path {
    pathname: string;
    search: string;
    hash: string;
}

export function useRouterLocation(): Path {
    return useServerRequest().req_urlInfos;
}

export function RouterLink({to, onClick, children, ...p}: React.ComponentProps<"a"> & {
    to: string|undefined, onClick?: (e: React.MouseEvent<HTMLAnchorElement>) => void,
    children?: React.ReactNode,
    params?: any
}) {
    return <a href={to} onClick={onClick} {...p}>{children}</a>;
}