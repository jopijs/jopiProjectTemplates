import { MenuManager } from "../../../_menuManager/index.ts";
import { isServerSide, type MenuItemForExtraPageParams, JopiUiApplication } from "jopijs/ui";

export default function (uiApp: JopiUiApplication): MenuManager {
    let menuManager = uiApp.valueStore.getValue("jopijs.menuManager") as MenuManager;
    if (menuManager) return menuManager;

    if (isServerSide) {
        const mustRemoveTrailingSlashes = uiApp.mustRemoveTrailingSlashes;
        menuManager = new MenuManager(uiApp, mustRemoveTrailingSlashes, uiApp.getCurrentURL());

    } else {
        let mustRemoveTrailingSlashes = (window as any)["__JOPI_OPTIONS__"].removeTrailingSlashes === true
        menuManager = new MenuManager(uiApp, mustRemoveTrailingSlashes);
    }

    uiApp.valueStore.setValue("jopijs.menuManager", menuManager);

    addMenuEntries(uiApp, menuManager);
    return menuManager;
}

function addMenuEntries(uiApp: JopiUiApplication, menuManager: MenuManager) {
    const menuEntries = uiApp.valueStore.getValue("jopi.server.menuEntries") as MenuItemForExtraPageParams[];
    if (!menuEntries || !menuEntries.length) return;

    const byMenu: Record<string, MenuItemForExtraPageParams[]> = {}

    for (const entry of menuEntries) {
        let e = byMenu[entry.menuName];
        if (!e) byMenu[entry.menuName] = e = [];
        e.push(entry);
    }

    for (const menuName in byMenu) {
        const entries = byMenu[menuName];

        menuManager.addMenuBuilder(menuName, (menu) => {
            entries.forEach((entry) => {
                if (entry.roles) {
                    uiApp.ifUserHasOneOfThisRoles(entry.roles, () => {
                        menu.set(entry.keys, entry)
                    })
                } else {
                    menu.set(entry.keys, entry)
                }
            });
        })
    }
}