import Layout from '@/ui/website.layout';
import trProvider from "@/translations/page.errorPages";
import useLanguage from "@/hooks/lang.useLanguage";
import imgError404 from "@/res/website.error404";

export default function Error404Page() {
    return (
        <Layout>
            <Error404Content />
        </Layout>
    );
}

function Error404Content() {
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    return (
        <div className="relative min-h-[85vh] flex flex-col items-center justify-center overflow-hidden bg-white">
            {/* Background artistic image */}
            <div className="absolute inset-0 z-0">
                <img
                    src={imgError404}
                    alt="Lost in Garden"
                    className="w-full h-full object-cover opacity-40 scale-105"
                    style={{ filter: 'blur(2px)' }}
                />
                <div className="absolute inset-0 bg-linear-to-b from-white via-transparent to-white opacity-90" />
            </div>

            {/* Content */}
            <div className="relative z-10 text-center px-4 max-w-3xl mx-auto flex flex-col items-center">
                <div className="relative mb-8">
                    <span className="text-[150px] md:text-[200px] font-bold text-jopi-primary opacity-10 block leading-none select-none transition-all duration-1000 hover:opacity-20" style={{ fontFamily: 'var(--font-futura-alt)' }}>
                        404
                    </span>
                    <div className="absolute inset-0 flex items-center justify-center">
                        <p className="text-[32px] md:text-[48px] text-jopi-accent transform -rotate-3 mt-8" style={{ fontFamily: 'var(--font-hand)' }}>
                            {tr.error404_title()}
                        </p>
                    </div>
                </div>

                <h1 className="text-[28px] md:text-[42px] font-normal mb-10 text-jopi-text leading-tight max-w-2xl" style={{ fontFamily: 'var(--font-futura-alt)' }}>
                    {tr.error404_description()}
                </h1>

                <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mt-4">
                    <a
                        href="/"
                        className="bg-jopi-primary text-white px-12 py-4 rounded-full text-[14px] font-bold uppercase tracking-[0.2em] hover:bg-opacity-90 transition-all shadow-[0_10px_30px_rgba(45,127,168,0.3)] hover:scale-105 active:scale-95 no-underline"
                    >
                        {tr.back_home()}
                    </a>

                    <a
                        href="/plants"
                        className="bg-white border border-jopi-primary text-jopi-primary px-12 py-4 rounded-full text-[14px] font-bold uppercase tracking-[0.2em] hover:bg-jopi-primary hover:text-white transition-all shadow-lg hover:scale-105 active:scale-95 no-underline"
                    >
                        Exploration
                    </a>
                </div>
            </div>

            {/* Decorative floating elements */}
            <div className="absolute top-[15%] left-[10%] w-64 h-64 bg-jopi-accent opacity-10 rounded-full blur-[100px] animate-[pulse_8s_infinite]" />
            <div className="absolute bottom-[20%] right-[5%] w-96 h-96 bg-jopi-primary opacity-10 rounded-full blur-[120px] animate-[pulse_10s_infinite]" />

            {/* Interactive cursor follower effect could go here, but keeping it simple for now */}
        </div>
    );
}
