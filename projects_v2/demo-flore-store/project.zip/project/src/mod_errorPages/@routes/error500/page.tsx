import Layout from '@/ui/website.layout';
import trProvider from "@/translations/page.errorPages";
import useLanguage from "@/hooks/lang.useLanguage";

export default function Error500Page() {
    return (
        <Layout>
            <Error500Content />
        </Layout>
    );
}

function Error500Content() {
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    return (
        <div className="relative min-h-[85vh] flex flex-col items-center justify-center overflow-hidden bg-white">
            {/* Background artistic image - Reusing 404 for now but with a different filter/hue if possible, or just same */}
            <div className="absolute inset-0 z-0">
                <img
                    src="/jopi/error-404.png"
                    alt="Unexpected Storm"
                    className="w-full h-full object-cover opacity-40 scale-105 grayscale contrast-125"
                    style={{ filter: 'blur(3px) grayscale(50%)' }}
                />
                <div className="absolute inset-0 bg-linear-to-b from-white via-transparent to-white opacity-90" />
            </div>

            {/* Content */}
            <div className="relative z-10 text-center px-4 max-w-3xl mx-auto flex flex-col items-center">
                <div className="relative mb-8">
                    <span className="text-[150px] md:text-[200px] font-bold text-red-100 opacity-20 block leading-none select-none" style={{ fontFamily: 'var(--font-futura-alt)' }}>
                        500
                    </span>
                    <div className="absolute inset-0 flex items-center justify-center">
                        <p className="text-[32px] md:text-[48px] text-jopi-primary transform -rotate-2 mt-8" style={{ fontFamily: 'var(--font-hand)' }}>
                            {tr.error500_title()}
                        </p>
                    </div>
                </div>

                <h1 className="text-[28px] md:text-[42px] font-normal mb-10 text-jopi-text leading-tight max-w-2xl" style={{ fontFamily: 'var(--font-futura-alt)' }}>
                    {tr.error500_description()}
                </h1>

                <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mt-4">
                    <a
                        href="/"
                        className="bg-jopi-primary text-white px-12 py-4 rounded-full text-[14px] font-bold uppercase tracking-[0.2em] hover:bg-opacity-90 transition-all shadow-[0_10px_30px_rgba(45,127,168,0.3)] hover:scale-105 active:scale-95 no-underline"
                    >
                        {tr.back_home()}
                    </a>
                </div>
            </div>

            {/* Decorative floating elements */}
            <div className="absolute top-[20%] right-[15%] w-64 h-64 bg-red-200 opacity-10 rounded-full blur-[100px] animate-[pulse_6s_infinite]" />
            <div className="absolute bottom-[20%] left-[5%] w-96 h-96 bg-jopi-primary opacity-10 rounded-full blur-[120px] animate-[pulse_8s_infinite]" />
        </div>
    );
}
