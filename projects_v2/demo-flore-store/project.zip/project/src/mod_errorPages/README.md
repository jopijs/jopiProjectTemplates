# jopimod_errorPages

This module manages the display of standard error pages within the application. It ensures a consistent and user-friendly experience when users encounter HTTP errors or access restricted resources.

## Features

This module provides dedicated pages for the following error scenarios:

- **401 Unauthorized**: Displayed when a user attempts to access a resource that requires authentication or permissions they do not possess.
- **404 Not Found**: Displayed when a user tries to navigate to a URL that does not exist in the application.
- **500 Server Error**: Displayed when an unexpected error occurs on the server side, offering a graceful fallback instead of a raw error trace.

## Structure

The module works by defining specific routes that intercept these error codes:

- `error401/`: Handles authorization failures.
- `error404/`: Handles "page not found" scenarios.
- `error500/`: Handles internal server errors.

## Localization

Error messages and UI elements are fully localized, with translation resources located in the `@alias/translations` directory.
