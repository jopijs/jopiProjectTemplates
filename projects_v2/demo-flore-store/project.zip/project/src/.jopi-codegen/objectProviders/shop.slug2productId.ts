import {ImplObjectProvider} from "jopijs/generated";
import providerDef from "../../mod_data/@alias/objectProviders/shop.slug2productId/index.ts";

const provider = new ImplObjectProvider("shop.slug2productId", providerDef);
export default provider;
