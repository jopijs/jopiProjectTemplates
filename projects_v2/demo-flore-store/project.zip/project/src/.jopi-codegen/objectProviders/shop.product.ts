import {ImplObjectProvider} from "jopijs/generated";
import providerDef from "../../mod_data/@alias/objectProviders/shop.product/index.ts";

const provider = new ImplObjectProvider("shop.product", providerDef);
export default provider;
