import {ImplObjectProvider} from "jopijs/generated";
import providerDef from "../../mod_data/@alias/objectProviders/shop.category/index.ts";

const provider = new ImplObjectProvider("shop.category", providerDef);
export default provider;
