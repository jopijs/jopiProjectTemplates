export const lang = "en-us";

export default {
    back_home() { return "Back to the Garden" },
    login_btn() { return "Log In" },
    error404_title() { return "Lost in the Garden" },
    error404_description() { return "It seems you've wandered off the path. The page you're looking for has vanished like morning mist." },
    error500_title() { return "Unexpected Storm" },
    error500_description() { return "An internal error occurred. Our gardeners are working to restore harmony." },
    error401_title() { return "Restricted Access" },
    error401_description() { return "You don't have the key to this secret garden. Please log in to enter." },
}