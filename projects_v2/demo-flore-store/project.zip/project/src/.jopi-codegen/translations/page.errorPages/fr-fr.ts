export const lang = "fr-fr";

export default {
    back_home() { return "Retour au Jardin" },
    login_btn() { return "Connexion" },
    error404_title() { return "Perdu dans le Jardin" },
    error404_description() { return "Il semble que vous vous soyez égaré. La page que vous cherchez a disparu comme la brume matinale." },
    error500_title() { return "Tempête inattendue" },
    error500_description() { return "Une erreur interne s'est produite. Nos jardiniers travaillent pour restaurer l'harmonie." },
    error401_title() { return "Accès Réservé" },
    error401_description() { return "Vous n'avez pas la clé de ce jardin secret. Veuillez vous connecter pour entrer." },
}