export const lang = "fr-fr";

export default {
    hero_title() { return "Nos Bouquets" },
    hero_subtitle() { return "Liés à la main avec amour" },
    hero_description() { return "Explorez notre superbe collection de bouquets de fleurs fraîches, parfaits pour toute occasion. Chaque arrangement est confectionné avec les fleurs de saison les plus fraîches." },
    add_to_cart() { return "Ajouter au panier" },
}