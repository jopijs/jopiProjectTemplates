export const lang = "en-us";

export default {
    hero_title() { return "Our Bouquets" },
    hero_subtitle() { return "Hand-tied with love" },
    hero_description() { return "Explore our stunning collection of fresh flower bouquets, perfect for any occasion. Each arrangement is crafted with the freshest seasonal blooms." },
    add_to_cart() { return "Add to Cart" },
}