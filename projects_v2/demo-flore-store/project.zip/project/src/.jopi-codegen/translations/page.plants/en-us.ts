interface I8 {
    category: string|number;
}

function fs_8(data: I8): string {return "View all " + data.category + "s"}

export const lang = "en-us";

export default {
    hero_subtitle() { return "Bring Nature Home" },
    hero_title() { return "The Plant Collection" },
    hero_description() { return "Curated greenery to transform your space into a sanctuary of calm and beauty." },
    categories_dried_title() { return "Dried Plants" },
    categories_dried_description() { return "Everlasting beauty for your home." },
    categories_potted_title() { return "Potted Plants" },
    categories_potted_description() { return "Bring nature indoors with our lush potted collection." },
    categories_succulents_title() { return "Succulents & Cacti" },
    categories_succulents_description() { return "Low maintenance, high personality." },
    common_view_all(data: I8) { return fs_8(data); },
    common_add_to_cart() { return "Add to Cart" },
    product_back_to_plants() { return "Back to Plants" },
    product_not_found() { return "Product Not Found" },
    product_continue_shopping() { return "Continue Shopping" },
    product_in_stock() { return "In Stock" },
    product_fast_delivery() { return "Fast Delivery" },
}