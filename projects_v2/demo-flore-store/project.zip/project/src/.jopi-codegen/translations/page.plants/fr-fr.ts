interface I10 {
    category: string|number;
}

function fs_10(data: I10): string {return "Voir toutes les " + data.category + "s"}

export const lang = "fr-fr";

export default {
    hero_subtitle() { return "La Nature chez Vous" },
    hero_title() { return "La Collection de Plantes" },
    hero_description() { return "Une verdure sélectionnée pour transformer votre espace en un sanctuaire de calme et de beauté." },
    categories_dried_title() { return "Plantes Séchées" },
    categories_dried_description() { return "Une beauté éternelle pour votre maison." },
    categories_potted_title() { return "Plantes en Pot" },
    categories_potted_description() { return "Invitez la nature à l'intérieur avec notre collection luxuriante." },
    categories_succulents_title() { return "Succulentes & Cactus" },
    categories_succulents_description() { return "Peu d'entretien, beaucoup de personnalité." },
    common_view_all(data: I10) { return fs_10(data); },
    common_add_to_cart() { return "Ajouter au Panier" },
    product_back_to_plants() { return "Retour aux Plantes" },
    product_not_found() { return "Produit Introuvable" },
    product_continue_shopping() { return "Continuer vos achats" },
    product_in_stock() { return "En Stock" },
    product_fast_delivery() { return "Livraison Rapide" },
}