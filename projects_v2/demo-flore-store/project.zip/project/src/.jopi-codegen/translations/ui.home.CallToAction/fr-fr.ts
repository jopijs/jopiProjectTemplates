export const lang = "fr-fr";

export default {
    title() { return "Prêt à illuminer la journée de quelqu'un ?" },
    btn_text() { return "Commencer les achats" },
}