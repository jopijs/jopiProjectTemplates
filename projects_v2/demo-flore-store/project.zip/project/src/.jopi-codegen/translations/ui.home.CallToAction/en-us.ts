export const lang = "en-us";

export default {
    title() { return "Ready to brighten someone's day?" },
    btn_text() { return "Start Shopping" },
}