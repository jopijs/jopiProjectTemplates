import L1 from "./en-us.ts";
import L2 from "./fr-fr.ts";
import defaultLang from "./default.ts";

const byLang = {
    "en-us": L1,
    "fr-fr": L2,
};

export const supportedLangs = ["en-us","fr-fr"];

export default function get(lang?: string) { return lang ? (((byLang as any)[lang]) || defaultLang) :  defaultLang }