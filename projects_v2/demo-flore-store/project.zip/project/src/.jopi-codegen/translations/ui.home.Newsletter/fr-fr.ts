export const lang = "fr-fr";

export default {
    title() { return "Envie de -15% ? Inscrivez-vous et économisez sur votre premier bouquet." },
    legal_prefix() { return "En continuant, vous acceptez nos" },
    legal_terms() { return "Conditions d'utilisation" },
    legal_and() { return "et" },
    legal_privacy() { return "Politique de confidentialité" },
    placeholder() { return "Entrez votre email" },
    btn_submit() { return "S'inscrire" },
}