export const lang = "en-us";

export default {
    title() { return "Want 15% off? Sign up and save on your first bouquet." },
    legal_prefix() { return "By continuing, you agree to our" },
    legal_terms() { return "Terms of Service" },
    legal_and() { return "and" },
    legal_privacy() { return "Privacy Policy" },
    placeholder() { return "Enter your email" },
    btn_submit() { return "Sign Up" },
}