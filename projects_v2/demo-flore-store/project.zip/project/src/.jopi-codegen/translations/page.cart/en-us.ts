interface I0 {
    count: string|number;
}

function fp_0(data: I0): string {return data.count + " items"}

function fs_0(data: I0): string {return data.count + " item"}

export const lang = "en-us";

export default {
    empty_title() { return "Your cart is empty" },
    empty_subtitle() { return "Looks like you haven't added any beautiful flowers yet." },
    start_shopping() { return "Start Shopping" },
    cart_title() { return "Shopping Cart" },
    items_plural(count: number, data: I0) {
        if (count>1) return fp_0(data);
        return fs_0(data);
},
    proceed_to_checkout() { return "Proceed to Checkout" },
    secure_checkout_stripe() { return "Secure checkout provided by Stripe" },
    subtotal() { return "Subtotal" },
    shipping() { return "Shipping" },
    taxes() { return "Taxes" },
    total() { return "Total" },
    ref() { return "Ref" },
    remove_item() { return "Remove item" },
    decrease_quantity() { return "Decrease quantity" },
    increase_quantity() { return "Increase quantity" },
    free() { return "Free" },
    taxes_estimated() { return "Tax (estimated)" },
    including_vat() { return "Including VAT" },
    download_invoice() { return "Download Invoice" },
}