interface I2 {
    count: string|number;
}

function fp_2(data: I2): string {return data.count + " articles"}

function fs_2(data: I2): string {return data.count + " article"}

export const lang = "fr-fr";

export default {
    empty_title() { return "Votre panier est vide" },
    empty_subtitle() { return "On dirait que vous n'avez pas encore ajouté de magnifiques fleurs." },
    start_shopping() { return "Commencer mes achats" },
    cart_title() { return "Mon Panier" },
    items_plural(count: number, data: I2) {
        if (count>1) return fp_2(data);
        return fs_2(data);
},
    proceed_to_checkout() { return "Passer la commande" },
    secure_checkout_stripe() { return "Paiement sécurisé par Stripe" },
    subtotal() { return "Sous-total" },
    shipping() { return "Livraison" },
    taxes() { return "Taxes" },
    total() { return "Total" },
    ref() { return "Réf" },
    remove_item() { return "Supprimer l'article" },
    decrease_quantity() { return "Diminuer la quantité" },
    increase_quantity() { return "Augmenter la quantité" },
    free() { return "Gratuit" },
    taxes_estimated() { return "Taxes (estimées)" },
    including_vat() { return "TVA incluse" },
    download_invoice() { return "Télécharger la facture" },
}