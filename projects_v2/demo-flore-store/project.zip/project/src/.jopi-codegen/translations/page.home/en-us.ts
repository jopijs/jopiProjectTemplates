export const lang = "en-us";

export default {
    hero_subtitle() { return "Let beauty bloom" },
    hero_title() { return "Fresh flowers for 2026." },
    hero_description() { return "Every petal tells a story. From daily bouquets to grand weddings, Jopi brings the freshest blooms directly from the field to your hands." },
    hero_cta() { return "Shop Flowers" },
}