export const lang = "fr-fr";

export default {
    hero_subtitle() { return "Laissez la beauté éclore" },
    hero_title() { return "Des fleurs fraîches pour 2026." },
    hero_description() { return "Chaque pétale raconte une histoire. Des bouquets quotidiens aux grands mariages, Jopi apporte les fleurs les plus fraîches directement du champ à vos mains." },
    hero_cta() { return "Acheter des Fleurs" },
}