export const lang = "fr-fr";

export default {
    hero_title() { return "Ateliers Floraux" },
    hero_subtitle() { return "Apprenez l'art de la fleuristerie" },
    hero_description() { return "Rejoignez nos experts pour des ateliers pratiques. Apprenez à composer des bouquets, créer des centres de table et prendre soin de vos plantes." },
    workshop_1_title() { return "Confection de Couronne d'Automne" },
    workshop_1_price() { return "€45" },
    workshop_1_description() { return "Créez une magnifique couronne en utilisant des feuilles et des fleurs séchées d'automne." },
    workshop_2_title() { return "Introduction aux Bouquets Liés à la Main" },
    workshop_2_price() { return "€60" },
    workshop_2_description() { return "Apprenez la technique de la spirale pour créer des bouquets au look professionnel." },
    workshop_3_title() { return "Création de Terrarium" },
    workshop_3_price() { return "€55" },
    workshop_3_description() { return "Construisez votre propre écosystème autonome dans un bocal en verre." },
    btn_book_now() { return "Réserver" },
}