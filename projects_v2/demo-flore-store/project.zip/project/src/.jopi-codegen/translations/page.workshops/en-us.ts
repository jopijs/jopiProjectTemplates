export const lang = "en-us";

export default {
    hero_title() { return "Floral Workshops" },
    hero_subtitle() { return "Learn the art of floristry" },
    hero_description() { return "Join our experts for hands-on workshops. Learn how to arrange bouquets, create centerpieces, and care for your plants." },
    workshop_1_title() { return "Autumn Wreath Making" },
    workshop_1_price() { return "€45" },
    workshop_1_description() { return "Create a beautiful wreath using dried autumn foliage and flowers." },
    workshop_2_title() { return "Introduction to Hand-Tied Bouquets" },
    workshop_2_price() { return "€60" },
    workshop_2_description() { return "Learn the spiral technique to create professional looking bouquets." },
    workshop_3_title() { return "Terrarium Building" },
    workshop_3_price() { return "€55" },
    workshop_3_description() { return "Build your own self-sustaining ecosystem in a glass jar." },
    btn_book_now() { return "Book Now" },
}