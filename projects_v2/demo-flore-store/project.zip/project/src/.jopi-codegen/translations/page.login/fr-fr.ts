interface I6 {
    name: string|number;
}

function fs_6(data: I6): string {return "Vous êtes déjà connecté en tant que : " + data.name + " !"}

export const lang = "fr-fr";

export default {
    loginQuoteText() { return "Les fleurs sont la musique de la terre. Parlées par les lèvres de la terre sans aucun son." },
    loginQuoteAuthor() { return "— Edwin Curran" },
    registerQuoteText() { return "Chaque fleur est une âme qui s'épanouit dans la nature." },
    registerQuoteAuthor() { return "— Gérard de Nerval" },
    alreadyLoggedQuoteText() { return "Une fleur ne pense pas à rivaliser avec la fleur d'à côté. Elle s'épanouit, tout simplement." },
    alreadyLoggedQuoteAuthor() { return "— Zen Shin" },
    invalidIdentifierOrPassword() { return "Identifiant ou mot de passe incorrect" },
    checkMailOrPassword() { return "Vérifiez votre e-mail et/ou votre mot de passe" },
    rememberMe() { return "Se souvenir de moi" },
    forgotPassword() { return "Mot de passe oublié ?" },
    welcomeBack() { return "Bon retour ! Veuillez vous connecter pour continuer" },
    signIn() { return "Se connecter" },
    alreadyLoggedInAs(data: I6) { return fs_6(data); },
    userAlreadyExists() { return "Un utilisateur existe déjà avec ce nom." },
    cannotCreateUser() { return "Impossible de créer l'utilisateur." },
    accountCreated() { return "Votre compte a été créé avec succès !" },
    loginPlaceholder() { return "Identifiant" },
    passwordPlaceholder() { return "Mot de passe" },
    dontHaveAccount() { return "Vous n'avez pas de compte ?" },
    signUp() { return "S'inscrire" },
    createAccount() { return "Créer un compte" },
    joinCommunity() { return "Rejoignez notre communauté florale dès aujourd'hui" },
    registrationFailed() { return "L'inscription a échoué" },
    checkDetails() { return "Veuillez vérifier vos informations et réessayer." },
    usernameOrEmailPlaceholder() { return "Nom d'utilisateur ou Email" },
    alreadyHaveAccount() { return "Vous avez déjà un compte ?" },
    logIn() { return "Se connecter" },
    switchAccountText() { return "Vous êtes actuellement connecté. Souhaitez-vous vous déconnecter pour changer de compte ?" },
    logOut() { return "Se déconnecter" },
    backToHome() { return "Retour à l'accueil" },
}