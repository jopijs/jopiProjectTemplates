interface I4 {
    name: string|number;
}

function fs_4(data: I4): string {return "You are already logged as: " + data.name + "!"}

export const lang = "en-us";

export default {
    loginQuoteText() { return "Flowers are the music of the ground. From earth's lips spoken without sound." },
    loginQuoteAuthor() { return "— Edwin Curran" },
    registerQuoteText() { return "Every flower is a soul blossoming in nature." },
    registerQuoteAuthor() { return "— Gerard De Nerval" },
    alreadyLoggedQuoteText() { return "A flower does not think of competing with the flower next to it. It just blooms." },
    alreadyLoggedQuoteAuthor() { return "— Zen Shin" },
    invalidIdentifierOrPassword() { return "Invalid identifier" },
    checkMailOrPassword() { return "Check you e-mail and/or password" },
    rememberMe() { return "Remember me" },
    forgotPassword() { return "Forgot password?" },
    welcomeBack() { return "Welcome back! Please sign in to continue" },
    signIn() { return "Sign in" },
    alreadyLoggedInAs(data: I4) { return fs_4(data); },
    userAlreadyExists() { return "A user with this name or email already exists." },
    cannotCreateUser() { return "Cannot create user. Please try again later." },
    accountCreated() { return "Account created successfully!" },
    loginPlaceholder() { return "Login" },
    passwordPlaceholder() { return "Password" },
    dontHaveAccount() { return "Don’t have an account?" },
    signUp() { return "Sign up" },
    createAccount() { return "Create Account" },
    joinCommunity() { return "Join our floral community today" },
    registrationFailed() { return "Registration failed" },
    checkDetails() { return "Please check your details and try again." },
    usernameOrEmailPlaceholder() { return "Username or Email" },
    alreadyHaveAccount() { return "Already have an account?" },
    logIn() { return "Log in" },
    switchAccountText() { return "You are currently signed in. Would you like to log out to switch accounts?" },
    logOut() { return "Log Out" },
    backToHome() { return "Back to Home" },
}