export const lang = "en-us";

export default {
    hero_title() { return "Shop by Occasion" },
    hero_subtitle() { return "For every moment" },
    hero_description() { return "Whether it's a birthday, anniversary, or just because, we have the perfect floral arrangement to express your feelings." },
    view_collection() { return "View Collection" },
    occ_wedding() { return "Wedding & Events" },
    occ_birthday() { return "Birthday" },
    occ_sympathy() { return "Sympathy" },
    occ_anniversary() { return "Anniversary" },
    occ_new_baby() { return "New Baby" },
    occ_just_because() { return "Just Because" },
}