export const lang = "fr-fr";

export default {
    hero_title() { return "Acheter par Occasion" },
    hero_subtitle() { return "Pour chaque moment" },
    hero_description() { return "Que ce soit un anniversaire ou juste pour le plaisir, nous avons l'arrangement floral parfait pour exprimer vos sentiments." },
    view_collection() { return "Voir la collection" },
    occ_wedding() { return "Mariage & Événements" },
    occ_birthday() { return "Anniversaire" },
    occ_sympathy() { return "Condoléances" },
    occ_anniversary() { return "Anniversaire de mariage" },
    occ_new_baby() { return "Naissance" },
    occ_just_because() { return "Juste pour le plaisir" },
}