import React from 'react';
import CurvedDivider from "@/ui/website.CurvedDivider";

interface PageHeroProps {
    title: string;
    subtitle?: string;
    description?: string;
}

export default function PageHero({ title, subtitle, description }: PageHeroProps) {
    return (
        <section className="bg-jopi-primary text-white pt-[60px] pb-[100px] relative overflow-hidden text-center z-10 transition-colors duration-300">
            <div className="container mx-auto px-4 relative z-20 flex flex-col items-center">
                {subtitle && (
                    <p className="text-[24px] md:text-[32px] text-jopi-accent mb-2 transform -rotate-2" style={{ fontFamily: 'var(--font-hand)' }}>
                        {subtitle}
                    </p>
                )}
                <h1 className="text-[48px] md:text-[64px] leading-tight font-normal mb-6" style={{ fontFamily: 'var(--font-futura-alt)' }}>
                    {title}
                </h1>
                {description && (
                    <p className="text-[18px] md:text-[20px] mb-10 max-w-2xl opacity-90 leading-relaxed font-light mx-auto relative z-50">
                        {description}
                    </p>
                )}
            </div>


            {/* Curved Divider */}
            <CurvedDivider />
        </section>
    );
}
