
import React from 'react';
import styles from './style.module.css';
import trProvider from "@/translations/page.plants";
import useLanguage from "@/hooks/lang.useLanguage";
import productsData from "@/res/products";
import ProductCard from "@/ui/shop.ProductCard";

const CategoryList = () => {
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    const categories = [
        {
            id: 'dried',
            title: tr.categories_dried_title(),
            description: tr.categories_dried_description(),
            products: productsData.plants.dried
        },
        {
            id: 'potted',
            title: tr.categories_potted_title(),
            description: tr.categories_potted_description(),
            products: productsData.plants.potted
        },
        {
            id: 'succulents',
            title: tr.categories_succulents_title(),
            description: tr.categories_succulents_description(),
            products: productsData.plants.succulents
        }
    ];

    return (
        <div className="container mx-auto px-4 py-16">
            {categories.map((category, idx) => (
                <div key={category.id} className="mb-24 last:mb-0">
                    <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 pb-6 border-b border-gray-100">
                        <div>
                            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'var(--font-futura-alt)' }}>
                                {category.title}
                            </h2>
                            <p className="text-gray-500 font-light text-lg">{category.description}</p>
                        </div>
                        <a href="#" className="hidden md:flex items-center gap-2 text-sm font-medium text-black group hover:text-jopi-green transition-colors mt-4 md:mt-0">
                            {tr.common_view_all({ category: category.title })}
                            <span className="transform transition-transform group-hover:translate-x-1">→</span>
                        </a>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12">
                        {category.products.map((product, pIdx) => (
                            <ProductCard
                                key={product.id}
                                id={`category-list-${product.id}`}
                                product={product}
                                addToCartLabel={tr.common_add_to_cart()}
                                className={styles.fadeIn}
                                style={{ animationDelay: `${pIdx * 100}ms` }}
                            />
                        ))}
                    </div>
                    <div className="mt-8 md:hidden flex justify-center">
                        <a href="#" className="text-sm font-medium text-black underline underline-offset-4 flex items-center gap-2">
                            {tr.common_view_all({ category: category.title })}
                            <span>→</span>
                        </a>
                    </div>
                </div>
            ))}
        </div>
    );
}

export default CategoryList;
