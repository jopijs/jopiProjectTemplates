
import React, { useEffect, useState } from 'react';
import styles from './style.module.css';
import trProvider from "@/translations/page.plants";
import useLanguage from "@/hooks/lang.useLanguage";

export default function Hero() {
    const [mounted, setMounted] = useState(false);
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    useEffect(() => {
        setMounted(true);
    }, []);

    return (
        <section className="relative h-[400px] md:h-[500px] flex items-center justify-center overflow-hidden">
            <div className="absolute inset-0 bg-black/30 z-10" />
            <img
                src="/jopi/plants_hero_banner.png"
                alt="Plants Hero"
                className={`absolute inset-0 w-full h-full object-cover transition-transform duration-[2s] ${mounted ? 'scale-100' : 'scale-110'}`}
            />
            <div className={`relative z-20 text-center text-white px-4 flex flex-col items-center ${styles.fadeIn}`}>
                <span className="mb-4 text-sm md:text-base tracking-[0.2em] uppercase font-medium text-jopi-light-gray">
                    {tr.hero_subtitle()}
                </span>
                <h1 className="text-5xl md:text-7xl font-bold mb-6 tracking-tight drop-shadow-md" style={{ fontFamily: 'var(--font-futura-alt)' }}>
                    {tr.hero_title()}
                </h1>
                <p className="text-lg md:text-xl font-light max-w-2xl mx-auto opacity-90 leading-relaxed">
                    {tr.hero_description()}
                </p>
            </div>
        </section>
    );
}
