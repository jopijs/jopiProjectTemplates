import React from 'react';

export default function Workshops() {
    return (
        <section className="py-24 bg-gray-50">
            <div className="container mx-auto px-4">
                <div className="flex flex-col md:flex-row items-center gap-16">
                    <div className="md:w-1/2">
                        <img src="https://images.unsplash.com/photo-1463936575829-25148e1db1b8?auto=format&fit=crop&q=80&w=800" alt="Workshops" className="rounded-2xl shadow-none w-full h-auto aspect-4/3 object-cover" width={800} height={600} />
                    </div>
                    <div className="md:w-1/2">
                        <h2 className="text-3xl md:text-4xl font-bold mb-6">Learn the art of floral arrangement</h2>
                        <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                            Join our community of flower lovers. Whether you're a beginner or an aspiring florist, we have workshops to help you bloom.
                        </p>
                        <ul className="space-y-4 mb-10">
                            <li className="flex items-start">
                                <span className="text-jopi-primary mr-3 text-xl">✓</span>
                                <div>
                                    <strong className="block text-gray-900">In-Person Workshops</strong>
                                    <span className="text-gray-600">Hands-on practice with fresh seasonal flowers in our studio.</span>
                                </div>
                            </li>
                            <li className="flex items-start">
                                <span className="text-jopi-primary mr-3 text-xl">✓</span>
                                <div>
                                    <strong className="block text-gray-900">Online Courses</strong>
                                    <span className="text-gray-600">Learn at your own pace with our comprehensive video guides.</span>
                                </div>
                            </li>
                            <li className="flex items-start">
                                <span className="text-jopi-primary mr-3 text-xl">✓</span>
                                <div>
                                    <strong className="block text-gray-900">Care Guides</strong>
                                    <span className="text-gray-600">Expert tips to keep your plants and flowers thriving longer.</span>
                                </div>
                            </li>
                        </ul>
                        <a href="/workshops" className="inline-block border-2 border-jopi-blue text-jopi-blue px-8 py-3 rounded-md font-bold hover:bg-jopi-blue hover:text-white transition-all">
                            Explore Workshops
                        </a>
                    </div>
                </div>
            </div>
        </section>
    );
}
