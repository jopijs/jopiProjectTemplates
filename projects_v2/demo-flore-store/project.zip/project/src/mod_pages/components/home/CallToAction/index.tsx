import trProvider from "@/translations/ui.home.CallToAction";
import useLanguage from "@/hooks/lang.useLanguage";

export default function CallToAction() {
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    return (
        <section className="py-24 bg-jopi-light-gray text-gray-900 text-center">
            <div className="container mx-auto px-4">
                <h2 className="text-4xl md:text-5xl font-bold mb-8">{tr.title()}</h2>
                <button className="bg-jopi-primary text-white px-10 py-5 rounded-md text-xl font-bold hover:shadow-2xl transition-all transform hover:-translate-y-1 cursor-pointer">
                    {tr.btn_text()}
                </button>
            </div>
        </section>
    );
}
