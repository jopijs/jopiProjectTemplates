import React from 'react';

export default function Testimonials() {
    return (
        <section className="py-24 bg-gray-50">
            <div className="container mx-auto px-4">
                <div className="text-center mb-16">
                    <h2 className="text-3xl md:text-4xl font-bold mb-4">Flowers that make moments special</h2>
                    <a href="#" className="text-jopi-primary font-bold hover:underline">View Gallery &rarr;</a>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {[
                        {
                            title: 'Summer Wedding',
                            author: 'Sarah & Tom',
                            details: 'Style: Rustic, Flowers: Wildflowers, Roses',
                            img: 'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&q=80&w=400'
                        },
                        {
                            title: 'Birthday Surprise',
                            author: 'Emily R.',
                            details: 'Style: Vibrant, Flowers: Tulips, Lilies',
                            img: '/jopi/birthday-surprise.png'
                        },
                        {
                            title: 'Corporate Gala',
                            author: 'Tech Corp',
                            details: 'Style: Modern, Flowers: Orchids, Monstera',
                            img: 'https://images.unsplash.com/photo-1561181286-d3fee7d55364?auto=format&fit=crop&q=80&w=400'
                        },
                    ].map((ex, i) => (
                        <div key={i} className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                            <div className="h-64 overflow-hidden bg-gray-100 flex items-center justify-center">
                                <img src={ex.img} alt={ex.title} className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-500" />
                            </div>
                            <div className="p-6">
                                <h3 className="font-bold text-xl mb-1">{ex.title}</h3>
                                <p className="text-gray-600 mb-4 text-sm">for {ex.author}</p>
                                <div className="text-xs text-gray-500 border-t pt-4">
                                    {ex.details}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
