import React from 'react';

export default function JopiPromise() {
    return (
        <section className="py-24 bg-white">
            <div className="container mx-auto px-4 text-center mb-16">
                <h2 className="text-3xl md:text-4xl font-bold mb-4">The Jopi Promise</h2>
            </div>
            <div className="container mx-auto px-4">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-12 text-center">
                    {[
                        { icon: '✨', title: 'Farm Fresh Quality', text: 'We source directly from sustainable farms to ensure the longest vase life.' },
                        { icon: '🤝', title: 'Trusted Florists', text: 'Expertly arranged by our master florists with years of experience.' },
                        { icon: '🌱', title: 'Eco-Friendly', text: 'Sustainable packaging and locally sourced blooms whenever possible.' },
                        { icon: '🚚', title: 'Reliable Delivery', text: 'Same-day delivery available in select cities. Freshness guaranteed.' },
                    ].map((item, i) => (
                        <div key={i} className="flex flex-col items-center">
                            <div className="w-16 h-16 bg-jopi-light-gray rounded-full flex items-center justify-center text-3xl mb-6 text-jopi-primary">
                                {item.icon}
                            </div>
                            <h3 className="font-bold mb-3 text-lg leading-tight">{item.title}</h3>
                            <p className="text-gray-500 text-sm leading-relaxed">{item.text}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
