import React from 'react';

export default function FAQ() {
    return (
        <section className="py-24 bg-gray-50">
            <div className="container mx-auto px-4 max-w-4xl">
                <div className="text-center mb-16">
                    <h2 className="text-3xl md:text-4xl font-bold mb-4">Have questions? Get answers.</h2>
                </div>
                <div className="space-y-8">
                    <div>
                        <h3 className="font-bold text-xl mb-3">What flowers does Jopi sell?</h3>
                        <p className="text-gray-600 leading-relaxed">
                            Jopi offers a wide variety of fresh blooms, including <strong className="text-gray-900">Roses</strong>,
                            <strong className="text-gray-900"> Tulips</strong>,
                            <strong className="text-gray-900"> Wildflowers</strong>, and
                            <strong className="text-gray-900"> Potted Plants</strong>. We also have seasonal collections.
                        </p>
                    </div>
                    <div>
                        <h3 className="font-bold text-xl mb-3">How do I order flowers?</h3>
                        <p className="text-gray-600 leading-relaxed">
                            1. Choose a bouquet or arrangement.<br />
                            2. Select a delivery date and add a personal message.<br />
                            3. Checkout securely.<br />
                            4. We hand-deliver to the recipient's door.
                        </p>
                    </div>
                    <div>
                        <h3 className="font-bold text-xl mb-3">Do you offer flower subscriptions?</h3>
                        <p className="text-gray-600 leading-relaxed">
                            Yes! You can subscribe to receive fresh flowers weekly, bi-weekly, or monthly.
                            Check our <a href="#" className="text-jopi-primary font-bold hover:underline">subscription page</a> for details.
                        </p>
                    </div>
                </div>
            </div>
        </section>
    );
}
