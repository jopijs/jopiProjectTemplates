import React from 'react';
import Layout from '@/ui/website.layout';
import PageHero from '../../components/shared/PageHero';
import Newsletter from '../../components/home/Newsletter';
import CallToAction from '../../components/home/CallToAction';

import useLanguage from '@/hooks/jopijs.lang.useLanguage';
import trProvider from '@/translations/page.subscriptions';

export default function SubscriptionsPage() {
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    const steps = [
        { step: '01', title: tr.step_1_title(), desc: tr.step_1_desc() },
        { step: '02', title: tr.step_2_title(), desc: tr.step_2_desc() },
        { step: '03', title: tr.step_3_title(), desc: tr.step_3_desc() },
    ];

    const plans = [
        { name: tr.plan_classic_name(), price: '€35', period: tr.period_delivery(), features: [tr.plan_classic_features_0(), tr.plan_classic_features_1(), tr.plan_classic_features_2()] },
        { name: tr.plan_seasonal_name(), price: '€55', period: tr.period_delivery(), features: [tr.plan_seasonal_features_0(), tr.plan_seasonal_features_1(), tr.plan_seasonal_features_2(), tr.plan_seasonal_features_3()], recommended: true },
        { name: tr.plan_luxe_name(), price: '€85', period: tr.period_delivery(), features: [tr.plan_luxe_features_0(), tr.plan_luxe_features_1(), tr.plan_luxe_features_2(), tr.plan_luxe_features_3(), tr.plan_luxe_features_4()] },
    ];

    return (
        <Layout>
            <main className="bg-white min-h-screen">
                <PageHero
                    title={tr.hero_title()}
                    subtitle={tr.hero_subtitle()}
                    description={tr.hero_description()}
                />

                {/* How it Works */}
                <section className="py-20 bg-gray-50">
                    <div className="container mx-auto px-4 text-center">
                        <h2 className="text-3xl md:text-4xl font-bold mb-16 text-gray-900" style={{ fontFamily: 'var(--font-futura-alt)' }}>{tr.how_it_works_title()}</h2>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
                            {steps.map((item, i) => (
                                <div key={i} className="flex flex-col items-center">
                                    <span className="text-6xl font-bold text-jopi-primary/20 mb-4" style={{ fontFamily: 'var(--font-futura-alt)' }}>{item.step}</span>
                                    <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                                    <p className="text-gray-600 max-w-xs">{item.desc}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>

                {/* Plans */}
                <section className="py-20">
                    <div className="container mx-auto px-4">
                        <h2 className="text-3xl md:text-4xl font-bold mb-16 text-center text-gray-900" style={{ fontFamily: 'var(--font-futura-alt)' }}>{tr.plan_title()}</h2>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                            {plans.map((plan, i) => (
                                <div key={i} className={`border rounded-lg p-8 relative flex flex-col items-center text-center transition-all duration-300 hover:shadow-xl ${plan.recommended ? 'border-jopi-primary shadow-lg scale-105' : 'border-gray-200'}`}>
                                    {plan.recommended && <span className="absolute top-0 -translate-y-1/2 bg-jopi-primary text-white px-4 py-1 text-xs font-bold uppercase tracking-wider rounded-full">{tr.plan_popular()}</span>}
                                    <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                                    <div className="mb-6">
                                        <span className="text-4xl font-bold">{plan.price}</span>
                                        <span className="text-gray-500 text-sm">{plan.period}</span>
                                    </div>
                                    <ul className="mb-8 space-y-3 w-full">
                                        {plan.features.map((feat, idx) => (
                                            <li key={idx} className="flex items-center justify-center text-gray-600 text-sm">
                                                <svg className="w-4 h-4 text-jopi-primary mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                                                {feat}
                                            </li>
                                        ))}
                                    </ul>
                                    <button className={`w-full py-3 rounded text-sm font-bold uppercase tracking-wider transition-colors ${plan.recommended ? 'bg-jopi-primary text-white hover:bg-opacity-90' : 'bg-gray-100 text-gray-800 hover:bg-gray-200'}`}>
                                        {tr.btn_subscribe()}
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>

                <Newsletter />
                <CallToAction />
            </main>
        </Layout>
    );
}
