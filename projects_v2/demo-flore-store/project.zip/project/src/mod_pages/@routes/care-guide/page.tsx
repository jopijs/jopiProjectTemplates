import React from 'react';
import Layout from '@/ui/website.layout';
import PageHero from '../../components/shared/PageHero';
import Newsletter from '../../components/home/Newsletter';
import CallToAction from '../../components/home/CallToAction';

import useLanguage from '@/hooks/jopijs.lang.useLanguage';
import trProvider from '@/translations/page.care-guide';

export default function CareGuidePage() {
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    const careTips = [
        { id: 1, title: tr.tip_1_title(), category: tr.tip_1_category(), text: tr.tip_1_text() },
        { id: 2, title: tr.tip_2_title(), category: tr.tip_2_category(), text: tr.tip_2_text() },
        { id: 3, title: tr.tip_3_title(), category: tr.tip_3_category(), text: tr.tip_3_text() },
        { id: 4, title: tr.tip_4_title(), category: tr.tip_4_category(), text: tr.tip_4_text() },
        { id: 5, title: tr.tip_5_title(), category: tr.tip_5_category(), text: tr.tip_5_text() },
        { id: 6, title: tr.tip_6_title(), category: tr.tip_6_category(), text: tr.tip_6_text() },
    ];

    return (
        <Layout>
            <main className="bg-white min-h-screen">
                <PageHero
                    title={tr.hero_title()}
                    subtitle={tr.hero_subtitle()}
                    description={tr.hero_description()}
                />

                <section className="container mx-auto px-4 py-20">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {careTips.map((tip) => (
                            <div key={tip.id} className="bg-orange-50/50 p-8 rounded-lg border border-orange-100 hover:border-orange-200 transition-colors">
                                <span className="text-xs font-bold text-orange-400 uppercase tracking-widest mb-2 block">{tip.category}</span>
                                <h3 className="text-xl font-bold text-gray-900 mb-4">{tip.title}</h3>
                                <p className="text-gray-600 leading-relaxed text-sm">{tip.text}</p>
                            </div>
                        ))}
                    </div>
                </section>

                <Newsletter />
                <CallToAction />
            </main>
        </Layout>
    );
}
