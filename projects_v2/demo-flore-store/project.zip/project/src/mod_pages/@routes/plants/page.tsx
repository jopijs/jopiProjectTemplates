import Layout from '@/ui/website.layout';
import { usePageData } from "jopijs/ui";
import PageHero from '@/ui/website.PageHero';
import CategoryList from '../../components/plants/CategoryList';
import Newsletter from '../../components/home/Newsletter';
import CallToAction from '../../components/home/CallToAction';

import useLanguage from '@/hooks/jopijs.lang.useLanguage';
import trProvider from '@/translations/page.plants';

export default function PlantsPage() {
    const [lang] = useLanguage();
    const tr = trProvider(lang);
    const { items: categoriesData } = usePageData() as { items: any };

    return (
        <Layout>
            <main className="bg-white min-h-screen pb-20">
                <PageHero
                    title={tr.hero_title()}
                    subtitle={tr.hero_subtitle()}
                    description={tr.hero_description()}
                />
                <CategoryList categories={categoriesData} />
                <Newsletter />
                <CallToAction />
            </main>
        </Layout>
    );
}
