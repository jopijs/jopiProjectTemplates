import { JopiPageDataProvider } from "jopijs";
import getCategory from "@/objectProviders/shop.category";
import getProduct from "@/objectProviders/shop.product";
import IProduct from "@/lib/shop.IProduct";

export default {
    async getDataForCache({req}) {
        const category = req.req_urlParts.category!;
        const lang = req.cookie_getReqCookie("lang", "en-us")!;
        
        const products = await getCategoryProducts(category, lang);
        
        return {
            items: products,
            global: { category },
            seed: products.map(p => p.id),
            itemKey: "id"
        };
    },

    async getRefreshedData({ seed }: {seed: number[]}) {
        // Seed contains product IDs
        return {
            items: await getProductsPrice(seed),
            itemKey: "id"
        };
    }
} as JopiPageDataProvider;

export async function getProductsPrice(ids: number[]) {
    if (!ids || ids.length === 0) return [];

    const products = await Promise.all(ids.map(async (id) => {
        const res = await getProduct.getValue(id);
        const val = (res && 'value' in (res as any)) ? (res as any).value : res;
        return val ? { id: val.id, price: val.price } : null;
    }));

    return products.filter((p) => !!p);
}

export async function getCategoryProducts(categorySlug: string, lang: string = "en-us") {
    const mapping: Record<string, string> = {
        'dried': 'plants.dried',
        'potted': 'plants.potted',
        'succulents': 'plants.succulents'
    };

    const catId = mapping[categorySlug];
    if (!catId) return [];

    try {
        const catRes = await getCategory.getValue(catId);
        
        let ids: number[] = [];
        if (catRes && typeof catRes === 'object' && 'value' in catRes) {
             ids = (catRes as any).value || [];
        } else if (Array.isArray(catRes)) {
             ids = catRes;
        }

        if (ids.length > 0) {
            const products = await Promise.all(ids.map(async (id) => {
                const res = await getProduct.getValue(id);
                const val = (res && 'value' in (res as any)) ? (res as any).value : res;
                return val ?? null;
            }));

            return products.filter((p): p is IProduct => !!p);
        }
    } catch (e) {
        console.error(`Error fetching category ${catId}:`, e);
    }
    
    return [];
}