import { JopiRouteConfig } from "jopijs";
import trProvider, { supportedLangs } from "@/translations/website.layout";

export default function (config: JopiRouteConfig) {
    const translations: Record<string, string> = {};

    for (const lang of supportedLangs) {
        translations[lang] = trProvider(lang).menu_plants();
    }

    config.menu_addToTopMenu(["Plants"], {
        translations,
        priority: -20
    });
}
