import { JopiPageDataProvider } from "jopijs";
import getCategory from "@/objectProviders/shop.category";
import getProduct from "@/objectProviders/shop.product";
import IProduct from "@/lib/shop.IProduct";

export default {
    async getDataForCache() {
        return {
            items: await getAllPlants() 
        } as any;
    }
} as JopiPageDataProvider;

async function getAllPlants() {
    const mapping = {
        'dried': 'plants.dried',
        'potted': 'plants.potted',
        'succulents': 'plants.succulents'
    };

    const data: Record<string, IProduct[]> = {};

    for (const [key, catId] of Object.entries(mapping)) {
        try {
            const catRes = await getCategory.getValue(catId);

            if (catRes) {
                const ids = (catRes as unknown as number[]).slice(0, 4);

                const products = await Promise.all(ids.map(async (id) => {
                    const res = await getProduct.getValue(id);
                    return res ?? null;
                }));

                data[key] = products.filter((p): p is IProduct => !!p);
            } else {
                data[key] = [];
            }
        } catch (e) {
            console.error(`Error fetching category ${catId}:`, e);
            data[key] = [];
        }
    }

    return data;
}
