import { JopiRouteConfig } from "jopijs";
import trProvider, { supportedLangs } from "@/translations/website.layout";

export default function (config: JopiRouteConfig) {
    const translations: Record<string, string> = {};

    for (const lang of supportedLangs) {
        translations[lang] = trProvider(lang).menu_bouquets();
    }

    config.menu_addToTopMenu(["Bouquets"], {
        translations,
        priority: -10
    });
}
