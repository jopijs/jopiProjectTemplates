
import { JopiPageDataProvider } from "jopijs";
import productsData from "@/res/products";

export default {
    async getDataForCache({req}) {
        // We get all bouquets from our data source
        const allBouquets = productsData.bouquets;
        
        // We extract IDs for the seed
        const bouquetIds = allBouquets.map(b => b.id);
        
        return this.getRefreshedData!({
            seed: { allIds: bouquetIds },
            isFromBrowser: false,
            req
        });
    },

    async getRefreshedData({ seed, isFromBrowser }) {
        if (isFromBrowser) console.log("Called getRefreshedData from browser. Seed:", seed);

        // Fetch products based on the seed IDs
        const allBouquets = productsData.bouquets;
        // Filter: only return what corresponds to the seed
        const products = allBouquets.filter((b) => seed.allIds.includes(b.id));

        if (isFromBrowser) {
            // Optimization for browser refresh: 
            // Return only dynamic data (price) + id for matching
            return {
                items: products.map((p) => ({
                    id: p.id,
                    price: p.price
                }))
            };
        }

        return {
            // Name this 'items' to enable automatic list merging
            items: products,

            // CRITICAL: Tells JopiJS which field uniquely identifies an item
            itemKey: "id",

            // Data passed back to the browser for future refreshes
            seed: seed
        };
    }
} as JopiPageDataProvider;
