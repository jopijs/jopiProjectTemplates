import { JopiPageDataProvider } from "jopijs";

import shopProduct from "@/objectProviders/shop.product";
import shopCategory from "@/objectProviders/shop.category";
import { PageDataProviderData } from "jopijs/ui";

export default {
    async getDataForCache({ req }) {
        const lang = req.cookie_getReqCookie("lang", "en-us")!;
        const allBouquets = await getProducts_bouquets(lang);

        const res = {
            items: allBouquets,
            seed: allBouquets.map(p => p.id),
            itemKey: "id"
        };

        return res;
    },

    async getRefreshedData({ seed }: {seed: number[]}) {
        const prices = await getPricesFromIds(seed);
        let items = seed.map((id: number) => ({ id: id, price: prices[id] }));
        return { items: items };
    }
} as JopiPageDataProvider;

async function getProducts_bouquets(lang: string) {
    let productIds = await shopCategory.useSubCache(lang).getValue("bouquets");
    if (!productIds) return [];

    const products = await Promise.all(productIds.map((id: any) => shopProduct.useSubCache(lang).getValue(id)));
    return products.filter((p: any) => !!p);
}

async function getPricesFromIds(ids: number[]) {
    let res: Record<number, number> = {};

    for (const id of ids) {
        const product = await shopProduct.getValue(id);
        
        if (product) {
            // We increase the price for the demo.
            res[id] = product.price * 5;
        }
    }

    return res;
}