
import { JopiPageDataProvider } from "jopijs";
import productsData from "@/res/products";

export default {
    /**
     * The data that will be stored inside the html page for fast rendering.
     * Is called only one time, since the result is put in cache.
     */
    async getDataForCache({req}) {
        // We get all bouquets from our data source
        const allBouquets = getProducts_bouquets();
        
        // Returns all the data.
        const res = {
            // Items is where we put our product.
            // It will be merged with the refreshed data.
            //
            items: allBouquets,

            // The data that will be passed back from the browser for future refreshes.
            // What we send is depending on your own strategy, JopiJS don't care.
            //
            seed: { allId: allBouquets.map(b => b.id) },

            // CRITICAL: Tells JopiJS which field uniquely identifies an item.
            //           JopiJS will use this field to merge the refreshed data with the previous data.
            //
            itemKey: "id",
        };

        console.log("Call to getDataForCache. Result is:", res);

        return res;
    },

    /**
     * Will be called by the browser for refreshing the data.
     * Is called for each request.
     * 
     * !!! IMPORTANT !!!
     * The seed value can be compromised by attackers.
     * You must not trust the values.
     * !!!!!!!!!!!!!!!!!
     */
    async getRefreshedData({ seed }) {
        // Get all prices in an optimized way.
        const prices = getPricesFromIds(seed.allId);

        let items = seed.allId.map((id: number) => ({
            id: id,

            // We returns only minimal datas.
            price: prices[id]
        }));

        let res = {
            // items data will be automatically merged
            // with the previous data stored inside the HTML page.
            //
            items: items
        };

        console.log("Call to getRefreshedData. Seed is:", seed, "- Result is", res);

        return res;
    }
} as JopiPageDataProvider;

// Emulate a real project: call the BDD and returns data for a full rendering.
//
function getProducts_bouquets() {
    return productsData.bouquets;
}

// Emulate a real project: call the BDD and returns only the price of a product.
//
// Improvement: You can implement a cache to avoid calling the BDD for each request.
//              If the data is too old, refresh this cache.
//
function getPricesFromIds(ids: number[]) {
    // In a real project, this would be a single SQL query: SELECT id, price FROM ... WHERE id IN (...)
    //
    const products = getProducts_bouquets().filter(p => ids.includes(p.id));
    const prices: Record<number, number> = {};

    for (const product of products) {
        // We increase the price for the demo.
        prices[product.id] = product.price * 5;
    }

    return prices;
}