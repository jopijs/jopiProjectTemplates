import { JopiRouteConfig } from "jopijs";
import trProvider, { supportedLangs } from "@/translations/website.layout";
import { applyCacheRules } from "@/mod_pages/routesCommon";

export default function (config: JopiRouteConfig) {
    applyCacheRules(config);
    const translations: Record<string, string> = {};

    for (const lang of supportedLangs) {
        translations[lang] = trProvider(lang).menu_home();
    }

    config.menu_addToTopMenu(["Home"], {
        translations,
        priority: 0
    });
}