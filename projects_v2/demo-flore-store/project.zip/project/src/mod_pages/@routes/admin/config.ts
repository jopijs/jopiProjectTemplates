import { JopiRouteConfig } from "jopijs";

export default function (config: JopiRouteConfig) {
    config.menu_addToTopMenu(["Admin"], {
        priority: -100
    });
}
