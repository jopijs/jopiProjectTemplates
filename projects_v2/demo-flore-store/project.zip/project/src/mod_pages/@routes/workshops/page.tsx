import React from 'react';
import Layout from '@/ui/website.layout';
import PageHero from '@/ui/website.PageHero';
import Newsletter from '../../components/home/Newsletter';
import CallToAction from '../../components/home/CallToAction';

import useLanguage from '@/hooks/jopijs.lang.useLanguage';
import trProvider from '@/translations/page.workshops';

const imgWorkshops = "/jopi/wildflower-bunch.png"; // Placeholder

export default function WorkshopsPage() {
    const [lang] = useLanguage();
    const tr = trProvider(lang);

    const upcomingWorkshops = [
        { id: 1, date: "Oct 15", time: '14:00 - 16:00', title: tr.workshop_1_title(), price: tr.workshop_1_price(), image: imgWorkshops, description: tr.workshop_1_description() },
        { id: 2, date: "Oct 22", time: '10:00 - 13:00', title: tr.workshop_2_title(), price: tr.workshop_2_price(), image: imgWorkshops, description: tr.workshop_2_description() },
        { id: 3, date: "Nov 05", time: '15:00 - 17:00', title: tr.workshop_3_title(), price: tr.workshop_3_price(), image: imgWorkshops, description: tr.workshop_3_description() },
    ];

    return (
        <Layout>
            <main className="bg-white min-h-screen">
                <PageHero
                    title={tr.hero_title()}
                    subtitle={tr.hero_subtitle()}
                    description={tr.hero_description()}
                />

                <section className="container mx-auto px-4 py-20">
                    <div className="max-w-4xl mx-auto space-y-8">
                        {upcomingWorkshops.map((workshop) => (
                            <div key={workshop.id} className="flex flex-col md:flex-row bg-white border border-gray-100 shadow-sm hover:shadow-md rounded-lg overflow-hidden transition-all duration-300">
                                <div className="md:w-1/3 h-48 md:h-auto overflow-hidden relative">
                                    <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 text-center rounded shadow-sm z-10">
                                        <span className="block text-sm font-bold text-gray-500 uppercase">{workshop.date.split(' ')[0]}</span>
                                        <span className="block text-xl font-bold text-jopi-primary">{workshop.date.split(' ')[1]}</span>
                                    </div>
                                    <img src={workshop.image} alt={workshop.title} className="w-full h-full object-cover transition-transform duration-700 hover:scale-105" />
                                </div>
                                <div className="md:w-2/3 p-8 flex flex-col justify-center">
                                    <div className="flex justify-between items-start mb-2">
                                        <h3 className="text-2xl font-bold text-gray-900">{workshop.title}</h3>
                                        <span className="text-xl font-medium text-jopi-primary">{workshop.price}</span>
                                    </div>
                                    <p className="text-gray-500 text-sm mb-4 flex items-center">
                                        <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                        {workshop.time}
                                    </p>
                                    <p className="text-gray-600 mb-6">{workshop.description}</p>
                                    <button className="self-start text-sm font-bold uppercase tracking-wider text-jopi-text border border-jopi-text px-6 py-2 rounded hover:bg-jopi-text hover:text-white transition-colors">
                                        {tr.btn_book_now()}
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </section>

                <Newsletter />
                <CallToAction />
            </main>
        </Layout>
    );
}
