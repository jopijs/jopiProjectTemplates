import { JopiRouteConfig } from "jopijs";
import trProvider, {supportedLangs} from "@/translations/website.layout";
import { applyCacheRules } from "@/mod_pages/routesCommon";

export default function (config: JopiRouteConfig) {
    applyCacheRules(config);
    const translations: Record<string, string> = {};

    for (let lang of supportedLangs) {
        translations[lang] = trProvider(lang).menu_workshops();
    }

    config.menu_addToTopMenu(["Workshops"], {
        translations,
        priority: -30
    });
}
