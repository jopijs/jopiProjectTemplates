import Layout from '@/ui/website.layout';
import HomeHero from "../components/home/HomeHero";
import FeaturedProducts from "../components/home/FeaturedProducts";
import Workshops from "../components/home/Workshops";
import JopiPromise from "../components/home/JopiPromise";
import Testimonials from "../components/home/Testimonials";
import FAQ from "../components/home/FAQ";
import Newsletter from "../components/home/Newsletter";
import CallToAction from "../components/home/CallToAction";

export default function Page() {
    return (
        <Layout>
            <main className="flex flex-col">
                <HomeHero />
                <FeaturedProducts />
                <Workshops />
                <JopiPromise />
                <Testimonials />
                <FAQ />
                <Newsletter />
                <CallToAction />
            </main>
        </Layout>
    );
}
