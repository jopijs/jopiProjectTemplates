import { JopiPageDataProvider } from "jopijs";
import getProductFromSlug from "@/objectProviders/shop.slug2productId";
import getProductFromId from "@/objectProviders/shop.product";

export default {
    async getDataForCache({req}) {
        let productSlug = req.req_urlParts.productSlug!;
        const lang = req.cookie_getReqCookie("lang", "en-us")!;
        const product = await getProductFromSlug.useSubCache(lang).getValue(productSlug);
    
        return {
            items: [product],
            seed: product.id,
            itemKey: "id"
        } as any;
    },

    async getRefreshedData({ seed, req }) {
        const productId = seed as number;
        const lang = req.cookie_getReqCookie("lang", "en-us")!;
        const product = await getProductFromId.useSubCache(lang).getValue(productId);
        return {items: [{id: productId, price: product.price}]};
    }
} as JopiPageDataProvider;