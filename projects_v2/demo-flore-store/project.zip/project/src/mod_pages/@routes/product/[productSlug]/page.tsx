import React from 'react';
import Layout from '@/ui/website.layout';
import useLanguage from '@/hooks/lang.useLanguage';
import IProduct from '@/lib/shop.IProduct';
import eventCartAddProduct from "@/events/shop.cart.add.product";
import trProvider from "@/translations/page.plants";
import { usePageData } from 'jopijs/ui';

export default function ProductPage() {
    const [lang] = useLanguage();
    const tr = trProvider(lang);
    
    const { items } = usePageData() as unknown as { items: IProduct[] };
    const product = items[0];
    
    const handleAddToCart = (e: React.MouseEvent) => {
        e.preventDefault();
        if (product) {
            eventCartAddProduct.send(product);
        }
    };

    return (
        <Layout>
            <main className="container mx-auto px-4 py-20 min-h-[60vh]">
                
                {!product && (
                    <div className="text-center py-10">
                        <h2 className="text-2xl font-bold text-gray-800">{tr.product_not_found ? tr.product_not_found() : "Product Not Found"}</h2>
                        <a href="/plants" className="text-jopi-primary underline mt-4 inline-block">{tr.product_back_to_plants ? tr.product_back_to_plants() : "Back to Plants"}</a>
                    </div>
                )}

                {product && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-20 items-start">
                        {/* Product Image */}
                        <div className="relative aspect-4/5 bg-gray-50 rounded-sm overflow-hidden shadow-sm">
                            <img
                                src={product.image}
                                alt={product.name}
                                className="w-full h-full object-cover"
                            />
                        </div>

                        {/* Product Details */}
                        <div className="flex flex-col h-full justify-center">
                            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4" style={{ fontFamily: 'var(--font-futura-alt)' }}>
                                {product.name}
                            </h1>
                            
                            <p className="text-2xl text-jopi-primary font-medium mb-8">
                                €{product.price.toFixed(2)}
                            </p>

                            <div className="prose text-gray-600 mb-10 text-lg leading-relaxed">
                                <p>
                                    {product.description}
                                </p>
                            </div>

                            <div className="flex flex-col sm:flex-row gap-4">
                                <button
                                    onClick={handleAddToCart}
                                    className="px-8 py-4 bg-jopi-primary text-white text-lg font-bold rounded-md hover:bg-white hover:text-jopi-primary border border-jopi-primary transition-all shadow-lg flex-1 md:flex-none justify-center flex items-center gap-2"
                                >
                                    <span>{tr.common_add_to_cart ? tr.common_add_to_cart() : "Add to Cart"}</span>
                                    <span>+</span>
                                </button>
                                
                                <a 
                                    href="/plants"
                                    className="px-8 py-4 bg-gray-100 text-gray-800 text-lg font-medium rounded-md hover:bg-gray-200 transition-all text-center flex-1 md:flex-none"
                                >
                                    {tr.product_continue_shopping ? tr.product_continue_shopping() : "Continue Shopping"}
                                </a>
                            </div>
                            
                            <div className="mt-12 pt-8 border-t border-gray-100 grid grid-cols-2 gap-4 text-sm text-gray-500">
                                <div className="flex items-center gap-2">
                                    <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                                    {tr.product_in_stock ? tr.product_in_stock() : "In Stock"}
                                </div>
                                <div className="flex items-center gap-2">
                                    <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                                    {tr.product_fast_delivery ? tr.product_fast_delivery() : "Fast Delivery"}
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </main>
        </Layout>
    );
}
