import { JopiRequest, JopiRouteConfig } from "jopijs";

export function applyCacheRules(config: JopiRouteConfig) {
    config.onPage.cache_beforeCheckingCache(async (req: JopiRequest) => {
        let lang = req.cookie_getReqCookie("lang");
        
        // The main cache is en-us.
        if (!lang || (lang=="en-us")) return;

        // For other languages, use a sub-cache.
        // Why? It allows the server to send the same content as what we will see in the browser.
        //
        // This avoid flickering, since without that:
        //      1- Prebuild HTML from the server render the english version
        //      2- React is mounted and render a translated page. Here: flickering.
        //
        // It's very small but visible.
        //
        // Note: next version of JopiJS will probably allows
        //       to avoid that through some render tips.

        console.log("Using sub-cache for lang:", lang);
        req.cache_useCache(req.cache_getSubCache(lang));
    });
}