# JopiFlores

This project is a demo application for **JopiJS**, showcasing a fully functional flower shop e-commerce interface.

## Installation

 To install the project dependencies, run:

```bash
bun install && bun install
```

or

```bash
npm install && npm install
```

## Running the Project

To start the server, you can use:

```bash
bun run start
```
