# 🌸 JopiFlores - E-Commerce Demo

> A complete showcase of the [JopiJS](https://jopijs.com) framework capabilities, demonstrating how to build a scalable, modular, and high-performance e-commerce application.

## 🌟 Overview

**JopiFlores** serves as a reference implementation for advanced JopiJS patterns.

It demonstrates how the **Cache System** and **Modular Architecture** of JopiJS can significantly simplify the implementation of complex features like a **Product Catalog** and a **Shopping Cart**.

## 🏗️ Architecture: The "Modular Monolith"

This project creates a unified application from loosely coupled modules. This separation allows specialized teams to work on specific domains (Cart, Catalog, UI Design) without stepping on each other's toes.

### 📦 Key Modules

| Module | Responsibility | Key Pattern |
| :--- | :--- | :--- |
| **`mod_pages`** | Catalog content & routing | *Static Data Injection* (`usePageData`) |
| **`mod_cart`** | Cart logic, state, persistence | *Event-Driven* & *Singleton Service* |
| **`mod_template`** | Design System (UI Kit) | *Shared Components* (`@alias/ui`) |
| **`mod_jopijs@...`** | Core features (Auth, Menu, UI) | *Framework Integration* |

---

## 🔍 Guided Tour of JopiJS Patterns

### 1. Decoupling Logic with Events
Instead of hard dependencies (e.g., the Product Card importing the Cart Store), we use **System Events**.
- **Scenario**: User clicks "Add to Cart".
- **Action**: The UI component emits `shop.cart.add.product`.
- **Reaction**: The independent `mod_cart` listens to this event and updates its state.
- **Benefit**: The UI doesn't know *how* the cart works, only that it *exists*.

### 2. Dependency Injection for Services
Global logic (like the `CartController`) is injected into the application context via the `valueStore`.
- This ensures a single instance (Singleton) manages the state.
- It makes the service available everywhere (UI, Server, other modules) via a unified API.

### 3. Smart Caching (Language Aware)
Performance is critical. It's why we use server sub-cache feature to serve one page version per language.
- See `src/mod_pages/serverInit.ts`.
- The server detects the user's language preference.
- It serves a cached version specific to that language (Sub-Cache), preventing hydration mismatch (flickering) when React takes over.

### 4. Shared Resources & Design System
Styles and UI components are centralized in `mod_template` and exported via **Aliases**.
- Any module can import from `@/ui/...` to reuse buttons, cards, or layouts.
- This enforces consistency across the entire application.

---

## � Getting Started

### Prerequisites
- **Bun** (Recommended) or Node.js.

### Installation
```bash
bun install
```

### Running Development Server
Start the development environment with hot-reload:
```bash
npm run start:dev_server
```
Visit `http://localhost:3000` to see the shop in action.

### Building Static Site (SSG)
JopiJS includes a crawler to generate static HTML files for production:
```bash
npm run build-static-site
```
Output will be generated in `./ssg-out`.

## 📂 Project Structure

```
src/
├── mod_cart/          # SHOPPING CART DOMAIN
│   ├── @alias/        # Exports (Hooks, Controller, UI)
│   └── @routes/       # /cart page definition
├── mod_pages/         # CATALOG DOMAIN
│   └── @routes/       # /bouquets, /plants pages
├── mod_template/      # DESIGN SYSTEM
│   ├── components/    # Atomic UI components
│   └── global.css     # Base styles
└── mod_jopijs@.../    # SYSTEM MODULES
```

---

*Built with ❤️ using [JopiJS](https://github.com/jopijs/jopi).*
