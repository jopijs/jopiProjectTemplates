---
description: Add data fetching to a JopiJS page using the Cache-First strategy
---

// turbo-all
1. Identify the route folder (e.g., `src/mod_main/@routes/dashboard`).
2. Create a file named `pageData.ts` in that folder.
3. Use the following template to implement the SWR (Stale-While-Revalidate) pattern:
   ```typescript
   import type { JopiPageDataProvider } from "jopijs";

   export default {
       // 1. Initial Supply: Executed on server during build or first request
       async getDataForCache({ req }) {
           const initialData = await fetchMyData();

           // Delegate to refresh to standardise the data structure
           return this.getRefreshedData({
               req,
               isFromBrowser: false,
               seed: { ids: initialData.map(d => d.id) }
           });
       },

       // 2. Background Refresh: Triggered by browser or server
       async getRefreshedData({ seed, isFromBrowser, req }) {
           const onlyDynamicFields = isFromBrowser; // Optimisation tip
           const data = await fetchMyData(seed.ids, onlyDynamicFields);

           return {
               // 'items' enables automatic list merging
               items: data,
               
               // Unique key for merging (e.g., 'id')
               itemKey: "id", 
               
               // Global data (merged into 'global' prop)
               global: {
                   pageTitle: "My Page Title"
               },

               // Data passed back to browser for future refreshes
               seed: seed
           };
       }
   } as JopiPageDataProvider;

   async function fetchMyData(ids?: number[], dynamicOnly?: boolean) {
       // Mock implementation
       return [{ id: 1, name: "Item 1", price: 100 }];
   }
   ```
4. Update your `page.tsx` to consume the data:
   ```typescript
   import { JopiPageProps, usePageData, setPageTitle } from "jopijs/ui";

   export default function Page({ params }: JopiPageProps) {
       const { items, global, isLoading } = usePageData();

       if (global?.pageTitle) setPageTitle(global.pageTitle);
       
       return (
           <div>
               <h1>{global?.pageTitle}</h1>
               {isLoading && <div>Updating...</div>}
               <ul>
                   {items?.map((item: any) => (
                       <li key={item.id}>{item.name} - ${item.price}</li>
                   ))}
               </ul>
           </div>
       );
   }
   ```
