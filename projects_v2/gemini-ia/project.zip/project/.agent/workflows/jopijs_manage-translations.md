---
description: Create, improve, or replace translations in JopiJS
---

// turbo-all
1. **Create a New Translation Namespace**:
   - Navigate to `src/mod_<module_name>/@alias/translations/`.
   - Create a subfolder for your namespace (e.g., `page.home`).
   - Inside this folder, create your language JSON files (e.g., `en-us.json`, `fr-fr.json`).
   - **Important**: Create an empty file named `en-us.default` (or your preferred language) to set it as the fallback.

2. **Add Translation Keys**:
   - **Simple**: `{ "hello": "Hello World" }`
   - **Dynamic**: `{ "welcome": "Hello %(name)!" }` -> usage: `tr.welcome({ name: "John" })`
   - **Plural**:
     ```json
     {
       "apple": "%(count) apple",
       "*apple": "%(count) apples"
     }
     ```
     -> usage: `tr.apple_plural(count, { count })`

3. **Use in Components**:
   ```tsx
   import trProvider from "@/translations/page.home"; // Import from your namespace

   export default function Component() {
       const tr = trProvider("en-us"); // Should come from context/url
       return <h1>{tr.hello()}</h1>;
   }
   ```

4. **Override/Improve Existing Translations**:
   - To change text from *another* module (e.g., `mod_core`) without modifying it:
   - Create the **exact same folder path** in your module: `src/mod_myTheme/@alias/translations/page.home`.
   - Add a marker file named `high.priority`.
   - Create a JSON file (e.g., `en-us.json`) containing *only* the keys you want to change.
   - JopiJS will merge your changes:
     ```json
     { "hello": "Welcome Back!" } // Overrides only 'hello', keeps others
     ```
