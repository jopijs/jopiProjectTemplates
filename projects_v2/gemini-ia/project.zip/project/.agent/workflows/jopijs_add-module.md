---
description: Create a new JopiJS module
---

// turbo-all
1. Create a directory `src/mod_<module_name>` (e.g., `src/mod_auth`).
2. Create a `package.json` file inside the new module directory with the following content:
   ```json
   {
     "name": "@mod/<module_name>",
     "version": "1.0.0",
     "private": true
   }
   ```
3. Run `npx jopi mod-check` at the project root to register the module and sync the workspaces.