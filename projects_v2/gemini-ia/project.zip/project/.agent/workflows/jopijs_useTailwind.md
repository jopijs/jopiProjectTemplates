---
description: Configure/Use Tailwind CSS with JopiJS
---

// turbo-all
1. JopiJS uses **Tailwind CSS v4** by default.
2. Ensure the root `global.css` file (or your main CSS file) includes the Tailwind import:
   ```css
   @import "tailwindcss";
   ```
3. You can now use Tailwind utility classes directly in `className` props or use `@apply` in `.module.css` files.
4. **Customization**: Configuration is handled via CSS variables and the `@theme` block in your CSS file.
5. **Multi-module Support**: Each module can have its own `global.css` file.
   - It is recommended to **only declare CSS variables** (tokens) inside these files, rather than writing standard CSS rules, to keep the styling system clean and predictable.